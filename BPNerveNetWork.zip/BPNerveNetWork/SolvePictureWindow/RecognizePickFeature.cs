﻿//-----------------------------------------------------------------------
// <copyright file="RecognizePickFeature.cs" company="517Na Enterprises">
// * Copyright (C) 2015 517Na科技有限公司 版权所有。
// * version : 2.0.50727.5485
// * author  : xukong
// * FileName: RecognizePickFeature.cs
// * history : created by xukong 2015-01-29 19:47:13 
// </copyright>
//-----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using PictureSolveAlgorithm;
using Better517Na.VerificationCodeParam.Model;

namespace SolvePictureWindow
{
    /// <summary>
    /// RecognizePickFeature类 
    /// </summary>
    public class RecognizePickFeature
    {
        public static List<Bitmap> allBitmap = new List<Bitmap>();

        private static Bitmap GetValidRegion(Bitmap bitMap, int gap)
        {
            int width = bitMap.Width;
            int height = bitMap.Height;
            Bitmap gg = new Bitmap(width, height);
            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    if (i > (width - gap))
                    {
                        gg.SetPixel(i, j, Color.White);
                    }
                    else
                    {
                        Color gggc = bitMap.GetPixel(i, j);
                        gg.SetPixel(i, j, gggc);
                    }
                }
            }

            return gg;
        }

        public static List<Bitmap> AverageSplit(Bitmap bitMap)
        {
            List<Bitmap> resultBitmap = new List<Bitmap>();
            int width = bitMap.Width;
            int height = bitMap.Height;
            int tempWidth = width / 3;
            for (int i = 0; i < 3; i++)
            {
                Bitmap tempBitmap = InitBitMap(width, height);
                int tempStart = i * tempWidth;
                int tempEnd = (i + 1) * tempWidth;
                for (int j = tempStart; j < tempEnd; j++)
                {
                    for (int m = 0; m < height; m++)
                    {
                        Color color = bitMap.GetPixel(j, m);
                        tempBitmap.SetPixel(j, m, color);
                    }
                }

                resultBitmap.Add(tempBitmap);
            }

            return resultBitmap;
        }

        public static Bitmap InitBitMap(int width, int heigth)
        {
            Bitmap newBitmap = new Bitmap(width, heigth);
            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < heigth; j++)
                {
                    newBitmap.SetPixel(i, j, Color.White);
                }
            }

            return newBitmap;
        }

        /// <summary>
        /// 赋值图片
        /// </summary>
        /// <param name="bimap">原始图片</param>
        /// <returns>返回复制后的结果</returns>
        public static Bitmap CopyPicture(Bitmap bimap)
        {
            Rectangle coneTangle = new Rectangle(0, 0, bimap.Width, bimap.Height);
            Bitmap newImage = bimap.Clone(coneTangle, bimap.PixelFormat);

            return newImage;
        }

        public static void TempGetSolvedPicture(Bitmap bitmap)
        {
            ////分割掉问号
            Bitmap cc = GetValidRegion(bitmap, 20);
            cc = SolvePicture.GetPictureValidByValue(cc, 4);
            cc = SolvePicture.ClearNoise(cc, 128, 2);
            ////分割图片
            ////按照每个字符宽度为10进行拆分,或者平均分割
            List<Bitmap> splitBitmapResult = AverageSplit(cc);
            List<Bitmap> bitmaps = new List<Bitmap>();
            foreach (var tempOne in splitBitmapResult)
            {
                Bitmap tempBit = CopyPicture(tempOne);
                tempBit = MuAlgorithm.GetMainConnection(tempBit, 10);
                tempBit = SolvePicture.GetPictureValidByValue(tempBit, 4);
                tempBit = ZoomAlgorithm.ReduceImage(tempBit, 10, 15);
                bitmaps.Add(tempBit);
            }

            allBitmap.AddRange(bitmaps);
        }

        public static void GetSolvedPicture(Bitmap bitmap)
        {
            //// 二值化处理
            ////Bitmap tempBitmapone = ZoomAlgorithm.ReduceImage(bitmap, 60, 25);
            //// 灰度化处理
            Bitmap tempBitmaponehdh = GrayAlgorithm.AverageGray(bitmap);
            Bitmap grayBitMap = BinaryzationAlgorithm.CVThreshold(tempBitmaponehdh);
            #region 新增图片切割

            //// 获取图片列有效列像素点数
            Bitmap binarizationBitMap = grayBitMap;
            List<int> bitMapVolumnNumList = new List<int>();
            for (int i = 0; i < binarizationBitMap.Width; i++)
            {
                int bitMapVolumnNum = 0;
                for (int j = 0; j < binarizationBitMap.Height; j++)
                {
                    Color c = binarizationBitMap.GetPixel(i, j);
                    if (binarizationBitMap.GetPixel(i, j).R == Color.Black.R)
                    {
                        bitMapVolumnNum++;
                    }
                }

                bitMapVolumnNumList.Add(bitMapVolumnNum);
            }

            ////将有效像素点区域值保存
            List<Rectangle> validPixelList = new List<Rectangle>();
            bool isFirstCut = true;
            Rectangle rect = new Rectangle();
            for (int i = 0; i < bitMapVolumnNumList.Count; i++)
            {
                if (isFirstCut)
                {
                    if (bitMapVolumnNumList[i] > 0)
                    {
                        rect = new Rectangle();
                        rect.Y = 0;
                        rect.X = i;
                        rect.Height = binarizationBitMap.Height;
                        isFirstCut = false;
                    }
                }
                else
                {
                    if (validPixelList.Count == 5)
                    {
                        break;
                        //// 最后一个 特殊处理
                        ////for (int j = bitMapVolumnNumList.Count - 1; j > 0; j--)
                        ////{
                        ////    if (bitMapVolumnNumList[j] > 0)
                        ////    {
                        ////        rect.Width = j - rect.X + 1;
                        ////        break;
                        ////    }
                        ////}
                        ////isFirstCut = true;
                        ////validPixelList.Add(rect);
                        ////break;
                    }

                    ////每个字符最后切割点
                    if (bitMapVolumnNumList[i] == 0)
                    {
                        rect.Width = i - rect.X;
                        isFirstCut = true;
                        validPixelList.Add(rect);
                    }
                }

            }

            //// 根据字符区域切割图片并保存
            List<Bitmap> pictures = new List<Bitmap>();
            foreach (Rectangle rectangle in validPixelList)
            {
                Bitmap tempBitmap = binarizationBitMap.Clone(rectangle, binarizationBitMap.PixelFormat);
                tempBitmap = SolvePicture.GetPictureValidByValue(tempBitmap, 4);
                tempBitmap = ZoomAlgorithm.ReduceImage(tempBitmap, 10, 10);
                pictures.Add(tempBitmap);

            }
            #endregion
            allBitmap.AddRange(pictures);
        }
    }
}
