﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.IO;
using PictureSolveAlgorithm;
using Better517Na.VerificationCodeParam.Bussiness;
using Better517Na.VerificationCodeParam.Model;
using BPNerveNetWork;
using System.Linq;
using System.Text.RegularExpressions;
using System.Drawing.Imaging;
using Better517na.Core.AsyncInfrastructure;
using Better517Na.AutoIdentifyVerificateCode.Iservice;

namespace SolvePictureWindow
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private static int apartCount = 0;

        private static int allApartCount = 0;

        private static int allCount = 0;

        private static int correctCount = 0;

        private static int count = 0;

        private static int error = 0;

        private static Bitmap getBitmap = null;

        private static List<Bitmap> allBitmap = new List<Bitmap>();

        private static List<MOutputMappingValue> mappingValues = new List<MOutputMappingValue>();

        private static double[,] teacherData = null;

        private static List<double[]> tempData = new List<double[]>();

        private static double[,] data = null;

        private static int ss = 0;

        private static NerveNetWork netWorkTest = null;

        private static Bitmap solveBitmap = null;

        #region 公共方法
        /// <summary>
        /// 赋值图片
        /// </summary>
        /// <param name="bimap">原始图片</param>
        /// <returns>返回复制后的结果</returns>
        public Bitmap CopyPicture(Bitmap bimap)
        {
            Rectangle coneTangle = new Rectangle(0, 0, bimap.Width, bimap.Height);
            Bitmap newImage = bimap.Clone(coneTangle, bimap.PixelFormat);

            return newImage;
        }
        #endregion

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
        private static Bitmap save = null;
        private void button1_Click(object sender, EventArgs e)
        {
            //ss++;
            string address = textBox2.Text.Trim();

            //// 从固定地址获取图片
            //HttpWebRequest myRequest = (HttpWebRequest)WebRequest.Create(address);
            //HttpWebResponse myResponse = (HttpWebResponse)myRequest.GetResponse();
            //Stream reader = myResponse.GetResponseStream();
            //Bitmap picture = new Bitmap(reader);
            //reader.Close();
            Bitmap picture = (Bitmap)Image.FromFile(string.Format("E:\\学习\\验证码识别\\图片资源\\{0}.png", address));
            pictureBox1.Image = picture;
            save = this.CopyPicture(picture);
            getBitmap = this.CopyPicture(picture);
            pictureBox15.Image = null;
            pictureBox16.Image = null;
            pictureBox17.Image = null;
            pictureBox18.Image = null;

        }

        private void twoValueBtn_Click(object sender, EventArgs e)
        {
            Bitmap grayBitMap = BinaryzationAlgorithm.CVThreshold(getBitmap);
            pictureBox2.Image = grayBitMap;
            solveBitmap = this.CopyPicture(grayBitMap);
        }

        private void pickLintBtn_Click(object sender, EventArgs e)
        {
            List<Rectangle> dd = SolvePicture.Split(solveBitmap, 30);
            List<Bitmap> pictures = new List<Bitmap>();
            string ss = string.Empty;
            List<Bitmap> del = new List<Bitmap>();

            // 去除里面像素点少的图像
            foreach (Rectangle rect in dd)
            {
                Bitmap tempBitmap = solveBitmap.Clone(rect, solveBitmap.PixelFormat);
                pictures.Add(tempBitmap);
            }

            foreach (var bb in pictures)
            {
                int ssc = ChangeSmallAlgorithm.GetPixNumber(bb);
                if (ssc < 10)
                {
                    del.Add(bb);
                }
            }

            foreach (var dddds in del)
            {
                pictures.Remove(dddds);
            }

            pictures[0] = SolvePicture.GetPictureValidByValue(pictures[0], 4);
            //pictures[0] = SolvePicture.ClearNoise(pictures[0], 128, 2);
            pictures[0] = ZoomAlgorithm.ReduceImage(pictures[0], 20, 20);

            pictures[1] = SolvePicture.GetPictureValidByValue(pictures[1], 4);
            //pictures[1] = SolvePicture.ClearNoise(pictures[1], 128, 2);
            pictures[1] = ZoomAlgorithm.ReduceImage(pictures[1], 20, 20);

            pictures[2] = SolvePicture.GetPictureValidByValue(pictures[2], 4);
            //pictures[2] = SolvePicture.ClearNoise(pictures[2], 128, 2);
            pictures[2] = ZoomAlgorithm.ReduceImage(pictures[2], 20, 20);

            pictures[3] = SolvePicture.GetPictureValidByValue(pictures[3], 4);
            //pictures[3] = SolvePicture.ClearNoise(pictures[3], 128, 2);
            pictures[3] = ZoomAlgorithm.ReduceImage(pictures[3], 20, 20);

            pictureBox9.Image = pictures[0];
            pictureBox19.Image = pictures[1];
            pictureBox17.Image = pictures[2];
            pictureBox18.Image = pictures[3];

            allBitmap.AddRange(pictures);
        }

        private void middleFilterBtn_Click(object sender, EventArgs e)
        {
            Bitmap pic = SolvePicture.ClearNoise(solveBitmap, 128, 2);
            pictureBox6.Image = pic;
            solveBitmap = this.CopyPicture(pic);
        }

        private void filterBtn_Click(object sender, EventArgs e)
        {
            ////判断图片的大小，如果长度小于52，那么则进行判断是否有问号，判断问号通过每一列的黑点个数
            int width = solveBitmap.Width;
            if (width <= 52)
            {

                ////匹配问号,用水平投影进行对比
                Bitmap gbn = this.CopyPic(solveBitmap, 9);
                Bitmap tt = this.solvepic(gbn);
                Bitmap cc = this.CopyPicture(tt);
                cc.Save("E:\\ttt5.jpg");
                string projectionValues = this.GetHorizonProjectionValue(tt);

                Bitmap yy = (Bitmap)Image.FromFile("E:\\ff.jpg");
                yy = BinaryzationAlgorithm.CVThreshold(yy);
                Bitmap ttt = this.solvepic(yy);
                string moban = this.GetHorizonProjectionValue(ttt);

                string difference = this.GetCosine(projectionValues, moban);
                pictureBox7.Image = tt;
                pictureBox12.Image = ttt;
                int diff = 0;
                for (int i = 0; i < difference.Length; i++)
                {
                    if (difference.Substring(i, 1) == "1")
                    {
                        diff++;
                    }
                }


                if (diff > 39)
                {
                    MessageBox.Show("对比失败");
                }
                else
                {
                    MessageBox.Show("对比成功");
                }
            }
            else
            {
                MessageBox.Show("不满足识别条件");
            }


            //pictureBox7.Image = bitMap;
            //solveBitmap = this.CopyPicture(bitMap);
        }

        public string GetCosine(string e1, string e2)
        {
            int length = e1.Length;
            string cc = string.Empty;
            for (int i = 0; i < length; i++)
            {
                cc += (Convert.ToInt16(e1[i]) ^ Convert.ToInt16(e2[i])).ToString();
            }

            return cc;
            //int width = e1.GetLength(0);
            //int height = e1.GetLength(1);
            //double member = 0;
            //double numerator1 = 0;
            //double numerator2 = 0;
            //for (int i = 0; i < width; i++)
            //{
            //    for (int j = 0; j < height; j++)
            //    {
            //        member += e1[i, j] & e2[i, j];
            //        numerator1 += e1[i, j];
            //        numerator2 += e2[i, j];
            //    }
            //}

            //double temp = numerator2 * numerator1;
            //return temp == 0 ? 0 : member / Math.Sqrt(temp);

            //int a = 0;//分母1
            //int b = 0;//分母2
            //int c = 0;//分子
            //int widthLength = e1.Length;
            //for (int y = 0; y < widthLength; ++y)
            //{
            //    //两个数组中的整数按位与
            //    int i = e2[y] & e1[y];
            //    //按位加
            //    for (int x = 1; x < widthLength + 1; ++x)
            //    {
            //        c += (i >> x) & 1;
            //        a += (e2[y] >> x) & 1;
            //        b += (e1[y] >> x) & 1;
            //    }
            //}

            ////计算分母
            //int d = a * b;

            //return d == 0 ? 0 : c / Math.Sqrt(d);
        }


        private Bitmap solvepic(Bitmap one)
        {
            Bitmap cc = SolvePicture.ClearNoise(one, 128, 2);
            Bitmap tt = SolvePicture.GetPictureValidByValue(cc, 4);
            tt = ZoomAlgorithm.ReduceImage(tt, 15, 15);
            return tt;
        }

        private int compare(List<int> one, List<int> two)
        {
            int result = 0;
            int count = one.Count;
            for (int i = 0; i < count; i++)
            {
                int temp = one[i] - two[i];
                if (temp != 0)
                {
                    result++;
                }
            }

            return result;
        }

        private Bitmap CopyPic(Bitmap bitMap, int gap)
        {
            int width = bitMap.Width;
            int height = bitMap.Height;
            Bitmap gg = new Bitmap(width, height);
            int start = width - gap;
            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    Color ggc = bitMap.GetPixel(i, j);
                    if (ggc == Color.Black)
                    {
                        int cc = 0;
                    }
                    if (i < start)
                    {
                        gg.SetPixel(i, j, Color.White);
                    }
                    else
                    {
                        Color gggc = bitMap.GetPixel(i, j);
                        if (gggc == Color.Black)
                        {
                            int cc = 0;
                        }
                        gg.SetPixel(i, j, ggc);
                    }
                }
            }

            return gg;
        }

        private Bitmap GetValidRegion(Bitmap bitMap, int gap)
        {
            int width = bitMap.Width;
            int height = bitMap.Height;
            Bitmap gg = new Bitmap(width, height);
            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    if (i > (width - gap))
                    {
                        gg.SetPixel(i, j, Color.White);
                    }
                    else
                    {
                        Color gggc = bitMap.GetPixel(i, j);
                        gg.SetPixel(i, j, gggc);
                    }
                }
            }

            return gg;
        }

        private string GetHorizonProjectionValue(Bitmap bitMap)
        {
            int width = bitMap.Width;
            int height = bitMap.Height;
            string tempStr = string.Empty;
            for (int i = 0; i < width; i++)
            {

                for (int j = 0; j < height; j++)
                {
                    Color gddg = bitMap.GetPixel(i, j);
                    if (gddg.R == 0 && gddg.G == 0 && gddg.B == 0)
                    {
                        tempStr += 1;
                    }
                    else
                    {
                        tempStr += 0;
                    }
                }
            }

            return tempStr;
        }

        private void getFeatureBtn_Click(object sender, EventArgs e)
        {
            data = null;
            teacherData = null;
            data = GetPictureFeature.GetPicFeature(allBitmap);
            teacherData = new double[data.GetLength(0), 35];
            for (int i = 0; i < tempData.Count; i++)
            {
                double[] ddx = tempData[i];
                for (int j = 0; j < ddx.Length; j++)
                {
                    teacherData[i, j] = ddx[j];
                }
            }

            allBitmap.Clear();
        }

        private void OneSolveBtn_Click(object sender, EventArgs e)
        {
            Bitmap bmp = MuAlgorithm.MarkLineOne(solveBitmap);
            pictureBox7.Image = bmp;
            solveBitmap = this.CopyPicture(solveBitmap);
        }

        private void getRelationBtn_Click(object sender, EventArgs e)
        {
            VerficationCodeParamOperate operate = new VerficationCodeParamOperate();
            mappingValues = operate.GetMappingValue("travelsky");
        }



        private void trainNetWorkBtn_Click(object sender, EventArgs e)
        {
            MNerveNetWork netWork = new MNerveNetWork();
            netWork.InputData = data;
            netWork.TeacherData = teacherData;
            netWork.StudyRate = 0.32;
            netWork.AllowError = 0.03;
            netWork.Beta = 0.75;
            netWork.PreSystemError = 300000;
            netWork.Theta = 1.05;
            netWork.TrainNumber = 3000;
            netWork.MomentumFactor = 0.8;
            netWork.OutputDataNumber = 11;
            //netWork.DataSource = "crossTravel";
            netWork.DataSource = "ChinaPnRV";
            OptimizeNerveNetWork netWorkTest = new OptimizeNerveNetWork(netWork);
            netWorkTest.TrainNetWork();

            MessageBox.Show("训练完成");
        }

        private void auotRecognizeBtn_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            fbd.Description = "请选择一个目录.";
            if (fbd.ShowDialog() == DialogResult.OK)
            {
                string[] PicPaht = Directory.GetFiles(fbd.SelectedPath, "*.png");
                textBox5.Text = PicPaht.Length.ToString();
                for (int m = 0; m < PicPaht.Length; m++)
                {
                    // 加载图片
                    Image img = Image.FromFile(PicPaht[m]);
                    string pictureName = PicPaht[m].Split('\\')[2].Split('.')[0];
                    Bitmap bitmap = new Bitmap(img);
                    pictureBox9.Image = bitmap;
                    // 图片预处理
                    RecognizePickFeature.GetSolvedPicture(bitmap);
                    if (RecognizePickFeature.allBitmap.Count == 4)
                    {
                        double[,] sampleData = GetPictureFeature.GetPicFeature(RecognizePickFeature.allBitmap);
                        pictureBox10.Image = RecognizePickFeature.allBitmap[0];
                        pictureBox11.Image = RecognizePickFeature.allBitmap[1];
                        pictureBox12.Image = RecognizePickFeature.allBitmap[2];
                        pictureBox13.Image = RecognizePickFeature.allBitmap[3];

                        VerficationCodeParamOperate operate = new VerficationCodeParamOperate();
                        List<MSystemParam> SystemParam = operate.GetSystemParam("MUB2C");
                        string paramName = "hideNodeNumber";

                        // 拿到隐层节点数目
                        MSystemParam hideSysParam = SystemParam.Find(p => p.ParamName == paramName);

                        // 拿到输出节点数目
                        paramName = "outPutNodeNumber";
                        MSystemParam outputSysParam = SystemParam.Find(p => p.ParamName == paramName);
                        paramName = "inputNodeNumber";
                        MSystemParam inputSysParam = SystemParam.Find(p => p.ParamName == paramName);

                        int hideNodeNumber = Convert.ToInt32(hideSysParam.ParamValue);
                        int outPutNodeNumber = Convert.ToInt32(outputSysParam.ParamValue);
                        int inputNodeNumber = Convert.ToInt32(inputSysParam.ParamValue);

                        List<MOutputMappingValue> MappingValue = operate.GetMappingValue("MUB2C");

                        List<MWeightMatrix> HiddenWeightMatrix = operate.GetWeightMatrix("MUB2C", 0);
                        HiddenWeightMatrix = HiddenWeightMatrix.OrderBy(p => p.MatrixLocation).ToList();
                        int col = HiddenWeightMatrix[0].MatrixLineData.Split(',').Length;
                        int line = HiddenWeightMatrix.Count;
                        double[,] hideWeightMatrix = new double[line, col];
                        for (int i = 0; i < line; i++)
                        {
                            string[] lineData = HiddenWeightMatrix[i].MatrixLineData.Split(',');
                            for (int j = 0; j < col; j++)
                            {
                                hideWeightMatrix[i, j] = Convert.ToDouble(lineData[j]);
                            }
                        }

                        List<MWeightMatrix> OutputWeightMatrix = operate.GetWeightMatrix("MUB2C", 1);
                        OutputWeightMatrix = OutputWeightMatrix.OrderBy(p => p.MatrixLocation).ToList();
                        int col1 = OutputWeightMatrix[0].MatrixLineData.Split(',').Length;
                        int line1 = OutputWeightMatrix.Count;
                        double[,] outputWeightMatrix = new double[line1, col1];
                        for (int i = 0; i < line1; i++)
                        {
                            string[] lineData = OutputWeightMatrix[i].MatrixLineData.Split(',');
                            for (int j = 0; j < col1; j++)
                            {
                                outputWeightMatrix[i, j] = Convert.ToDouble(lineData[j]);
                            }
                        }

                        // 拿到隐藏层阀值,只有一条数据
                        List<MWeightMatrix> hideThreshold = operate.GetWeightMatrix("MUB2C", 2);
                        string[] hideThresholdResult = hideThreshold[0].MatrixLineData.Split(',');
                        double[] hideThresholdAdjust = new double[hideThresholdResult.Length];
                        for (int i = 0; i < hideThresholdResult.Length; i++)
                        {
                            hideThresholdAdjust[i] = Convert.ToDouble(hideThresholdResult[i]);
                        }

                        // 拿到输出层阀值，只有一条数据
                        List<MWeightMatrix> outPutThreshold = operate.GetWeightMatrix("MUB2C", 3);
                        string[] outPutThresholdResult = outPutThreshold[0].MatrixLineData.Split(',');
                        double[] outPutThresholdAdjust = new double[outPutThresholdResult.Length];
                        for (int i = 0; i < outPutThresholdResult.Length; i++)
                        {
                            outPutThresholdAdjust[i] = Convert.ToDouble(outPutThresholdResult[i]);
                        }


                        List<double[]> resultValues = new List<double[]>();
                        NerveNetWork netWorkTest = new NerveNetWork();
                        for (int i = 0; i < sampleData.GetLength(0); i++)
                        {
                            double[] result = netWorkTest.NetWorkSim(sampleData, hideWeightMatrix, outputWeightMatrix, hideThresholdAdjust, outPutThresholdAdjust, inputNodeNumber, hideNodeNumber, outPutNodeNumber, i);
                            resultValues.Add(result);
                        }

                        RecognizePickFeature.allBitmap.Clear();

                        string resultStr = string.Empty;
                        foreach (var yy in resultValues)
                        {
                            int result = 0;
                            double resultValue = 0.0;
                            for (int i = 0; i < 35; i++)
                            {
                                if (resultValue < yy[i])
                                {
                                    resultValue = yy[i];
                                    result = i;
                                }
                            }

                            MOutputMappingValue cc = mappingValues.Find(p => p.MappingValue == result);
                            resultStr += cc.TeacherData;
                        }

                        if (resultStr == pictureName)
                        {
                            correctCount++;
                        }

                        textBox6.Text = correctCount.ToString();
                    }
                    else
                    {
                        RecognizePickFeature.allBitmap.Clear();
                        MessageBox.Show("拆分有问题");
                    }

                }
            }
        }

        /// <summary>
        /// 等比例缩放图片
        /// </summary>
        /// <param name="initImage">图片</param>
        /// <returns>返回统一后的图片</returns>
        public Bitmap NarrowOrEnlarge(Bitmap initImage)
        {
            Bitmap bimap = null;
            System.Drawing.Image newImage = null;
            System.Drawing.Graphics newG = null;
            try
            {
                if (initImage != null)
                {
                    double newWidth = initImage.Width;
                    double newHeight = initImage.Height;
                    double targetWidth = 100;
                    double targetHeight = 100;

                    // 宽大于高或宽等于高（横图或正方）
                    if (initImage.Width >= initImage.Height)
                    {
                        newWidth = targetWidth;
                        newHeight = initImage.Height * (targetWidth / initImage.Width);
                    }
                    else
                    {
                        newHeight = targetHeight;
                        newWidth = initImage.Width * (targetHeight / initImage.Height);
                    }

                    // 生成新图
                    // 新建一个bmp图片
                    newImage = new System.Drawing.Bitmap((int)newWidth, (int)newHeight);

                    // 新建一个画板
                    newG = System.Drawing.Graphics.FromImage(newImage);

                    // 设置质量
                    newG.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                    newG.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;

                    // 置背景色
                    newG.Clear(Color.White);

                    // 画图
                    newG.DrawImage(initImage, new System.Drawing.Rectangle(0, 0, newImage.Width, newImage.Height), new System.Drawing.Rectangle(0, 0, initImage.Width, initImage.Height), System.Drawing.GraphicsUnit.Pixel);

                    // 保存缩略图
                    bimap = newImage as Bitmap;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (newG != null)
                {
                    newG.Dispose();
                }

                if (initImage != null)
                {
                    initImage.Dispose();
                }
            }

            return bimap;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string address = textBox2.Text.Trim();
            //allCount++;
            //textBox7.Text = allCount.ToString();
            //// 从固定地址获取图片
            //HttpWebRequest myRequest = (HttpWebRequest)WebRequest.Create(address);
            //HttpWebResponse myResponse = (HttpWebResponse)myRequest.GetResponse();
            //Stream reader = myResponse.GetResponseStream();
            ////Bitmap picture = (Bitmap)Image.FromFile("E:\\AllPictures\\MUE_C\\WCL7.PNG");
            //Bitmap picture = new Bitmap(reader);
            //reader.Close();
            //pictureBox1.Image = picture;
            //getBitmap = picture;

            //Bitmap bitmap = this.CopyPicture(getBitmap);
            //pictureBox9.Image = bitmap;
            Bitmap bitmap = (Bitmap)Image.FromFile(string.Format("E:/umetricp/{0}.png", address));

            ////bitmap = this.NarrowOrEnlarge(bitmap
            ////AdditionalParam additionalParam = new AdditionalParam()
            ////{
            ////    LogKey1 = "航旅纵横图片"
            ////};

            ////string validateCode = WcfCallHelper.Instance.Invoke<IRecognizeVerificateCode, Bitmap, string, string>(bitmap, "CrossTravel", "RecognizeCode", additionalParam);

            ////// 图片预处理
            RecognizePickFeature.GetSolvedPicture(bitmap);

            double[,] sampleData = GetPictureFeature.GetPicFeature(RecognizePickFeature.allBitmap);
            //pictureBox10.Image = RecognizePickFeature.allBitmap[0];
            //pictureBox11.Image = RecognizePickFeature.allBitmap[1];
            //pictureBox12.Image = RecognizePickFeature.allBitmap[2];
            //pictureBox13.Image = RecognizePickFeature.allBitmap[3];
            //pictureBox18.Image = RecognizePickFeature.allBitmap[4];

            VerficationCodeParamOperate operate = new VerficationCodeParamOperate();
            //mappingValues = operate.GetMappingValue("CrossTravel"); 
            mappingValues = operate.GetMappingValue("ChinaPnRV");
            //List<MSystemParam> SystemParam = operate.GetSystemParam("CrossTravel");
            List<MSystemParam> SystemParam = operate.GetSystemParam("ChinaPnRV");
            string paramName = "hideNodeNumber";

            // 拿到隐层节点数目
            MSystemParam hideSysParam = SystemParam.Find(p => p.ParamName == paramName);

            // 拿到输出节点数目
            paramName = "outPutNodeNumber";
            MSystemParam outputSysParam = SystemParam.Find(p => p.ParamName == paramName);
            paramName = "inputNodeNumber";
            MSystemParam inputSysParam = SystemParam.Find(p => p.ParamName == paramName);

            int hideNodeNumber = Convert.ToInt32(hideSysParam.ParamValue);
            int outPutNodeNumber = Convert.ToInt32(outputSysParam.ParamValue);
            int inputNodeNumber = Convert.ToInt32(inputSysParam.ParamValue);

            List<MOutputMappingValue> MappingValue = operate.GetMappingValue("ChinaPnRV");

            List<MWeightMatrix> HiddenWeightMatrix = operate.GetWeightMatrix("ChinaPnRV", 0);
            HiddenWeightMatrix = HiddenWeightMatrix.OrderBy(p => p.MatrixLocation).ToList();
            int col = HiddenWeightMatrix[0].MatrixLineData.Split(',').Length;
            int line = HiddenWeightMatrix.Count;
            double[,] hideWeightMatrix = new double[line, col];
            for (int i = 0; i < line; i++)
            {
                string[] lineData = HiddenWeightMatrix[i].MatrixLineData.Split(',');
                for (int j = 0; j < col; j++)
                {
                    hideWeightMatrix[i, j] = Convert.ToDouble(lineData[j]);
                }
            }

            List<MWeightMatrix> OutputWeightMatrix = operate.GetWeightMatrix("ChinaPnRV", 1);
            OutputWeightMatrix = OutputWeightMatrix.OrderBy(p => p.MatrixLocation).ToList();
            int col1 = OutputWeightMatrix[0].MatrixLineData.Split(',').Length;
            int line1 = OutputWeightMatrix.Count;
            double[,] outputWeightMatrix = new double[line1, col1];
            for (int i = 0; i < line1; i++)
            {
                string[] lineData = OutputWeightMatrix[i].MatrixLineData.Split(',');
                for (int j = 0; j < col1; j++)
                {
                    outputWeightMatrix[i, j] = Convert.ToDouble(lineData[j]);
                }
            }

            // 拿到隐藏层阀值,只有一条数据
            List<MWeightMatrix> hideThreshold = operate.GetWeightMatrix("ChinaPnRV", 2);
            string[] hideThresholdResult = hideThreshold[0].MatrixLineData.Split(',');
            double[] hideThresholdAdjust = new double[hideThresholdResult.Length];
            for (int i = 0; i < hideThresholdResult.Length; i++)
            {
                hideThresholdAdjust[i] = Convert.ToDouble(hideThresholdResult[i]);
            }

            // 拿到输出层阀值，只有一条数据
            List<MWeightMatrix> outPutThreshold = operate.GetWeightMatrix("ChinaPnRV", 3);
            string[] outPutThresholdResult = outPutThreshold[0].MatrixLineData.Split(',');
            double[] outPutThresholdAdjust = new double[outPutThresholdResult.Length];
            for (int i = 0; i < outPutThresholdResult.Length; i++)
            {
                outPutThresholdAdjust[i] = Convert.ToDouble(outPutThresholdResult[i]);
            }


            List<double[]> resultValues = new List<double[]>();
            NerveNetWork netWorkTest = new NerveNetWork();
            for (int i = 0; i < sampleData.GetLength(0); i++)
            {
                double[] result = netWorkTest.NetWorkSim(sampleData, hideWeightMatrix, outputWeightMatrix, hideThresholdAdjust, outPutThresholdAdjust, inputNodeNumber, hideNodeNumber, outPutNodeNumber, i);
                resultValues.Add(result);
            }

            RecognizePickFeature.allBitmap.Clear();

            string resultStr = string.Empty;
            foreach (var yy in resultValues)
            {
                int result = 0;
                double resultValue = 0.0;
                for (int i = 0; i < 10; i++)
                {
                    if (resultValue < yy[i])
                    {
                        resultValue = yy[i];
                        result = i;
                    }
                }

                MOutputMappingValue cc = mappingValues.Find(p => p.MappingValue == result);
                resultStr += cc.TeacherData;
            }

            textBox9.Text = resultStr;

        }

        private void button4_Click(object sender, EventArgs e)
        {
            correctCount++;
            textBox8.Text = (correctCount * 1.0 / allCount * 1.0).ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Bitmap dd = MuAlgorithm.RemoveRed(solveBitmap);
            pictureBox8.Image = dd;
            solveBitmap = this.CopyPicture(solveBitmap);

            //Bitmap twoValue = BinaryzationAlgorithm.CVThreshold(solveBitmap);
            //pictureBox8.Image = twoValue;
            //solveBitmap = this.CopyPicture(twoValue);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            data = null;
            teacherData = null;
            data = GetPictureFeature.GetPicFeature(allBitmap);
            teacherData = new double[data.GetLength(0), 13];
            for (int i = 0; i < tempData.Count; i++)
            {
                double[] ddx = tempData[i];
                for (int j = 0; j < ddx.Length; j++)
                {
                    teacherData[i, j] = ddx[j];
                }
            }

            MessageBox.Show("特征提取完成");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Bitmap bmp = SolvePicture.MiddleFileter(solveBitmap, 128);
            pictureBox14.Image = bmp;
            solveBitmap = this.CopyPicture(bmp);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            List<Rectangle> dd = SolvePicture.Split(solveBitmap, 30);
            if (dd.Count >= 4)
            {
                List<Bitmap> pictures = new List<Bitmap>();
                List<Bitmap> del = new List<Bitmap>();

                foreach (Rectangle rect in dd)
                {
                    Bitmap tempBitmap = solveBitmap.Clone(rect, solveBitmap.PixelFormat);
                    pictures.Add(tempBitmap);
                }

                // 去掉每一张图片中连通域较小的，尤其是第一个字符
                pictures[0] = MuAlgorithm.GetMainConnection(pictures[0], 100);
                pictures[1] = MuAlgorithm.GetMainConnection(pictures[1], 30);
                pictures[2] = MuAlgorithm.GetMainConnection(pictures[2], 30);
                pictures[3] = MuAlgorithm.GetMainConnection(pictures[3], 30);
                pictures[0] = SolvePicture.ClearNoise(pictures[0], 128, 3);

                pictureBox15.Image = ZoomAlgorithm.ReduceImage(SolvePicture.GetPictureValidByValue(pictures[0], 128, 4), 20, 20);
                pictureBox16.Image = ZoomAlgorithm.ReduceImage(SolvePicture.GetPictureValidByValue(pictures[1], 128, 4), 20, 20);
                pictureBox17.Image = ZoomAlgorithm.ReduceImage(SolvePicture.GetPictureValidByValue(pictures[2], 128, 4), 20, 20);
                pictureBox18.Image = ZoomAlgorithm.ReduceImage(SolvePicture.GetPictureValidByValue(pictures[3], 128, 4), 20, 20);
            }
            else
            {
                MessageBox.Show("拆分有问题");
            }

        }

        private void button9_Click(object sender, EventArgs e)
        {
            Guid guid = new Guid();
            guid = Guid.NewGuid();
            Bitmap bitMap = SolvePicture.GetPictureValidByValue(solveBitmap, 128, 4);

            // 缩放到同样大小
            bitMap = ZoomAlgorithm.ReduceImage(bitMap, 90, 35);
            pictureBox19.Image = bitMap;
            if (!string.IsNullOrEmpty(textBox1.Text))
            {
                bitMap.Save(string.Format("E:\\MUB2C\\{0}.png", textBox1.Text));
            }

            solveBitmap = this.CopyPicture(bitMap);
            label5.Text = solveBitmap.Width + ":" + solveBitmap.Height;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Bitmap one = null;
            Bitmap two = null;
            Bitmap three = null;
            Bitmap four = null;

        }

        private void button2_Click(object sender, EventArgs e)
        {



        }

        private void button11_Click(object sender, EventArgs e)
        {
            VerficationCodeParamOperate operate = new VerficationCodeParamOperate();
            mappingValues = operate.GetMappingValue("MUB2C");
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            fbd.Description = "请选择一个目录.";
            if (fbd.ShowDialog() == DialogResult.OK)
            {
                string[] PicPaht = Directory.GetFiles(fbd.SelectedPath, "*.png");
                Bitmap one = null;
                Bitmap two = null;
                Bitmap three = null;
                Bitmap four = null;
                for (int m = 0; m < PicPaht.Length; m++)
                {
                    Bitmap bitmap = (Bitmap)Image.FromFile(PicPaht[m]);
                    Bitmap solveBitmap = null;
                    string pictureName = PicPaht[m].Split('\\')[2].Split('.')[0];
                    try
                    {
                        // 图片预处理
                        #region 均值灰度化
                        Bitmap twoValue = GrayAlgorithm.AverageGray(bitmap);
                        pictureBox2.Image = twoValue;
                        solveBitmap = this.CopyPicture(twoValue);
                        #endregion

                        #region 黑白化
                        Bitmap bitmap6 = MuAlgorithm.ChangeWhite(solveBitmap, 128);
                        pictureBox3.Image = bitmap6;
                        solveBitmap = this.CopyPicture(bitmap6);
                        #endregion

                        #region 切割一块
                        Rectangle rec = new Rectangle();
                        rec.X = 30;
                        rec.Y = 0;
                        rec.Height = 50;
                        rec.Width = solveBitmap.Width - 30;
                        Bitmap bmg = solveBitmap.Clone(rec, solveBitmap.PixelFormat);
                        pictureBox4.Image = bmg;
                        solveBitmap = this.CopyPicture(bmg);
                        #endregion

                        #region  去掉干扰线
                        Bitmap middle = SolvePicture.ClearNoise(solveBitmap, 128, 3);
                        pictureBox5.Image = middle;
                        solveBitmap = this.CopyPicture(middle);
                        #endregion

                        #region 去掉小的连通域
                        Bitmap bit = MuAlgorithm.GetMainConnection(solveBitmap, 30);
                        pictureBox6.Image = bit;
                        solveBitmap = this.CopyPicture(solveBitmap);
                        #endregion

                        #region 标记干扰线
                        Bitmap bmp = MuAlgorithm.MarkLineOne(solveBitmap);
                        pictureBox7.Image = bmp;
                        solveBitmap = this.CopyPicture(solveBitmap);
                        #endregion

                        #region 去掉标记线
                        Bitmap dd = MuAlgorithm.RemoveRed(solveBitmap);
                        pictureBox8.Image = dd;
                        solveBitmap = this.CopyPicture(solveBitmap);
                        #endregion

                        #region 中值滤波
                        Bitmap bmpr = SolvePicture.MiddleFileter(solveBitmap, 128);
                        pictureBox14.Image = bmpr;
                        solveBitmap = this.CopyPicture(bmpr);
                        #endregion

                        #region 中值滤波过后清除一次干扰线
                        Bitmap clearMiddle = SolvePicture.ClearNoise(solveBitmap, 128, 3);
                        pictureBox5.Image = clearMiddle;
                        solveBitmap = this.CopyPicture(clearMiddle);
                        #endregion

                        #region 得到有效区域
                        Bitmap bitMap = SolvePicture.GetPictureValidByValue(solveBitmap, 128, 4);
                        pictureBox19.Image = bitMap;
                        solveBitmap = this.CopyPicture(bitMap);
                        #endregion

                        List<Bitmap> result = new List<Bitmap>();
                        List<Bitmap> bits = new List<Bitmap>();
                        Dictionary<string, List<Coordinate>> parts = MuAlgorithm.GetConnectDomain(solveBitmap);
                        allApartCount++;
                        if (parts.Count < 5)
                        {
                            foreach (KeyValuePair<string, List<Coordinate>> par in parts)
                            {
                                if (par.Value.Count > 50)
                                {
                                    Bitmap onre = new Bitmap(solveBitmap.Width, solveBitmap.Height);
                                    for (int i = 0; i < onre.Width; i++)
                                    {
                                        for (int j = 0; j < onre.Height; j++)
                                        {
                                            onre.SetPixel(i, j, Color.White);
                                        }
                                    }
                                    foreach (var cc in par.Value)
                                    {
                                        onre.SetPixel(cc.X, cc.Y, Color.Black);
                                    }

                                    bits.Add(onre);
                                }
                            }

                            Bitmap one1 = null;
                            Bitmap two1 = null;
                            Bitmap three1 = null;
                            Bitmap four1 = null;
                            if (bits.Count == 1)
                            {
                                one1 = SolvePicture.GetPictureValidByValue(bits[0], 128, 4);
                                label6.Text = one1.Width + ":" + one1.Height;
                                result.AddRange(SolvePicture.SplicPicture(one1, 4));
                            }


                            if (bits.Count == 2)
                            {
                                one1 = SolvePicture.GetPictureValidByValue(bits[0], 128, 4);
                                label6.Text = one1.Width + ":" + one1.Height;

                                two1 = SolvePicture.GetPictureValidByValue(bits[1], 128, 4);
                                label7.Text = two1.Width + ":" + two1.Height;

                                if (one.Width > 30 && two.Width > 30)
                                {
                                    result.AddRange(SolvePicture.SplicPicture(one1, 2));
                                    result.AddRange(SolvePicture.SplicPicture(two1, 2));
                                }
                                else if (one.Width < 30)
                                {
                                    result.Add(one1);
                                    result.AddRange(SolvePicture.SplicPicture(two1, 3));
                                }
                                else
                                {
                                    result.AddRange(SolvePicture.SplicPicture(one1, 3));
                                    result.Add(two1);
                                }
                            }

                            if (bits.Count == 3)
                            {
                                one1 = SolvePicture.GetPictureValidByValue(bits[0], 128, 4);
                                label6.Text = one1.Width + ":" + one1.Height;

                                two1 = SolvePicture.GetPictureValidByValue(bits[1], 128, 4);
                                label7.Text = two1.Width + ":" + two1.Height;

                                three1 = SolvePicture.GetPictureValidByValue(bits[2], 128, 4);
                                label8.Text = three1.Width + ":" + three1.Height;

                                if (one1.Width > 33 && one1.Width < 60)
                                {
                                    result.AddRange(SolvePicture.SplicPicture(one1, 2));
                                    result.Add(two1);
                                    result.Add(three1);
                                }

                                if (two1.Width > 33 && two1.Width < 60)
                                {
                                    result.Add(one1);
                                    result.AddRange(SolvePicture.SplicPicture(two1, 2));
                                    result.Add(three1);
                                }

                                if (three1.Width > 33 && three1.Width < 60)
                                {
                                    result.Add(one1);
                                    result.Add(two1);
                                    result.AddRange(SolvePicture.SplicPicture(three1, 2));
                                }

                            }

                            if (bits.Count == 4)
                            {
                                one1 = SolvePicture.GetPictureValidByValue(bits[0], 128, 4);
                                label6.Text = one1.Width + ":" + one1.Height;

                                two1 = SolvePicture.GetPictureValidByValue(bits[1], 128, 4);
                                label7.Text = two1.Width + ":" + two1.Height;

                                three1 = SolvePicture.GetPictureValidByValue(bits[2], 128, 4);
                                label8.Text = three1.Width + ":" + three1.Height;


                                four1 = SolvePicture.GetPictureValidByValue(bits[3], 128, 4);
                                label9.Text = four1.Width + ":" + four1.Height;
                                result.Add(one1);
                                result.Add(two1);
                                result.Add(three1);
                                result.Add(four1);
                            }

                            if (result.Count == 4)
                            {
                                pictureBox15.Image = result[0];
                                label6.Text = result[0].Width + ":" + result[0].Height;
                                pictureBox16.Image = result[1];
                                label7.Text = result[1].Width + ":" + result[1].Height;
                                pictureBox17.Image = result[2];
                                label8.Text = result[2].Width + ":" + result[2].Height;
                                pictureBox18.Image = result[3];
                                label9.Text = result[3].Width + ":" + result[3].Height;
                            }
                            else
                            {
                                MessageBox.Show("拆分有误");
                            }

                        }
                        else
                        {
                            MessageBox.Show("原来那一套思路分割");

                            // 走原来那一套
                            List<Rectangle> dd1 = SolvePicture.Split(solveBitmap, 30);
                            if (dd1.Count >= 4)
                            {
                                List<Bitmap> pictures = new List<Bitmap>();
                                List<Bitmap> del = new List<Bitmap>();

                                foreach (Rectangle rect in dd1)
                                {
                                    Bitmap tempBitmap = solveBitmap.Clone(rect, solveBitmap.PixelFormat);
                                    pictures.Add(tempBitmap);
                                }

                                // 去掉像素少的图片
                                foreach (var bb in pictures)
                                {
                                    int ssc = ChangeSmallAlgorithm.GetPixNumber(bb);
                                    if (ssc < 10)
                                    {
                                        del.Add(bb);
                                    }
                                }

                                foreach (var dddds in del)
                                {
                                    pictures.Remove(dddds);
                                }


                                // 去掉每一张图片中连通域较小的，尤其是第一个字符

                                pictures[1] = SolvePicture.ClearNoise(pictures[1], 128, 2);
                                pictures[2] = SolvePicture.ClearNoise(pictures[2], 128, 2);
                                pictures[3] = SolvePicture.ClearNoise(pictures[3], 128, 2);
                                pictures[0] = SolvePicture.ClearNoise(pictures[0], 128, 3);

                                pictureBox15.Image = ZoomAlgorithm.ReduceImage(SolvePicture.GetPictureValidByValue(pictures[0], 128, 4), 20, 20);
                                pictureBox16.Image = ZoomAlgorithm.ReduceImage(SolvePicture.GetPictureValidByValue(pictures[1], 128, 4), 20, 20);
                                pictureBox17.Image = ZoomAlgorithm.ReduceImage(SolvePicture.GetPictureValidByValue(pictures[2], 128, 4), 20, 20);
                                pictureBox18.Image = ZoomAlgorithm.ReduceImage(SolvePicture.GetPictureValidByValue(pictures[3], 128, 4), 20, 20);
                            }
                            else
                            {
                                MessageBox.Show("原来那一套拆分有问题");
                            }

                        }


                        //List<Bitmap> pictures = new List<Bitmap>();
                        //string ss = string.Empty;
                        //List<Bitmap> del = new List<Bitmap>();

                        //List<Rectangle> ddr = SolvePicture.Split(solveBitmap, 30);
                        //foreach (Rectangle rect in ddr)
                        //{
                        //    Bitmap tempBitmap = solveBitmap.Clone(rect, solveBitmap.PixelFormat);
                        //    pictures.Add(tempBitmap);
                        //}

                        //// 去掉像素少的图片
                        //foreach (var bb in pictures)
                        //{
                        //    int ssc = ChangeSmallAlgorithm.GetPixNumber(bb);
                        //    if (ssc < 10)
                        //    {
                        //        del.Add(bb);
                        //    }
                        //}

                        //foreach (var dddds in del)
                        //{
                        //    pictures.Remove(dddds);
                        //}


                        //if (pictures.Count == 4)
                        //{
                        //    //List<Bitmap> pictures = new List<Bitmap>();
                        //    //string ss = string.Empty;
                        //    //List<Bitmap> del = new List<Bitmap>();

                        //    //foreach (Rectangle rect in ddr)
                        //    //{
                        //    //    Bitmap tempBitmap = solveBitmap.Clone(rect, solveBitmap.PixelFormat);
                        //    //    pictures.Add(tempBitmap);
                        //    //}

                        //    // 去掉每一张图片中连通域较小的，尤其是第一个字符
                        //    pictures[0] = MuAlgorithm.GetMainConnection(pictures[0], 30);
                        //    pictures[1] = MuAlgorithm.GetMainConnection(pictures[1], 30);
                        //    pictures[2] = MuAlgorithm.GetMainConnection(pictures[2], 30);
                        //    pictures[3] = MuAlgorithm.GetMainConnection(pictures[3], 30);

                        //    one = ZoomAlgorithm.ReduceImage(SolvePicture.GetPictureValidByValue(pictures[0], 128, 4), 20, 20);
                        //    two = ZoomAlgorithm.ReduceImage(SolvePicture.GetPictureValidByValue(pictures[1], 128, 4), 20, 20);
                        //    three = ZoomAlgorithm.ReduceImage(SolvePicture.GetPictureValidByValue(pictures[2], 128, 4), 20, 20);
                        //    four = ZoomAlgorithm.ReduceImage(SolvePicture.GetPictureValidByValue(pictures[3], 128, 4), 20, 20);

                        //    pictureBox15.Image = one;
                        //    pictureBox16.Image = two;
                        //    pictureBox17.Image = three;
                        //    pictureBox18.Image = four;
                        //    if (one.Width != 20 && one.Height != 20)
                        //    {
                        //        int myone = 0;
                        //    }
                        //    if (two.Width != 20 && two.Height != 20)
                        //    {
                        //        int mytwo = 0;
                        //    }
                        //    if (three.Width != 20 && three.Height != 20)
                        //    {
                        //        int mythree = 0;
                        //    }
                        //    if (four.Width != 20 && four.Height != 20)
                        //    {
                        //        int myfour = 0;
                        //    }

                        //    allBitmap.Add(one);
                        //    allBitmap.Add(two);
                        //    allBitmap.Add(three);
                        //    allBitmap.Add(four);


                        //    int strLength = pictureName.Length;
                        //    for (int i = 0; i < strLength; i++)
                        //    {
                        //        string sts = pictureName.Substring(i, 1);
                        //        double[] dataOne = new double[35];
                        //        for (int j = 0; j < 35; j++)
                        //        {
                        //            dataOne[j] = 0.1f;
                        //        }

                        //        MOutputMappingValue mapp = mappingValues.Find(P => P.TeacherData == sts);
                        //        int xxx = Convert.ToInt32(mapp.MappingValue);
                        //        dataOne[xxx] = 0.9f;
                        //        tempData.Add(dataOne);
                        //    }
                        //}

                    }
                    catch (Exception ex)
                    {
                        //allBitmap.Remove(one);
                        //allBitmap.Remove(two);
                        //allBitmap.Remove(three);
                        //allBitmap.Remove(four);
                    }

                }

                MessageBox.Show("训练完毕");
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            List<Bitmap> result = new List<Bitmap>();
            List<Bitmap> bits = new List<Bitmap>();
            Dictionary<string, List<Coordinate>> parts = MuAlgorithm.GetConnectDomain(solveBitmap);

            if (parts.Count < 5)
            {
                foreach (KeyValuePair<string, List<Coordinate>> par in parts)
                {
                    if (par.Value.Count > 50)
                    {
                        Bitmap onre = new Bitmap(solveBitmap.Width, solveBitmap.Height);
                        for (int i = 0; i < onre.Width; i++)
                        {
                            for (int j = 0; j < onre.Height; j++)
                            {
                                onre.SetPixel(i, j, Color.White);
                            }
                        }
                        foreach (var cc in par.Value)
                        {
                            onre.SetPixel(cc.X, cc.Y, Color.Black);
                        }

                        bits.Add(onre);
                    }
                }

                Bitmap one = null;
                Bitmap two = null;
                Bitmap three = null;
                Bitmap four = null;
                if (bits.Count == 1)
                {
                    one = SolvePicture.GetPictureValidByValue(bits[0], 128, 4);
                    label6.Text = one.Width + ":" + one.Height;
                    result.AddRange(SolvePicture.SplicPicture(one, 4));
                }


                if (bits.Count == 2)
                {
                    one = SolvePicture.GetPictureValidByValue(bits[0], 128, 4);
                    label6.Text = one.Width + ":" + one.Height;

                    two = SolvePicture.GetPictureValidByValue(bits[1], 128, 4);
                    label7.Text = two.Width + ":" + two.Height;

                    if (one.Width > 30 && two.Width > 30)
                    {
                        result.AddRange(SolvePicture.SplicPicture(one, 2));
                        result.AddRange(SolvePicture.SplicPicture(two, 2));
                    }
                    else if (one.Width < 30)
                    {
                        result.Add(one);
                        result.AddRange(SolvePicture.SplicPicture(two, 3));
                    }
                    else
                    {
                        result.AddRange(SolvePicture.SplicPicture(one, 3));
                        result.Add(two);
                    }
                }

                if (bits.Count == 3)
                {
                    one = SolvePicture.GetPictureValidByValue(bits[0], 128, 4);
                    label6.Text = one.Width + ":" + one.Height;

                    two = SolvePicture.GetPictureValidByValue(bits[1], 128, 4);
                    label7.Text = two.Width + ":" + two.Height;

                    three = SolvePicture.GetPictureValidByValue(bits[2], 128, 4);
                    label8.Text = three.Width + ":" + three.Height;

                    if (one.Width > 33 && one.Width < 60)
                    {
                        result.AddRange(SolvePicture.SplicPicture(one, 2));
                        result.Add(two);
                        result.Add(three);
                    }

                    if (two.Width > 33 && two.Width < 60)
                    {
                        result.Add(one);
                        result.AddRange(SolvePicture.SplicPicture(two, 2));
                        result.Add(three);
                    }

                    if (three.Width > 33 && three.Width < 60)
                    {
                        result.Add(one);
                        result.Add(two);
                        result.AddRange(SolvePicture.SplicPicture(three, 2));
                    }

                }

                if (bits.Count == 4)
                {
                    one = SolvePicture.GetPictureValidByValue(bits[0], 128, 4);
                    label6.Text = one.Width + ":" + one.Height;

                    two = SolvePicture.GetPictureValidByValue(bits[1], 128, 4);
                    label7.Text = two.Width + ":" + two.Height;

                    three = SolvePicture.GetPictureValidByValue(bits[2], 128, 4);
                    label8.Text = three.Width + ":" + three.Height;


                    four = SolvePicture.GetPictureValidByValue(bits[3], 128, 4);
                    label9.Text = four.Width + ":" + four.Height;
                    result.Add(one);
                    result.Add(two);
                    result.Add(three);
                    result.Add(four);
                }

                if (result.Count == 4)
                {
                    pictureBox15.Image = result[0];
                    label6.Text = result[0].Width + ":" + result[0].Height;
                    pictureBox16.Image = result[1];
                    label7.Text = result[1].Width + ":" + result[1].Height;
                    pictureBox17.Image = result[2];
                    label8.Text = result[2].Width + ":" + result[2].Height;
                    pictureBox18.Image = result[3];
                    label9.Text = result[3].Width + ":" + result[3].Height;
                }
                else
                {
                    MessageBox.Show("拆分有误");
                }

            }
            else
            {
                MessageBox.Show("原来那一套思路分割");
                // 走原来那一套
                List<Rectangle> dd = SolvePicture.Split(solveBitmap, 30);
                if (dd.Count >= 4)
                {
                    List<Bitmap> pictures = new List<Bitmap>();
                    List<Bitmap> del = new List<Bitmap>();

                    foreach (Rectangle rect in dd)
                    {
                        Bitmap tempBitmap = solveBitmap.Clone(rect, solveBitmap.PixelFormat);
                        pictures.Add(tempBitmap);
                    }

                    // 去掉像素少的图片
                    foreach (var bb in pictures)
                    {
                        int ssc = ChangeSmallAlgorithm.GetPixNumber(bb);
                        if (ssc < 10)
                        {
                            del.Add(bb);
                        }
                    }

                    foreach (var dddds in del)
                    {
                        pictures.Remove(dddds);
                    }


                    // 去掉每一张图片中连通域较小的，尤其是第一个字符

                    pictures[1] = SolvePicture.ClearNoise(pictures[1], 128, 2);
                    pictures[2] = SolvePicture.ClearNoise(pictures[2], 128, 2);
                    pictures[3] = SolvePicture.ClearNoise(pictures[3], 128, 2);
                    pictures[0] = SolvePicture.ClearNoise(pictures[0], 128, 3);

                    pictureBox15.Image = ZoomAlgorithm.ReduceImage(SolvePicture.GetPictureValidByValue(pictures[0], 128, 4), 20, 20);
                    pictureBox16.Image = ZoomAlgorithm.ReduceImage(SolvePicture.GetPictureValidByValue(pictures[1], 128, 4), 20, 20);
                    pictureBox17.Image = ZoomAlgorithm.ReduceImage(SolvePicture.GetPictureValidByValue(pictures[2], 128, 4), 20, 20);
                    pictureBox18.Image = ZoomAlgorithm.ReduceImage(SolvePicture.GetPictureValidByValue(pictures[3], 128, 4), 20, 20);
                }
                else
                {
                    MessageBox.Show("原来那一套拆分有问题");
                }

            }




        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button13_Click(object sender, EventArgs e)
        {
            //Bitmap bitmap = solveBitmap;
            Bitmap bitmap = solveBitmap;
            KirschAlgorithm kirsch = new KirschAlgorithm(bitmap);
            bitmap = kirsch.ExtractOutLine(500);
            pictureBox10.Image = bitmap;
            solveBitmap = this.CopyPicture(bitmap);
            solveBitmap.Save("E:\\YU.png");
        }

        private void button14_Click(object sender, EventArgs e)
        {

        }

        private void button15_Click(object sender, EventArgs e)
        {

        }

        private void button14_Click_1(object sender, EventArgs e)
        {
            List<Bitmap> result = new List<Bitmap>();
            List<Bitmap> bits = new List<Bitmap>();
            Dictionary<string, List<Coordinate>> parts = MuAlgorithm.GetConnectDomain(solveBitmap);
            allApartCount++;
            if (parts.Count < 5)
            {
                foreach (KeyValuePair<string, List<Coordinate>> par in parts)
                {
                    if (par.Value.Count > 50)
                    {
                        Bitmap onre = new Bitmap(solveBitmap.Width, solveBitmap.Height);
                        for (int i = 0; i < onre.Width; i++)
                        {
                            for (int j = 0; j < onre.Height; j++)
                            {
                                onre.SetPixel(i, j, Color.White);
                            }
                        }
                        foreach (var cc in par.Value)
                        {
                            onre.SetPixel(cc.X, cc.Y, Color.Black);
                        }

                        bits.Add(onre);
                    }
                }

                Bitmap one = null;
                Bitmap two = null;
                Bitmap three = null;
                Bitmap four = null;
                if (bits.Count == 1)
                {
                    one = SolvePicture.GetPictureValidByValue(bits[0], 128, 4);
                    label6.Text = one.Width + ":" + one.Height;
                    result.AddRange(SolvePicture.SplicPicture(one, 4));
                }


                if (bits.Count == 2)
                {
                    one = SolvePicture.GetPictureValidByValue(bits[0], 128, 4);
                    label6.Text = one.Width + ":" + one.Height;

                    two = SolvePicture.GetPictureValidByValue(bits[1], 128, 4);
                    label7.Text = two.Width + ":" + two.Height;

                    if (one.Width > 30 && two.Width > 30)
                    {
                        result.AddRange(SolvePicture.SplicPicture(one, 2));
                        result.AddRange(SolvePicture.SplicPicture(two, 2));
                    }
                    else if (one.Width < 30)
                    {
                        result.Add(one);
                        result.AddRange(SolvePicture.SplicPicture(two, 3));
                    }
                    else
                    {
                        result.AddRange(SolvePicture.SplicPicture(one, 3));
                        result.Add(two);
                    }
                }

                if (bits.Count == 3)
                {
                    one = SolvePicture.GetPictureValidByValue(bits[0], 128, 4);
                    label6.Text = one.Width + ":" + one.Height;

                    two = SolvePicture.GetPictureValidByValue(bits[1], 128, 4);
                    label7.Text = two.Width + ":" + two.Height;

                    three = SolvePicture.GetPictureValidByValue(bits[2], 128, 4);
                    label8.Text = three.Width + ":" + three.Height;

                    if (one.Width > 33 && one.Width < 60)
                    {
                        result.AddRange(SolvePicture.SplicPicture(one, 2));
                        result.Add(two);
                        result.Add(three);
                    }

                    if (two.Width > 33 && two.Width < 60)
                    {
                        result.Add(one);
                        result.AddRange(SolvePicture.SplicPicture(two, 2));
                        result.Add(three);
                    }

                    if (three.Width > 33 && three.Width < 60)
                    {
                        result.Add(one);
                        result.Add(two);
                        result.AddRange(SolvePicture.SplicPicture(three, 2));
                    }

                }

                if (bits.Count == 4)
                {
                    one = SolvePicture.GetPictureValidByValue(bits[0], 128, 4);
                    label6.Text = one.Width + ":" + one.Height;

                    two = SolvePicture.GetPictureValidByValue(bits[1], 128, 4);
                    label7.Text = two.Width + ":" + two.Height;

                    three = SolvePicture.GetPictureValidByValue(bits[2], 128, 4);
                    label8.Text = three.Width + ":" + three.Height;


                    four = SolvePicture.GetPictureValidByValue(bits[3], 128, 4);
                    label9.Text = four.Width + ":" + four.Height;
                    result.Add(one);
                    result.Add(two);
                    result.Add(three);
                    result.Add(four);
                }

                if (result.Count == 4)
                {
                    pictureBox15.Image = result[0];
                    label6.Text = result[0].Width + ":" + result[0].Height;
                    pictureBox16.Image = result[1];
                    label7.Text = result[1].Width + ":" + result[1].Height;
                    pictureBox17.Image = result[2];
                    label8.Text = result[2].Width + ":" + result[2].Height;
                    pictureBox18.Image = result[3];
                    label9.Text = result[3].Width + ":" + result[3].Height;
                }
                else
                {
                    MessageBox.Show("拆分有误");
                }

            }
            else
            {
                MessageBox.Show("原来那一套思路分割");

                // 走原来那一套
                List<Rectangle> dd = SolvePicture.Split(solveBitmap, 30);
                if (dd.Count >= 4)
                {
                    List<Bitmap> pictures = new List<Bitmap>();
                    List<Bitmap> del = new List<Bitmap>();

                    foreach (Rectangle rect in dd)
                    {
                        Bitmap tempBitmap = solveBitmap.Clone(rect, solveBitmap.PixelFormat);
                        pictures.Add(tempBitmap);
                    }

                    // 去掉像素少的图片
                    foreach (var bb in pictures)
                    {
                        int ssc = ChangeSmallAlgorithm.GetPixNumber(bb);
                        if (ssc < 10)
                        {
                            del.Add(bb);
                        }
                    }

                    foreach (var dddds in del)
                    {
                        pictures.Remove(dddds);
                    }


                    // 去掉每一张图片中连通域较小的，尤其是第一个字符

                    pictures[1] = SolvePicture.ClearNoise(pictures[1], 128, 2);
                    pictures[2] = SolvePicture.ClearNoise(pictures[2], 128, 2);
                    pictures[3] = SolvePicture.ClearNoise(pictures[3], 128, 2);
                    pictures[0] = SolvePicture.ClearNoise(pictures[0], 128, 3);

                    pictureBox15.Image = ZoomAlgorithm.ReduceImage(SolvePicture.GetPictureValidByValue(pictures[0], 128, 4), 20, 20);
                    pictureBox16.Image = ZoomAlgorithm.ReduceImage(SolvePicture.GetPictureValidByValue(pictures[1], 128, 4), 20, 20);
                    pictureBox17.Image = ZoomAlgorithm.ReduceImage(SolvePicture.GetPictureValidByValue(pictures[2], 128, 4), 20, 20);
                    pictureBox18.Image = ZoomAlgorithm.ReduceImage(SolvePicture.GetPictureValidByValue(pictures[3], 128, 4), 20, 20);
                }
                else
                {
                    MessageBox.Show("原来那一套拆分有问题");
                }

            }


        }

        private void button15_Click_1(object sender, EventArgs e)
        {
            apartCount++;
            textBox11.Text = apartCount.ToString() + ":" + allApartCount.ToString();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            VerficationCodeParamOperate operate = new VerficationCodeParamOperate();
            mappingValues = operate.GetMappingValue("MU_B2C");
            try
            {
                FolderBrowserDialog fbd = new FolderBrowserDialog();
                fbd.Description = "请选择一个目录.";
                if (fbd.ShowDialog() == DialogResult.OK)
                {
                    string[] PicPaht = Directory.GetFiles(fbd.SelectedPath, "*.png");
                    for (int m = 0; m < PicPaht.Length; m++)
                    {
                        List<Bitmap> result = new List<Bitmap>();
                        Bitmap bitmap = (Bitmap)Image.FromFile(PicPaht[m]);
                        string pictureName = PicPaht[m].Split('\\')[3].Split('.')[0];
                        List<Bitmap> bitMaps = new List<Bitmap>();
                        try
                        {
                            // 图片预处理
                            Bitmap grayBitMap = BinaryzationAlgorithm.CVThreshold(bitmap);
                            grayBitMap = SolvePicture.ClearNoise(grayBitMap, 128, 3);
                            Bitmap bitMaptwo = SolvePicture.MiddleFileter(grayBitMap, 128);
                            bitMaptwo = SolvePicture.GetPictureValidByValue(bitMaptwo, 4);
                            List<Rectangle> dd = SolvePicture.Split(bitMaptwo, 30);
                            List<Bitmap> pictures = new List<Bitmap>();
                            string ss = string.Empty;
                            foreach (var temp in dd)
                            {
                                Bitmap newImage = bitMaptwo.Clone(temp, bitMaptwo.PixelFormat);
                                pictures.Add(newImage);
                            }
                            if (pictures.Count == 4)
                            {
                                try
                                {
                                    pictures[0] = SolvePicture.GetPictureValidByValue(pictures[0], 4);
                                    pictures[0] = ZoomAlgorithm.ReduceImage(pictures[0], 20, 20);

                                    pictures[1] = SolvePicture.GetPictureValidByValue(pictures[1], 4);
                                    pictures[1] = ZoomAlgorithm.ReduceImage(pictures[1], 20, 20);

                                    pictures[2] = SolvePicture.GetPictureValidByValue(pictures[2], 4);
                                    pictures[2] = ZoomAlgorithm.ReduceImage(pictures[2], 20, 20);

                                    pictures[3] = SolvePicture.GetPictureValidByValue(pictures[3], 4);
                                    pictures[3] = ZoomAlgorithm.ReduceImage(pictures[3], 20, 20);
                                    allBitmap.AddRange(pictures);
                                    int strLength = pictureName.Length;
                                    for (int i = 0; i < strLength; i++)
                                    {
                                        string sts = pictureName.Substring(i, 1);
                                        double[] dataOne = new double[36];
                                        for (int j = 0; j < 36; j++)
                                        {
                                            dataOne[j] = 0.1f;
                                        }

                                        MOutputMappingValue mapp = mappingValues.Find(P => P.TeacherData == sts);
                                        int xxx = Convert.ToInt32(mapp.MappingValue);
                                        dataOne[xxx] = 0.9f;
                                        tempData.Add(dataOne);
                                    }
                                }
                                catch (Exception EX)
                                {
                                    int CC = 0;
                                }
                            }

                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("吃掉一个异常");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("加载图片异常");
            }

            MessageBox.Show("加载完成");
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            Bitmap bb = ZoomAlgorithm.ReduceImage(solveBitmap, 50, 50);
            pictureBox17.Image = bb;
        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            Bitmap bitMap = SolvePicture.ClearNoise(solveBitmap, 128, 3);
            pictureBox4.Image = bitMap;
            solveBitmap = this.CopyPicture(bitMap);
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            save.Save(string.Format("E:\\AllPictures\\MUE_C\\{0}.png", name));
        }

        private void button9_Click_1(object sender, EventArgs e)
        {
            Bitmap two = SolvePicture.BitmapToAverage(solveBitmap, 100, 200);
            pictureBox3.Image = two;
            solveBitmap = this.CopyPicture(two);
        }

        private void button10_Click_1(object sender, EventArgs e)
        {
            Bitmap sharpen = SolvePicture.Sharpen(solveBitmap, 0.2f);
            pictureBox5.Image = sharpen;
            solveBitmap = this.CopyPicture(sharpen);
        }

        private void button17_Click(object sender, EventArgs e)
        {
            Bitmap mid = SolvePicture.MiddleFileter(solveBitmap, 128);
            pictureBox8.Image = mid;
            solveBitmap = this.CopyPicture(mid);
        }

        private void button17_Click_1(object sender, EventArgs e)
        {
            Bitmap bigPic = ZoomAlgorithm.ReduceImage(solveBitmap, 100, 100);
            pictureBox20.Image = bigPic;
            solveBitmap = this.CopyPicture(bigPic);
        }

        private void button9_Click_2(object sender, EventArgs e)
        {
            //solveBitmap = SolvePicture.ClearNoise(solveBitmap, 128, 3);
            Bitmap validRegion = SolvePicture.GetPictureValidByValue(solveBitmap, 4);
            //////把图片统一大小调整为52*15,因为
            //validRegion = this.CopyPicture(validRegion);



            pictureBox8.Image = validRegion;
            solveBitmap = this.CopyPicture(validRegion);
            //solveBitmap.Save(string.Format("E:\\99bill\\validRegion\\{0}.jpg", Guid.NewGuid().ToString()));
        }

        private static Bitmap test = null;
        private void button8_Click_2(object sender, EventArgs e)
        {
            Bitmap b = (Bitmap)Image.FromFile("E:\\ff.jpg");
            pictureBox8.Image = b;
            test = this.CopyPicture(b);
        }

        private void button10_Click_2(object sender, EventArgs e)
        {
            Bitmap cc = SolvePicture.ClearNoise(test, 128, 2);
            pictureBox9.Image = cc;
            test = this.CopyPicture(cc);
        }

        private void button18_Click(object sender, EventArgs e)
        {
            Bitmap tt = SolvePicture.GetPictureValidByValue(test, 4);
            tt = ZoomAlgorithm.ReduceImage(tt, 10, 15);
            pictureBox19.Image = tt;
            test = this.CopyPicture(tt);
        }

        private void button20_Click(object sender, EventArgs e)
        {
            Bitmap CC = this.CopyPicture(solveBitmap);
            Bitmap gg = this.GetValidRegion(CC, 20);
            gg = SolvePicture.ClearNoise(gg, 128, 2);
            gg = SolvePicture.GetPictureValidByValue(gg, 4);
            gg.Save("E:\\FCD.JPG");
            pictureBox14.Image = gg;
        }

        public Bitmap InitBitMap(int width, int heigth)
        {
            Bitmap newBitmap = new Bitmap(width, heigth);
            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < heigth; j++)
                {
                    newBitmap.SetPixel(i, j, Color.White);
                }
            }

            return newBitmap;
        }

        public List<Bitmap> AverageSplit(Bitmap bitMap)
        {
            List<Bitmap> resultBitmap = new List<Bitmap>();
            int width = bitMap.Width;
            int height = bitMap.Height;
            int tempWidth = width / 3;
            for (int i = 0; i < 3; i++)
            {
                Bitmap tempBitmap = this.InitBitMap(width, height);
                int tempStart = i * tempWidth;
                int tempEnd = (i + 1) * tempWidth;
                for (int j = tempStart; j < tempEnd; j++)
                {
                    for (int m = 0; m < height; m++)
                    {
                        Color color = bitMap.GetPixel(j, m);
                        tempBitmap.SetPixel(j, m, color);
                    }
                }

                resultBitmap.Add(tempBitmap);
            }

            return resultBitmap;
        }

        private void button16_Click_1(object sender, EventArgs e)
        {
            VerficationCodeParamOperate operate = new VerficationCodeParamOperate();
            //mappingValues = operate.GetMappingValue("crossTravel");
            mappingValues = operate.GetMappingValue("ChinaPnRV");
            try
            {
                FolderBrowserDialog openDiag = new FolderBrowserDialog();
                openDiag.Description = "请选择一个目录";
                if (openDiag.ShowDialog() == DialogResult.OK)
                {
                    string[] PicPaht = Directory.GetFiles(openDiag.SelectedPath, "*.png");
                    for (int m = 0; m < PicPaht.Length; m++)
                    {
                        try
                        {
                            string pictureName = Path.GetFileName(PicPaht[m]);// PicPaht[m].Split('\\')[4].Split('.')[0];
                            Bitmap bitmap = (Bitmap)Image.FromFile(PicPaht[m]);


                            //// 灰度化处理
                            Bitmap tempBitmaponehdh = GrayAlgorithm.AverageGray(bitmap);
                            tempBitmaponehdh.Save(string.Format("E:/veryzhunma/处理后图片Flighth/60_25{0}", pictureName), System.Drawing.Imaging.ImageFormat.Jpeg);
                            Bitmap grayBitMap = BinaryzationAlgorithm.CVThreshold(tempBitmaponehdh);
                            pictureBox1.Image = grayBitMap;
                            grayBitMap.Save(string.Format("E:/veryzhunma/处理后图片Flight/{0}", pictureName), System.Drawing.Imaging.ImageFormat.Jpeg);
                            #region 新增图片切割

                            //// 获取图片列有效列像素点数
                            Bitmap binarizationBitMap = grayBitMap;
                            List<int> bitMapVolumnNumList = new List<int>();
                            for (int i = 0; i < binarizationBitMap.Width; i++)
                            {
                                int bitMapVolumnNum = 0;
                                for (int j = 0; j < binarizationBitMap.Height; j++)
                                {
                                    Color c = binarizationBitMap.GetPixel(i, j);
                                    if (binarizationBitMap.GetPixel(i, j).R == Color.Black.R)
                                    {
                                        bitMapVolumnNum++;
                                    }
                                }

                                bitMapVolumnNumList.Add(bitMapVolumnNum);
                            }

                            ////将有效像素点区域值保存
                            List<Rectangle> validPixelList = new List<Rectangle>();
                            bool isFirstCut = true;
                            Rectangle rect = new Rectangle();
                            for (int i = 0; i < bitMapVolumnNumList.Count; i++)
                            {
                                if (isFirstCut)
                                {
                                    if (bitMapVolumnNumList[i] > 0)
                                    {
                                        rect = new Rectangle();
                                        rect.Y = 0;
                                        rect.X = i;
                                        rect.Height = binarizationBitMap.Height;
                                        isFirstCut = false;
                                    }
                                }
                                else
                                {
                                    ////每个字符最后切割点
                                    if (bitMapVolumnNumList[i] == 0)
                                    {
                                        rect.Width = i - rect.X;
                                        isFirstCut = true;
                                        validPixelList.Add(rect);
                                    }
                                }

                            }

                            //// 根据字符区域切割图片并保存
                            List<Bitmap> pictures = new List<Bitmap>();
                            foreach (Rectangle rectangle in validPixelList)
                            {
                                Bitmap tempBitmap = binarizationBitMap.Clone(rectangle, binarizationBitMap.PixelFormat);
                                tempBitmap = SolvePicture.GetPictureValidByValue(tempBitmap, 4);
                                tempBitmap = ZoomAlgorithm.ReduceImage(tempBitmap, 10, 10);
                                pictures.Add(tempBitmap);

                            }
                            #endregion
                            allBitmap.AddRange(pictures);
                            int strLength = pictureName.Split('.')[0].Length;
                            for (int i = 0; i < strLength; i++)
                            {
                                string sts = pictureName.Substring(i, 1);
                                double[] dataOne = new double[13];
                                for (int j = 0; j < 13; j++)
                                {
                                    dataOne[j] = 0.1f;
                                }

                                MOutputMappingValue mapp = mappingValues.Find(P => P.TeacherData == sts);
                                int xxx = Convert.ToInt32(mapp.MappingValue);
                                dataOne[xxx] = 0.9f;
                                tempData.Add(dataOne);
                            }
                        }
                        catch (Exception ex)
                        {
                            ////一张图片出了问题，不影响整个加载流程
                            MessageBox.Show("处理异常");
                        }
                    }

                    MessageBox.Show("处理完成");
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void button21_Click(object sender, EventArgs e)
        {
            //// 获取图片列有效列像素点数
            Bitmap binarizationBitMap = (Bitmap)this.pictureBox2.Image;
            List<int> bitMapVolumnNumList = new List<int>();
            for (int i = 0; i < binarizationBitMap.Width; i++)
            {
                int bitMapVolumnNum = 0;
                for (int j = 0; j < binarizationBitMap.Height; j++)
                {
                    Color c = binarizationBitMap.GetPixel(i, j);
                    if (binarizationBitMap.GetPixel(i, j).R == Color.Black.R)
                    {
                        bitMapVolumnNum++;
                    }
                }

                bitMapVolumnNumList.Add(bitMapVolumnNum);
            }

            ////将有效像素点区域值保存
            List<Rectangle> validPixelList = new List<Rectangle>();
            bool isFirstCut = true;
            Rectangle rect = new Rectangle();
            for (int i = 0; i < bitMapVolumnNumList.Count; i++)
            {
                if (isFirstCut)
                {
                    if (bitMapVolumnNumList[i] > 0)
                    {
                        rect = new Rectangle();
                        rect.Y = 0;
                        rect.X = i;
                        rect.Height = binarizationBitMap.Height;
                        isFirstCut = false;
                    }
                }
                else
                {
                    if (validPixelList.Count == 6)
                    {
                        rect.Width = binarizationBitMap.Width - rect.X;
                        isFirstCut = true;
                        validPixelList.Add(rect);
                        break;
                    }

                    ////每个字符最后切割点
                    if (bitMapVolumnNumList[i] == 0)
                    {
                        rect.Width = i - rect.X;
                        isFirstCut = true;
                        validPixelList.Add(rect);
                    }

                }

            }

            //// 根据字符区域切割图片并保存
            List<Bitmap> pictures = new List<Bitmap>();
            List<PictureBox> pictureBoxList = new List<PictureBox>();
            foreach (Rectangle rectangle in validPixelList)
            {
                int i = 3;
                Bitmap tempBitmap = binarizationBitMap.Clone(rectangle, binarizationBitMap.PixelFormat);
                tempBitmap = SolvePicture.GetPictureValidByValue(tempBitmap, 4);
                tempBitmap = ZoomAlgorithm.ReduceImage(tempBitmap, 10, 10);
                pictures.Add(tempBitmap);
            }

            pictureBox9.Image = pictures[0];
            pictureBox19.Image = pictures[1];
            pictureBox17.Image = pictures[2];
            pictureBox18.Image = pictures[3];
            if (pictures.Count >= 6)
            {
                pictureBox14.Image = pictures[6];
            }

        }

        private void button21_Click_1(object sender, EventArgs e)
        {

        }
    }
}
