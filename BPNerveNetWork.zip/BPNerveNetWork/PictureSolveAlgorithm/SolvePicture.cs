﻿//-----------------------------------------------------------------------
// <copyright file="SolvePicture.cs" company="517Na Enterprises">
// * Copyright (C) 2014 517Na科技有限公司 版权所有。
// * version : 2.0.50727.5477
// * author  : xukong
// * FileName: SolvePicture.cs
// * history : created by xukong 2014/12/2 08:53:23 
// </copyright>
//-----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Text;
using System.Linq;

namespace PictureSolveAlgorithm
{
    /// <summary>
    /// 处理图片
    /// </summary>
    public class SolvePicture
    {
        /// <summary>
        /// 灰度转换,逐点方式
        /// </summary>
        public Bitmap GrayConvert(Bitmap bitMap)
        {
            for (int i = 0; i < bitMap.Height; i++)
            {
                for (int j = 0; j < bitMap.Width; j++)
                {
                    //int tmpValue = this.GetGrayNumColor(bitMap.GetPixel(j, i));
                    int tmpValue = 0;
                    bitMap.SetPixel(j, i, Color.FromArgb(tmpValue, tmpValue, tmpValue));
                }
            }

            return bitMap;
        }

        public static Bitmap BitmapToAverage(Bitmap bmpobj, int grayMin, int grayMax)
        {
            int w = bmpobj.Width;
            int h = bmpobj.Height;
            for (int y = 1; y < h - 1; y++)
            {
                for (int x = 1; x < w - 1; x++)
                {
                    Color c = bmpobj.GetPixel(x, y);
                    if (GetGrayNumColor(c) < grayMax && GetGrayNumColor(c) > grayMin)
                    {
                        byte r = Convert.ToByte((bmpobj.GetPixel(x - 1, y - 1).R + bmpobj.GetPixel(x - 1, y).R + bmpobj.GetPixel(x - 1, y + 1).R + bmpobj.GetPixel(x, y - 1).R + bmpobj.GetPixel(x, y + 1).R + bmpobj.GetPixel(x + 1, y - 1).R + bmpobj.GetPixel(x + 1, y).R + bmpobj.GetPixel(x + 1, y + 1).R) / 8);
                        byte g = Convert.ToByte((bmpobj.GetPixel(x - 1, y - 1).G + bmpobj.GetPixel(x - 1, y).G + bmpobj.GetPixel(x - 1, y + 1).G + bmpobj.GetPixel(x, y - 1).G + bmpobj.GetPixel(x, y + 1).G + bmpobj.GetPixel(x + 1, y - 1).G + bmpobj.GetPixel(x + 1, y).G + bmpobj.GetPixel(x + 1, y + 1).G) / 8);
                        byte b = Convert.ToByte((bmpobj.GetPixel(x - 1, y - 1).B + bmpobj.GetPixel(x - 1, y).B + bmpobj.GetPixel(x - 1, y + 1).B + bmpobj.GetPixel(x, y - 1).B + bmpobj.GetPixel(x, y + 1).B + bmpobj.GetPixel(x + 1, y - 1).B + bmpobj.GetPixel(x + 1, y).B + bmpobj.GetPixel(x + 1, y + 1).G) / 8);
                        bmpobj.SetPixel(x, y, Color.FromArgb(r, g, b));
                    }
                }
            }

            return bmpobj;
        }


        /// <summary>
        /// 锐化--要启用不安全代码编译
        /// </summary>
        /// <param name="b">原始Bitmap</param>
        /// <param name="val">锐化程度。取值[0,1]。值越大锐化程度越高</param>
        /// <returns>锐化后的图像</returns>
        public static Bitmap Sharpen(Bitmap b, float val)
        {
            if (b == null)
            {
                return null;
            }

            int w = b.Width;
            int h = b.Height;

            try
            {
                Bitmap bmpRtn = new Bitmap(w, h, PixelFormat.Format24bppRgb);

                BitmapData srcData = b.LockBits(new Rectangle(0, 0, w, h), ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);
                BitmapData dstData = bmpRtn.LockBits(new Rectangle(0, 0, w, h), ImageLockMode.WriteOnly, PixelFormat.Format24bppRgb);

                unsafe
                {
                    byte* pIn = (byte*)srcData.Scan0.ToPointer();
                    byte* pOut = (byte*)dstData.Scan0.ToPointer();
                    int stride = srcData.Stride;
                    byte* p;

                    for (int y = 0; y < h; y++)
                    {
                        for (int x = 0; x < w; x++)
                        {
                            //取周围9点的值。位于边缘上的点不做改变。
                            if (x == 0 || x == w - 1 || y == 0 || y == h - 1)
                            {
                                //不做
                                pOut[0] = pIn[0];
                                pOut[1] = pIn[1];
                                pOut[2] = pIn[2];
                            }
                            else
                            {
                                int r1, r2, r3, r4, r5, r6, r7, r8, r0;
                                int g1, g2, g3, g4, g5, g6, g7, g8, g0;
                                int b1, b2, b3, b4, b5, b6, b7, b8, b0;

                                float vR, vG, vB;

                                //左上
                                p = pIn - stride - 3;
                                r1 = p[2];
                                g1 = p[1];
                                b1 = p[0];

                                //正上
                                p = pIn - stride;
                                r2 = p[2];
                                g2 = p[1];
                                b2 = p[0];

                                //右上
                                p = pIn - stride + 3;
                                r3 = p[2];
                                g3 = p[1];
                                b3 = p[0];

                                //左侧
                                p = pIn - 3;
                                r4 = p[2];
                                g4 = p[1];
                                b4 = p[0];

                                //右侧
                                p = pIn + 3;
                                r5 = p[2];
                                g5 = p[1];
                                b5 = p[0];

                                //右下
                                p = pIn + stride - 3;
                                r6 = p[2];
                                g6 = p[1];
                                b6 = p[0];

                                //正下
                                p = pIn + stride;
                                r7 = p[2];
                                g7 = p[1];
                                b7 = p[0];

                                //右下
                                p = pIn + stride + 3;
                                r8 = p[2];
                                g8 = p[1];
                                b8 = p[0];

                                //自己
                                p = pIn;
                                r0 = p[2];
                                g0 = p[1];
                                b0 = p[0];

                                vR = (float)r0 - (float)(r1 + r2 + r3 + r4 + r5 + r6 + r7 + r8) / 8;
                                vG = (float)g0 - (float)(g1 + g2 + g3 + g4 + g5 + g6 + g7 + g8) / 8;
                                vB = (float)b0 - (float)(b1 + b2 + b3 + b4 + b5 + b6 + b7 + b8) / 8;

                                vR = r0 + vR * val;
                                vG = g0 + vG * val;
                                vB = b0 + vB * val;

                                if (vR > 0)
                                {
                                    vR = Math.Min(255, vR);
                                }
                                else
                                {
                                    vR = Math.Max(0, vR);
                                }

                                if (vG > 0)
                                {
                                    vG = Math.Min(255, vG);
                                }
                                else
                                {
                                    vG = Math.Max(0, vG);
                                }

                                if (vB > 0)
                                {
                                    vB = Math.Min(255, vB);
                                }
                                else
                                {
                                    vB = Math.Max(0, vB);
                                }

                                pOut[0] = (byte)vB;
                                pOut[1] = (byte)vG;
                                pOut[2] = (byte)vR;

                            }

                            pIn += 3;
                            pOut += 3;
                        }// end of x

                        pIn += srcData.Stride - w * 3;
                        pOut += srcData.Stride - w * 3;
                    } // end of y
                }

                b.UnlockBits(srcData);
                bmpRtn.UnlockBits(dstData);

                return bmpRtn;
            }
            catch
            {
                return null;
            }

        } // end of KiSharpen

        public static Bitmap BitmapToBalackAndWrite(Bitmap bmpobj, Double hsb)
        {
            int w = bmpobj.Width;
            int h = bmpobj.Height;
            Bitmap bmp = new Bitmap(w, h, PixelFormat.Format1bppIndexed);
            BitmapData data = bmp.LockBits(new Rectangle(0, 0, w, h), ImageLockMode.ReadWrite, PixelFormat.Format1bppIndexed);
            for (int y = 0; y < h; y++)
            {
                byte[] scan = new byte[(w + 7) / 8];
                for (int x = 0; x < w; x++)
                {
                    Color c = bmpobj.GetPixel(x, y);
                    {
                        if (c.GetBrightness() >= hsb)
                        {
                            scan[x / 8] |= (byte)(0x80 >> (x % 8));
                        }
                    }
                }

                Marshal.Copy(scan, 0, (IntPtr)((int)data.Scan0 + data.Stride * y), scan.Length);
            }

            bmp.UnlockBits(data);

            bmpobj = bmp;

            return bmpobj;
        }

        /// <summary>
        /// 二值化 遍历每个点 点的亮度小于阀值 则认为是黑色 否则是白色(干扰线和)
        /// </summary>
        public static Bitmap CVThreshold(Bitmap img, int thresholdValue)
        {
            if (img != null)
            {
                for (var x = 0; x < img.Width; x++)
                {
                    for (var y = 0; y < img.Height; y++)
                    {
                        Color color = img.GetPixel(x, y);
                        if (color.R < thresholdValue)
                        {
                            img.SetPixel(x, y, Color.Black);
                        }
                        else
                        {
                            img.SetPixel(x, y, Color.White);
                        }
                    }
                }
            }

            return img;
        }

        /// <summary>
        /// 二值化 遍历每个点 点的亮度小于阀值 则认为是黑色 否则是白色(干扰线和)
        /// </summary>
        public static Bitmap CVThreshold(Bitmap img)
        {
            if (img != null)
            {
                List<Coordinate> coordinates = new List<Coordinate>();
                for (var x = 0; x < img.Width; x++)
                {
                    for (var y = 0; y < img.Height; y++)
                    {
                        Color color = img.GetPixel(x, y);
                        if (color.GetBrightness() < 0.46f)
                        {
                            img.SetPixel(x, y, Color.Black);
                        }
                        else
                        {
                            // 判断这个点的四周是否有黑色点，如果有则把该点复制为黑色
                            if (!IsconnectionValidPoint(img, x, y))
                            {
                                img.SetPixel(x, y, Color.White);
                            }
                            else
                            {
                                Coordinate coo = new Coordinate();
                                coo.X = x;
                                coo.Y = y;

                                coordinates.Add(coo);
                            }
                        }
                    }
                }

                foreach (Coordinate coordinate in coordinates)
                {
                    img.SetPixel(coordinate.X, coordinate.Y, Color.Black);
                }
            }

            return img;
        }

        /// <summary>
        /// 二值化 遍历每个点 点的亮度小于阀值 则认为是黑色 否则是白色(干扰线和)
        /// </summary>
        public static Bitmap CVThresholdOne(Bitmap img)
        {
            if (img != null)
            {
                List<Coordinate> coordinates = new List<Coordinate>();
                for (var x = 0; x < img.Width; x++)
                {
                    for (var y = 0; y < img.Height; y++)
                    {
                        Color color = img.GetPixel(x, y);
                        if (color.GetBrightness() < 0.46f)
                        {
                            img.SetPixel(x, y, Color.Black);
                        }
                        else
                        {
                            img.SetPixel(x, y, Color.White);
                        }
                    }
                }
            }

            return img;
        }

        /// <summary>
        /// 是否与有效点连接
        /// </summary>
        /// <param name="bitMap">图片</param>
        /// <param name="x">x</param>
        /// <param name="y">y</param>
        /// <returns>是连接点true,不是连接点false</returns>
        private static bool IsconnectionValidPoint(Bitmap bitMap, int x, int y)
        {
            bool result = false;
            int width = bitMap.Width;
            int height = bitMap.Height;
            int point = 0;
            for (int i = -1; i <= 1; i++)
            {
                for (int j = -1; j <= 1; j++)
                {
                    int xlocate = x + i;
                    int ylocate = y + j;

                    if (xlocate != x && ylocate != y && Islegal(width, height, xlocate, ylocate))
                    {
                        Color color = bitMap.GetPixel(xlocate, ylocate);
                        if (color.R < 128 && color.G < 128 && color.B < 128)
                        {
                            point++;
                            if (point == 2)
                            {
                                result = true;
                                return result;
                            }
                        }
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// 是否是合法点
        /// </summary>
        /// <param name="width">图片宽度</param>
        /// <param name="height">图片高度</param>
        /// <param name="x">x</param>
        /// <param name="y">y</param>
        /// <returns>合法:true非法:false</returns>
        private static bool Islegal(int width, int height, int x, int y)
        {
            bool result = false;
            if ((x >= 0 && x < width && y >= 0 && y < height))
            {
                result = true;
            }

            return result;
        }

        public static Bitmap GetPictureValidByValue(Bitmap bmpobj, int dd, int CharsCount)
        {
            return null;
        }

        /**/
        /// <summary>
        /// 得到有效图形并调整为可平均分割的大小
        /// </summary>
        /// <param name="dgGrayValue">灰度背景分界值</param>
        /// <param name="CharsCount">有效字符数</param>
        /// <returns></returns>
        public static Bitmap GetPictureValidByValue(Bitmap bmpobj, int CharsCount)
        {
            int posx1 = bmpobj.Width;
            int posy1 = bmpobj.Height;
            int posx2 = 0; int posy2 = 0;
            for (int i = 0; i < bmpobj.Height; i++)      //找有效区
            {
                for (int j = 0; j < bmpobj.Width; j++)
                {
                    int pixelValue = bmpobj.GetPixel(j, i).R;
                    if (pixelValue == 0)     //根据灰度值
                    {
                        if (posx1 > j) posx1 = j;
                        if (posy1 > i) posy1 = i;

                        if (posx2 < j) posx2 = j;
                        if (posy2 < i) posy2 = i;
                    };
                };
            };
            // 确保能整除
            int Span = CharsCount - (posx2 - posx1 + 1) % CharsCount;   //可整除的差额数
            if (Span < CharsCount)
            {
                int leftSpan = Span / 2;    //分配到左边的空列 ，如span为单数,则右边比左边大1
                if (posx1 > leftSpan)
                    posx1 = posx1 - leftSpan;
                if (posx2 + Span - leftSpan < bmpobj.Width)
                    posx2 = posx2 + Span - leftSpan;
            }
            //复制新图
            Rectangle cloneRect = new Rectangle(posx1, posy1, posx2 - posx1 + 1, posy2 - posy1 + 1);
            bmpobj = bmpobj.Clone(cloneRect, bmpobj.PixelFormat);

            return bmpobj;
        }

        /// <summary>
        /// 灰度转换,逐行方式
        /// </summary>
        public static Bitmap GrayByLine(Bitmap bitMap)
        {
            Rectangle rec = new Rectangle(0, 0, bitMap.Width, bitMap.Height);
            BitmapData bmpData = bitMap.LockBits(rec, ImageLockMode.ReadWrite, bitMap.PixelFormat);// PixelFormat.Format32bppPArgb);
            //    bmpData.PixelFormat = PixelFormat.Format24bppRgb;
            IntPtr scan0 = bmpData.Scan0;
            int len = bitMap.Width * bitMap.Height;
            int[] pixels = new int[len];
            Marshal.Copy(scan0, pixels, 0, len);


            //对图片进行处理
            int GrayValue = 0;
            for (int i = 0; i < len; i++)
            {
                GrayValue = GetGrayNumColor(Color.FromArgb(pixels[i]));
                pixels[i] = (byte)(Color.FromArgb(GrayValue, GrayValue, GrayValue)).ToArgb();      //Color转byte
            }

            bitMap.UnlockBits(bmpData);

            return bitMap;
        }

        /// <summary>
        ///  去掉杂点（适合杂点/杂线粗为1）
        /// </summary>
        /// <param name="dggrayValue">背前景灰色界限</param>
        /// <param name="maxNearPoints">MaxNearPoints</param>
        public static Bitmap ClearNoise(Bitmap bitMap, int dggrayValue, int maxNearPoints)
        {
            Color piexl;
            int nearDots = 0;
            //// int XSpan, YSpan, tmpX, tmpY;
            //// 逐点判断
            for (int i = 0; i < bitMap.Width; i++)
            {
                for (int j = 0; j < bitMap.Height; j++)
                {
                    piexl = bitMap.GetPixel(i, j);
                    if (piexl.R < dggrayValue)
                    {
                        nearDots = 0;
                        //// 判断周围8个点是否全为空
                        //// 边框全去掉
                        if (i == 0 || i == bitMap.Width - 1 || j == 0 || j == bitMap.Height - 1)
                        {
                            bitMap.SetPixel(i, j, Color.White);
                        }
                        else
                        {
                            if (bitMap.GetPixel(i - 1, j - 1).R < dggrayValue)
                            {
                                nearDots++;
                            }

                            if (bitMap.GetPixel(i, j - 1).R < dggrayValue)
                            {
                                nearDots++;
                            }

                            if (bitMap.GetPixel(i + 1, j - 1).R < dggrayValue)
                            {
                                nearDots++;
                            }

                            if (bitMap.GetPixel(i - 1, j).R < dggrayValue)
                            {
                                nearDots++;
                            }

                            if (bitMap.GetPixel(i + 1, j).R < dggrayValue)
                            {
                                nearDots++;
                            }

                            if (bitMap.GetPixel(i - 1, j + 1).R < dggrayValue)
                            {
                                nearDots++;
                            }

                            if (bitMap.GetPixel(i, j + 1).R < dggrayValue)
                            {
                                nearDots++;
                            }

                            if (bitMap.GetPixel(i + 1, j + 1).R < dggrayValue)
                            {
                                nearDots++;
                            }
                        }

                        if (nearDots < maxNearPoints)
                        {
                            bitMap.SetPixel(i, j, Color.White);
                        }
                        //// 去掉单点 && 粗细小3邻边点
                    }
                    else
                    {
                        //// 背景
                        bitMap.SetPixel(i, j, Color.White);

                    }
                }
            }

            return bitMap;
        }

        /// <summary>
        /// 3×3中值滤波除杂，
        /// </summary>
        /// <param name="dggrayValue">dgGrayValue</param>
        public static Bitmap MiddleFileter(Bitmap bitMap, int dggrayValue)
        {
            int x, y;
            byte[] p = new byte[9]; //// 最小处理窗口3*3
            byte s;
            //// byte[] lpTemp=new BYTE[nByteWidth*nHeight];
            int i, j;

            ////--!!!!!!!!!!!!!!下面开始窗口为3×3中值滤波!!!!!!!!!!!!!!!!//// --第一行和最后一行无法取窗口
            for (y = 1; y < bitMap.Height - 1; y++)
            {
                for (x = 1; x < bitMap.Width - 1; x++)
                {
                    //// 取9个点的值
                    p[0] = bitMap.GetPixel(x - 1, y - 1).R;
                    p[1] = bitMap.GetPixel(x, y - 1).R;
                    p[2] = bitMap.GetPixel(x + 1, y - 1).R;
                    p[3] = bitMap.GetPixel(x - 1, y).R;
                    p[4] = bitMap.GetPixel(x, y).R;
                    p[5] = bitMap.GetPixel(x + 1, y).R;
                    p[6] = bitMap.GetPixel(x - 1, y + 1).R;
                    p[7] = bitMap.GetPixel(x, y + 1).R;
                    p[8] = bitMap.GetPixel(x + 1, y + 1).R;

                    //// 计算中值
                    for (j = 0; j < 5; j++)
                    {
                        for (i = j + 1; i < 9; i++)
                        {
                            if (p[j] > p[i])
                            {
                                s = p[j];
                                p[j] = p[i];
                                p[i] = s;
                            }
                        }
                    }
                    //if (bitMap.GetPixel(x, y).R < dgGrayValue)

                    bitMap.SetPixel(x, y, Color.FromArgb(p[4], p[4], p[4]));    //// 给有效值付中值

                }
            }

            return bitMap;
        }

        /// <summary>
        /// 阈值处理,即二值化，这里考虑用整体阀值，但是因为其对输入的图像量化噪音或不均匀光照抵抗差，在一些有干扰的像素上会发生错误判断
        /// ，因此建议采用动态阀值，动态阈值选择不仅取决于像素阈值以及其领域像素的灰度值，并且与该像素坐标位置有关。动态是指根据每个像素及其邻域像素的灰度值情况动态地计算分割所需的阈值
        /// </summary>
        /// <param name="er">阈值</param>
        public Bitmap KeyValue(int value, Bitmap bm)
        {
            //定义一个色彩变量对象
            Color ColorOrigin = new Color();

            //定义红、绿、蓝三色和亮度
            double Red, Green, Blue, Y;
            for (int i = 0; i <= bm.Width - 1; i++)
            {
                //循环处理图像中的每一个像素点
                for (int j = 0; j <= bm.Height - 1; j++)
                {
                    //获取当前像素点的色彩信息
                    ColorOrigin = bm.GetPixel(i, j);

                    //获取当前像素点的红色分量
                    Red = ColorOrigin.R;

                    //获取当前像素点的绿色分量
                    Green = ColorOrigin.G;

                    //获取当前像素点的蓝色分量
                    Blue = ColorOrigin.B;

                    //计算当前像素点的亮度
                    Y = 0.59 * Red + 0.3 * Green + 0.11 * Blue;

                    //如果当前像素点的亮度大于指定阈值
                    if (Y > value)
                    {
                        //那么定义一个纯白的色彩变量，即各分量均为255
                        Color ColorProcessed = Color.FromArgb(255, 255, 255);

                        //将白色变量赋给当前像素点
                        bm.SetPixel(i, j, ColorProcessed);
                    }

                    //如果当前像素点的亮度小于指定阈值
                    if (Y <= value)
                    {
                        //那么定义一个纯黑的色彩变量，即各分量均为0
                        Color ColorProcessed = Color.FromArgb(0, 0, 0);

                        //将黑色变量赋给当前像素点
                        bm.SetPixel(i, j, ColorProcessed);
                    }
                }
            }

            return bm;
        }

        /// <summary>
        /// 去掉边框，一般边框线占据两行的像素点
        /// </summary>
        /// <param name="w">边框的像素值</param>
        /// <returns>去掉边框后的图片</returns>
        public static Bitmap DropDistrubLine(int w, Bitmap bm)
        {
            for (int i = 0; i < bm.Height; i++)
            {
                for (int j = 0; j < bm.Width; j++)
                {
                    if (i < w || j < w || j > bm.Width - 1 - w || i > bm.Height - 1 - w)
                    {
                        bm.SetPixel(j, i, Color.FromArgb(255, 255, 255));
                    }
                }
            }

            bm.MakeTransparent(Color.White);
            return bm;
        }

        /// <summary>
        /// 去除噪点
        /// </summary>
        /// <returns>去掉噪点后的图片</returns>
        public Bitmap DropDisturbPoint(Bitmap bm)
        {
            bm.MakeTransparent(Color.White);
            for (int i = 2; i < bm.Width - 2; i++)
            {
                for (int j = 2; j < bm.Height - 2; j++)
                {
                    if (Color.Black.A == bm.GetPixel(i, j).A)
                    {
                        //选择黑点
                        if (bm.GetPixel(i - 1, j - 1).A.ToString() == "0" && bm.GetPixel(i, j - 1).A.ToString() == "0" && bm.GetPixel(i + 1, j - 1).A.ToString() == "0" && bm.GetPixel(i - 1, j).A.ToString() == "0" && bm.GetPixel(i + 1, j).A.ToString() == "0" && bm.GetPixel(i - 1, j + 1).A.ToString() == "0" && bm.GetPixel(i, j + 1).A.ToString() == "0" && bm.GetPixel(i + 1, j + 1).A.ToString() == "0")
                        {
                            //如果一圈都是白的,就将他设置为白的
                            bm.SetPixel(i, j, Color.White);
                        }
                    }
                }
            }

            return bm;
        }

        /**/
        /// <summary>
        /// 得到有效图形并调整为可平均分割的大小
        /// </summary>
        /// <param name="dgGrayValue">灰度背景分界值</param>
        /// <param name="CharsCount">有效字符数</param>
        /// <returns></returns>
        public static Bitmap GetPicValidByValue(Bitmap bmpobj, int dgGrayValue, int CharsCount)
        {
            int posx1 = bmpobj.Width;
            int posy1 = bmpobj.Height;
            int posx2 = 0; int posy2 = 0;
            for (int i = 0; i < bmpobj.Height; i++)      //找有效区
            {
                for (int j = 0; j < bmpobj.Width; j++)
                {
                    int pixelValue = bmpobj.GetPixel(j, i).R;
                    if (pixelValue < dgGrayValue)     //根据灰度值
                    {
                        if (posx1 > j) posx1 = j;
                        if (posy1 > i) posy1 = i;

                        if (posx2 < j) posx2 = j;
                        if (posy2 < i) posy2 = i;
                    };
                };
            };
            // 确保能整除
            int Span = CharsCount - (posx2 - posx1 + 1) % CharsCount;   //可整除的差额数
            if (Span < CharsCount)
            {
                int leftSpan = Span / 2;    //分配到左边的空列 ，如span为单数,则右边比左边大1
                if (posx1 > leftSpan)
                    posx1 = posx1 - leftSpan;
                if (posx2 + Span - leftSpan < bmpobj.Width)
                    posx2 = posx2 + Span - leftSpan;
            }
            //复制新图
            Rectangle cloneRect = new Rectangle(posx1, posy1, posx2 - posx1 + 1, posy2 - posy1 + 1);
            bmpobj = bmpobj.Clone(cloneRect, bmpobj.PixelFormat);

            return bmpobj;
        }

        /// <summary>
        /// 图片分割
        /// </summary>
        /// <returns>返回分割后的图片集合</returns>
        public static Bitmap[] DivisionImage(Bitmap bm)
        {
            Bitmap[] ImageCuted;
            StringBuilder strBuild = new StringBuilder();
            List<CutParamer> lsz = new List<CutParamer>();
            for (int i = 0; i < bm.Width; i++)
            {
                string k = string.Empty;
                for (int j = 0; j < bm.Height; j++)
                {
                    k += bm.GetPixel(i, j).R.ToString();
                }

                Color dd = Color.White;
                Color ccs = Color.Black;

                // 是否有黑点
                if (k.Contains("0"))
                {
                    // 有黑点
                    strBuild.Append(1);
                }
                else
                {
                    // 无黑点
                    strBuild.Append(0);
                }
            }

            // 开始计算所要截取的坐标

            // 是否记录初始值
            bool isrecord = true;

            // 初始横坐标
            int initialXlocal = 0;

            // 接收横坐标
            int receiveXlocal = 0;
            for (int i = 0; i < bm.Width; i++)
            {
                if (strBuild.ToString().Substring(i, 1) == "1")
                {
                    //遇见1
                    if (isrecord)
                    {
                        //第一次可以见到
                        isrecord = false;
                        initialXlocal = i;//记录初始坐标

                    }
                    if (strBuild.ToString().Substring(i + 1, 1) == "0")
                    {
                        //已经是1的终点
                        receiveXlocal = i;

                        //开始截取
                        CutParamer sss = new CutParamer() { X = initialXlocal, W = receiveXlocal - initialXlocal, };
                        lsz.Add(sss);
                    }
                }
                else
                {
                    //遇见0
                    isrecord = true;//初始化开始记录值
                }
            }

            ImageCuted = GetSegmentPicture(bm, lsz.ToArray());
            return ImageCuted;
        }

        /// <summary>
        /// 锐化、主要是消除图像中不应有的模糊边缘，使对象边缘变得轮廓分明
        /// </summary>
        /// <param name="b">原始Bitmap</param>
        /// <param name="val">锐化程度。取值[0,1]。值越大锐化程度越高</param>
        /// <returns>锐化后的图像</returns>
        public Bitmap Sharapen(Bitmap b, float val)
        {
            if (b == null)
            {
                return null;
            }

            int w = b.Width;
            int h = b.Height;
            try
            {
                // 24位真彩色
                Bitmap bmpRtn = new Bitmap(w, h, PixelFormat.Format24bppRgb);
                BitmapData srcData = b.LockBits(new Rectangle(0, 0, w, h), ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);
                BitmapData dstData = bmpRtn.LockBits(new Rectangle(0, 0, w, h), ImageLockMode.WriteOnly, PixelFormat.Format24bppRgb);

                // 用指针操作可以加快速度
                unsafe
                {
                    byte* pin = (byte*)srcData.Scan0.ToPointer();
                    byte* pout = (byte*)dstData.Scan0.ToPointer();
                    int stride = srcData.Stride;
                    byte* p;
                    for (int y = 0; y < h; y++)
                    {
                        for (int x = 0; x < w; x++)
                        {
                            //// 取周围9点的值。位于边缘上的点不做改变。
                            if (x == 0 || x == w - 1 || y == 0 || y == h - 1)
                            {
                                //// 不做
                                pout[0] = pin[0];
                                pout[1] = pin[1];
                                pout[2] = pin[2];
                            }
                            else
                            {
                                int r1, r2, r3, r4, r5, r6, r7, r8, r0;
                                int g1, g2, g3, g4, g5, g6, g7, g8, g0;
                                int b1, b2, b3, b4, b5, b6, b7, b8, b0;
                                float vR, vG, vB;
                                //// 左上
                                p = pin - stride - 3;
                                r1 = p[2];
                                g1 = p[1];
                                b1 = p[0];

                                //// 正上
                                p = pin - stride;
                                r2 = p[2];
                                g2 = p[1];
                                b2 = p[0];

                                //// 右上
                                p = pin - stride + 3;
                                r3 = p[2];
                                g3 = p[1];
                                b3 = p[0];

                                //// 左侧
                                p = pin - 3;
                                r4 = p[2];
                                g4 = p[1];
                                b4 = p[0];

                                //// 右侧
                                p = pin + 3;
                                r5 = p[2];
                                g5 = p[1];
                                b5 = p[0];

                                //// 右下
                                p = pin + stride - 3;
                                r6 = p[2];
                                g6 = p[1];
                                b6 = p[0];

                                //// 正下
                                p = pin + stride;
                                r7 = p[2];
                                g7 = p[1];
                                b7 = p[0];

                                //// 右下
                                p = pin + stride + 3;
                                r8 = p[2];
                                g8 = p[1];
                                b8 = p[0];

                                //// 自己
                                p = pin;
                                r0 = p[2];
                                g0 = p[1];
                                b0 = p[0];

                                vR = (float)r0 - ((float)(r1 + r2 + r3 + r4 + r5 + r6 + r7 + r8) / 8);
                                vG = (float)g0 - ((float)(g1 + g2 + g3 + g4 + g5 + g6 + g7 + g8) / 8);
                                vB = (float)b0 - ((float)((b1 + b2) + b3 + b4 + b5 + b6 + b7 + b8) / 8);

                                vR = r0 + (vR * val);
                                vG = g0 + (vG * val);
                                vB = b0 + (vB * val);

                                if (vR > 0)
                                {
                                    vR = Math.Min(255, vR);
                                }
                                else
                                {
                                    vR = Math.Max(0, vR);
                                }

                                if (vG > 0)
                                {
                                    vG = Math.Min(255, vG);
                                }
                                else
                                {
                                    vG = Math.Max(0, vG);
                                }

                                if (vB > 0)
                                {
                                    vB = Math.Min(255, vB);
                                }
                                else
                                {
                                    vB = Math.Max(0, vB);
                                }

                                pout[0] = (byte)vB;
                                pout[1] = (byte)vG;
                                pout[2] = (byte)vR;
                            }

                            pin += 3;
                            pout += 3;
                        }
                        //// end of x

                        pin += srcData.Stride - (w * 3);
                        pout += srcData.Stride - (w * 3);
                    }
                    //// end of y
                }

                b.UnlockBits(srcData);
                bmpRtn.UnlockBits(dstData);
                return bmpRtn;
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// 返回分割图片
        /// </summary>
        /// <param name="b">要分割的图片</param>
        /// <param name="s">分割参数</param>
        /// <returns>返回截取的图片</returns>
        public static Bitmap[] GetSegmentPicture(Bitmap b, CutParamer[] s)
        {
            Bitmap[] bs = new Bitmap[s.Count()];
            for (int q = 0; q < s.Count(); q++)
            {
                Bitmap bb = new Bitmap(s[q].W, b.Height);
                for (int i = s[q].X; i < s[q].X + s[q].W; i++)
                {
                    for (int j = 0; j < b.Height; j++)
                    {
                        bb.SetPixel(i - s[q].X, j, b.GetPixel(i, j));
                    }
                }

                bs[q] = bb;
            }

            return bs;
        }

        /**/
        /// <summary>
        /// 灰度转换,逐点方式
        /// </summary>
        public static Bitmap GrayByPixels(Bitmap bmpobj)
        {
            for (int i = 0; i < bmpobj.Height; i++)
            {
                for (int j = 0; j < bmpobj.Width; j++)
                {
                    int tmpValue = GetGrayNumColor(bmpobj.GetPixel(j, i));
                    bmpobj.SetPixel(j, i, Color.FromArgb(tmpValue, tmpValue, tmpValue));
                }
            }

            return bmpobj;
        }


        /// <summary>
        /// 根据RGB，计算灰度值
        /// </summary>
        /// <param name="posClr">Color值</param>
        /// <returns>灰度值，整型</returns>
        private static int GetGrayNumColor(System.Drawing.Color posClr)
        {
            return (posClr.R * 19595 + posClr.G * 38469 + posClr.B * 7472) >> 16;
        }

        /// <summary>
        /// 等比例缩放图片
        /// </summary>
        /// <param name="initImage">图片</param>
        /// <returns>返回统一后的图片</returns>
        public static Bitmap NarrowOrEnlarge(Bitmap initImage)
        {
            Bitmap bimap = null;
            try
            {
                if (initImage != null)
                {
                    double newWidth = initImage.Width;
                    double newHeight = initImage.Height;
                    double targetWidth = 1000;
                    double targetHeight = 1000;

                    // 宽大于高或宽等于高（横图或正方）
                    if (initImage.Width >= initImage.Height)
                    {
                        newWidth = targetWidth;
                        newHeight = initImage.Height * (targetWidth / initImage.Width);
                    }
                    else
                    {
                        newHeight = targetHeight;
                        newWidth = initImage.Width * (targetHeight / initImage.Height);
                    }

                    // 生成新图
                    // 新建一个bmp图片
                    System.Drawing.Image newImage = new System.Drawing.Bitmap((int)newWidth, (int)newHeight);

                    // 新建一个画板
                    System.Drawing.Graphics newG = System.Drawing.Graphics.FromImage(newImage);

                    // 设置质量
                    newG.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                    newG.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;

                    // 置背景色
                    newG.Clear(Color.White);

                    // 画图
                    newG.DrawImage(initImage, new System.Drawing.Rectangle(0, 0, newImage.Width, newImage.Height), new System.Drawing.Rectangle(0, 0, initImage.Width, initImage.Height), System.Drawing.GraphicsUnit.Pixel);

                    newG.Dispose();
                    initImage.Dispose();

                    // 保存缩略图
                    bimap = newImage as Bitmap;
                }
            }
            catch (Exception ex)
            {

            }

            return bimap;
        }

        private static List<int> MeetZero(List<int> my)
        {
            List<int> result = new List<int>();
            int count = my.Count;
            for (int i = 0; i < count; i++)
            {
                if (my[i] == 0)
                {
                    result.Add(i);
                }
            }

            return result;
        }


        //private static List<int> MeetZero(List<int> my)
        //{
        //    List<int> result = new List<int>();
        //    int count = my.Count;
        //    for (int i = 0; i < count; i++)
        //    {
        //        if (my[i] == 0)
        //        {
        //            result.Add(i);
        //        }
        //    }

        //    return result;
        //}


        /// <summary>
        /// 竖直投分割法
        /// </summary>
        /// <param name="bitMap">图像信息</param>
        /// <param name="projectionValues">投影数组</param>
        /// <param name="threshold">阀值</param>
        /// <returns>返回分割结果</returns>
        public static List<Rectangle> Split(Bitmap bitMap, int widthThreshold)
        {
            bool isClose = true;
            int last = 0;
            List<Rectangle> rectList = new List<Rectangle>();
            List<int> projectionValues = Xprojection(bitMap);
            List<int> zeros = MeetZero(projectionValues);
            bool tes = false;
            int my=(projectionValues.Count / 4) - 1;

            Rectangle rect = new Rectangle();
            for (int i = 0; i < projectionValues.Count; i++)
            {
                if (isClose)
                {
                    if (projectionValues[i] > 0)
                    {
                        rect = new Rectangle();
                        rect.Y = 0;
                        rect.X = i;
                        rect.Height = bitMap.Height - 1;
                        isClose = false;
                    }
                }
                else
                {
                    tes = false;

                    if (rectList.Count < 3)
                    {
                        if (zeros != null && zeros.Count > 0)
                        {
                            for (int ii = 0; ii < zeros.Count; ii++)
                            {
                                if ((zeros[ii] - i) > 2 && (zeros[ii] - i) <= 9 && i - rect.X > 13)
                                {
                                    rect.Width = zeros[ii] - rect.X;
                                    i = zeros[ii];
                                    rectList.Add(rect);
                                    isClose = true;
                                    tes = true;
                                    break;
                                }
                            }
                        }

                        if (tes == false)
                        {
                            if (i - rect.X >= my)
                            {
                                rect.Width = i - rect.X;
                                rectList.Add(rect);
                                isClose = true;
                            }
                        }
                    }
                    else
                    {
                        rect.Width = projectionValues.Count - 1 - rect.X;
                        rectList.Add(rect);
                        i = projectionValues.Count;
                        isClose = true;
                    }

                }
            }

            return rectList;
        }

        /// <summary>
        /// 分割图片
        /// </summary>
        /// <param name="bitMap">图片</param>
        /// <param name="number">待分割的字符数目</param>
        /// <returns>返回分割后的图片</returns>
        public static List<Bitmap> SplicPicture(Bitmap bitMap, int number)
        {
            List<Bitmap> allBitmaps = new List<Bitmap>();
            List<int> verticalValues = VerticalProjection(bitMap);
            int count = verticalValues.Count;
            int startColumn = 0;
            if (number == 4)
            {
                // 切分第一个字符出来，它的位置在13-25之间，找这个中间投影值最小的
                allBitmaps.Add(GetSplitPic(bitMap, verticalValues, 13, 25, ref startColumn));

                // 切分出第二个字符，他的大致位置为35-50
                allBitmaps.Add(GetSplitPic(bitMap, verticalValues, 35, 50, ref startColumn));

                // 找到第三个字符，他的大致位置为60-70
                allBitmaps.Add(GetSplitPic(bitMap, verticalValues, 60, 70, ref startColumn));

                // 找到第四个字符，基本上边缘切割即可
                allBitmaps.Add(GetSplitPic(bitMap, verticalValues, count - 1, count, ref startColumn));
            }

            if (number == 3)
            {
                // 切分第一个字符出来，它的位置在13-25之间，找这个中间投影值最小的
                allBitmaps.Add(GetSplitPic(bitMap, verticalValues, 13, 25, ref startColumn));

                // 切分出第二个字符，他的大致位置为35-50
                allBitmaps.Add(GetSplitPic(bitMap, verticalValues, 35, 45, ref startColumn));

                // 找到第三个字符，他的大致位置为60-70
                allBitmaps.Add(GetSplitPic(bitMap, verticalValues, count - 1, count, ref startColumn));
            }

            if (number == 2)
            {
                // 切分第一个字符出来，它的位置在13-25之间，找这个中间投影值最小的
                allBitmaps.Add(GetSplitPic(bitMap, verticalValues, 13, 25, ref startColumn));

                // 切分出第二个字符，他的大致位置为35-50
                allBitmaps.Add(GetSplitPic(bitMap, verticalValues, count - 1, count, ref startColumn));
            }

            return allBitmaps;
        }

        /// <summary>
        /// 获取分割的图片
        /// </summary>
        /// <param name="bitmap"></param>
        /// <param name="verticalValues"></param>
        /// <param name="fromColumn"></param>
        /// <param name="toColumn"></param>
        /// <returns></returns>
        private static Bitmap GetSplitPic(Bitmap bitmap, List<int> verticalValues, int fromColumn, int toColumn, ref int startColumn)
        {
            Bitmap result = null; ;
            Rectangle rect = new Rectangle();
            int small = GetSmallColumn(verticalValues, fromColumn, toColumn, startColumn);
            rect.Y = 0;
            rect.X = startColumn;
            rect.Height = bitmap.Height;
            rect.Width = small - startColumn;
            result = bitmap.Clone(rect, bitmap.PixelFormat);
            startColumn = small;
            return result;
        }

        /// <summary>
        /// 拿到某个区间投影值最小的列
        /// </summary>
        /// <param name="verticalValues">投影值</param>
        /// <param name="fromColumn">开始列</param>
        /// <param name="toColumn">结束列</param>
        /// <returns>返回投影值最小的列</returns>
        private static int GetSmallColumn(List<int> verticalValues, int fromColumn, int toColumn, int startColumn)
        {
            int count = verticalValues.Count;
            int result = 0;
            int temp = 0;
            for (int i = fromColumn; i < toColumn; i++)
            {
                // 第一次
                if (i == fromColumn)
                {
                    temp = verticalValues[i];
                    result = i;
                }
                else if (temp >= verticalValues[i])
                {
                    temp = verticalValues[i];
                    result = i;
                }
            }

            // 最后一列排除
            if (result > count - 5)
            {
                result = count - 1;
            }
            else if (result - startColumn < 16)
            {
                result = startColumn + 20;
            }

            return result;
        }

        /// <summary>
        /// 获取最小的投影值
        /// </summary>
        /// <param name="projectionValues">投影值集合</param>
        /// <param name="startColumn">起始列</param>
        /// <returns>返回最小投影值</returns>
        public static int GetSmallValue(List<int> projectionValues, int startColumn)
        {
            int result = 0;
            for (int i = 0; i < 5; i++)
            {
                if (projectionValues[startColumn + i] < 5)
                {
                    result = startColumn + i;
                    break;
                }
            }

            return result;
        }

        /// <summary>
        /// x方向投影
        /// </summary>
        /// <param name="bitMap">图像</param>
        /// <returns>返回结果</returns>
        public static List<int> Xprojection(Bitmap bitMap)
        {
            List<int> projectResult = new List<int>();
            for (int i = 0; i < bitMap.Width; i++)
            {
                int projectValue = 0;
                for (int j = 0; j < bitMap.Height; j++)
                {
                    Color c = bitMap.GetPixel(i, j);
                    if (bitMap.GetPixel(i, j).ToArgb() == Color.Black.ToArgb())
                    {
                        projectValue++;
                    }
                }

                projectResult.Add(projectValue);
            }

            return projectResult;
        }

        /// <summary>
        /// 切分图片
        /// </summary>
        /// <param name="_bitmap"></param>
        /// <param name="row"></param>
        /// <param name="col"></param>
        /// <returns></returns>
        public static Bitmap[] SplitImg(Bitmap _bitmap, int row, int col)
        {
            int singW = _bitmap.Width / row;
            int singH = _bitmap.Height / col;
            Bitmap[] arrmap = new Bitmap[row * col];
            Rectangle rect;
            for (int i = 0; i < col; i++)
            {
                for (int j = 0; j < row; j++)
                {
                    rect = new Rectangle(j * singW, i * singH, singW, singH);
                    arrmap[i * row + j] = _bitmap.Clone(rect, _bitmap.PixelFormat);
                }
            }

            return arrmap;
        }

        /// <summary>
        /// 扭曲图片校正
        /// </summary>
        public static Bitmap ReSetBitMap(Bitmap bmpobj)
        {
            Graphics g = Graphics.FromImage(bmpobj);
            Matrix X = new Matrix();
            //  X.Rotate(30);
            X.Shear((float)0.16666666667, 0);   //  2/12
            g.Transform = X;
            // Draw image
            //Rectangle cloneRect = GetPicValidByValue(128);  //Get Valid Pic Rectangle
            Rectangle cloneRect = new Rectangle(0, 0, bmpobj.Width, bmpobj.Height);
            Bitmap tmpBmp = bmpobj.Clone(cloneRect, bmpobj.PixelFormat);
            g.DrawImage(tmpBmp,
                new Rectangle(0, 0, bmpobj.Width, bmpobj.Height),
                 0, 0, tmpBmp.Width,
                 tmpBmp.Height,
                 GraphicsUnit.Pixel);

            return tmpBmp;
        }

        /// <summary>
        /// 去除周围的点
        /// </summary>
        /// <param name="bitMap"></param>
        /// <returns></returns>
        public static Bitmap PickAround(Bitmap bitMap)
        {
            byte[] p = new byte[9]; //// 最小处理窗口3*3
            for (int y = 1; y < bitMap.Height - 1; y++)
            {
                for (int x = 1; x < bitMap.Width - 1; x++)
                {
                    //////// 取9个点的值
                    ////p[0] = bitMap.GetPixel(x - 1, y - 1).R;
                    ////p[1] = bitMap.GetPixel(x, y - 1).R;
                    ////p[2] = bitMap.GetPixel(x + 1, y - 1).R;
                    ////p[3] = bitMap.GetPixel(x - 1, y).R;
                    ////p[4] = bitMap.GetPixel(x, y).R;
                    ////p[5] = bitMap.GetPixel(x + 1, y).R;
                    ////p[6] = bitMap.GetPixel(x - 1, y + 1).R;
                    ////p[7] = bitMap.GetPixel(x, y + 1).R;
                    ////p[8] = bitMap.GetPixel(x + 1, y + 1).R;
                    ////if()
                    //WriteableBitmap 
                }
            }

            return bitMap;
        }


        /// <summary>
        /// 算出竖直投影值
        /// </summary>
        /// <param name="bitmap">图像</param>
        /// <returns>返回投影值</returns>
        public static List<int> VerticalProjection(Bitmap bitmap)
        {
            List<int> lisValues = new List<int>();
            int width = bitmap.Width;
            int height = bitmap.Height;
            for (int i = 0; i < width; i++)
            {
                for (int j = height - 1; j >= 0; j--)
                {
                    Color color = bitmap.GetPixel(i, j);
                    if (color.R == 0 && color.G == 0 && color.B == 0)
                    {
                        lisValues.Add(j);
                        break;
                    }
                }
            }

            return lisValues;
        }

    }
}
