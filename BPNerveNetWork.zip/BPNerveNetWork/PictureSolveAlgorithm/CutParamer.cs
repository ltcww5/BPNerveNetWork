﻿
namespace PictureSolveAlgorithm
{
    public class CutParamer
    {
        int x;
        public int X
        {
            get { return x; }
            set { x = value; }
        }

        int w;
        public int W
        {
            get { return w; }
            set { w = value; }
        }
    }
}
