﻿//-----------------------------------------------------------------------
// <copyright file="CompareNumber.cs" company="517Na Enterprises">
// * Copyright (C) 2014 517Na科技有限公司 版权所有。
// * version : 2.0.50727.5477
// * author  : xukong
// * FileName: CompareNumber.cs
// * history : created by xukong 2014/12/2 20:53:23 
// </copyright>
//-----------------------------------------------------------------------
using System;
using System.Drawing;

namespace PictureSolveAlgorithm
{
    /// <summary>
    /// 对比数字
    /// </summary>
    public class Common
    {
        /// <summary>
        /// 获取最小值
        /// </summary>
        /// <param name="oneNumber">一个整数</param>
        /// <param name="twoNumber">一个整数</param>
        /// <param name="threeNumber">一个整数</param>
        /// <returns>返回最小值</returns>
        public static int GetMinNumber(int oneNumber, int twoNumber, int threeNumber)
        {
            int number = Math.Min(oneNumber, twoNumber);
            return Math.Min(number, threeNumber);
        }

        /// <summary>
        /// 赋值图片
        /// </summary>
        /// <param name="bimap">原始图片</param>
        /// <returns>返回复制后的结果</returns>
        public static Bitmap CopyPicture(Bitmap bimap)
        {
            Rectangle coneTangle = new Rectangle(0, 0, bimap.Width, bimap.Height);
            Bitmap newImage = bimap.Clone(coneTangle, bimap.PixelFormat);
            
            return newImage;
        }
    }
}
