﻿//-----------------------------------------------------------------------
// <copyright file="SolveGrayPicture.cs" company="517Na Enterprises">
// * Copyright (C) 2015 517Na科技有限公司 版权所有。
// * version : 2.0.50727.5485
// * author  : xukong
// * FileName: SolveGrayPicture.cs
// * history : created by xukong 2015-03-19 15:13:45 
// </copyright>
//-----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace PictureSolveAlgorithm
{
    /// <summary>
    /// SolveGrayPicture类 
    /// </summary>
    public class SolveGrayPicture
    {


    }
}
