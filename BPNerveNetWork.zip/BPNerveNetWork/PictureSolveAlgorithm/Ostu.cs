﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Collections;

namespace PictureSolveAlgorithm
{
    public class Ostu
    {
        /// <summary>
        /// 平均灰度法
        /// </summary>
        /// <param name="bit">图像</param>
        /// <returns>返回处理后的图像</returns>
        public Bitmap AverageGray(Bitmap bit)
        {
            for (int i = 0; i < bit.Width; i++)
            {
                for (int j = 0; j < bit.Height; j++)
                {
                    // 获取该点的RGB值
                    Color color = bit.GetPixel(i, j);

                    // 利用公式计算灰度值
                    int gray = (int)(color.R + color.G + color.B) / 3;
                    Color newColor = Color.FromArgb(gray, gray, gray);
                    bit.SetPixel(i, j, newColor);
                }
            }

            return bit;
        }

        /// <summary>
        /// 把图像转换为黑色和白色
        /// </summary>
        /// <param name="bitmap"></param>
        /// <param name="threshold"></param>
        /// <returns></returns>
        public Bitmap BlackAndWhitePic(Bitmap bitmap, int threshold)
        {
            int width = bitmap.Width;
            int height = bitmap.Height;
            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    Color color = bitmap.GetPixel(i, j);
                    if (color.R > threshold)
                    {
                        bitmap.SetPixel(i, j, Color.White);
                    }
                    else
                    {
                        bitmap.SetPixel(i, j, Color.Black);
                    }
                }
            }

            return bitmap;
        }

        /// <summary>
        /// 统计直方图
        /// </summary>
        /// <param name="bitmap">图片</param>
        /// <returns>返回直方图</returns>
        public int[] GetHistogram(Bitmap bitmap)
        {
            int[] result = new int[256];
            int width = bitmap.Width;
            int height = bitmap.Height;
            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    Color color = bitmap.GetPixel(i, j);
                    result[color.R]++;
                }
            }


            return result;
        }

        /// <summary>
        /// 获取最大类间距阀值
        /// </summary>
        /// <param name="HistGram"></param>
        /// <returns></returns>
        public int GetOSTUThreshold(int[] HistGram)
        {
            int X, Y, Amount = 0;

            // 背景像素点个数
            int PixelBack = 0;

            // 前景像素点个数
            int PixelFore = 0;
            int PixelIntegralBack = 0, PixelIntegralFore = 0, PixelIntegral = 0;
            double OmegaBack, OmegaFore, MicroBack, MicroFore, SigmaB, Sigma;              // 类间方差;
            int MinValue, MaxValue;
            int Threshold = 0;

            // 判断是否只有黑白
            for (MinValue = 0; MinValue < 256; MinValue++)
            {
                if (HistGram[MinValue] != 0)
                {
                    break;
                }
            }

            for (MaxValue = 255; MaxValue > MinValue; MaxValue--)
            {
                if (HistGram[MinValue] != 0)
                {
                    break;
                }
            }
            if (MaxValue == MinValue)
                return MaxValue;          // 图像中只有一个颜色             
            if (MinValue + 1 == MaxValue)
                return MinValue;      // 图像中只有二个颜色


            //  像素总数，从有像素点的灰度等级开始。
            for (Y = MinValue; Y <= MaxValue; Y++)
            {
                Amount += HistGram[Y];
            }

            PixelIntegral = 0;
            // 每个灰度值对应像素数累积和
            for (Y = MinValue; Y <= MaxValue; Y++)
            {
                PixelIntegral += HistGram[Y] * Y;
            }

            SigmaB = -1;
            for (Y = MinValue; Y < MaxValue; Y++)
            {
                PixelBack = PixelBack + HistGram[Y];
                PixelFore = Amount - PixelBack;
                OmegaBack = (double)PixelBack / Amount;
                OmegaFore = (double)PixelFore / Amount;
                PixelIntegralBack += HistGram[Y] * Y;
                PixelIntegralFore = PixelIntegral - PixelIntegralBack;
                MicroBack = (double)PixelIntegralBack / PixelBack;
                MicroFore = (double)PixelIntegralFore / PixelFore;
                Sigma = OmegaBack * OmegaFore * (MicroBack - MicroFore) * (MicroBack - MicroFore);
                if (Sigma > SigmaB)
                {
                    SigmaB = Sigma;
                    Threshold = Y;
                }
            }

            return Threshold;
        }

        #region
        /// <summary>
        /// 获取主要的连通域
        /// </summary>
        /// <param name="bitmap"></param>
        /// <param name="threshold"></param>
        /// <returns></returns>
        public Bitmap GetMainConnection(Bitmap bitmap, int threshold)
        {
            Dictionary<string, List<Coordinate>> dic = GetConnectDomain(bitmap);
            foreach (KeyValuePair<string, List<Coordinate>> co in dic)
            {
                if (co.Value.Count < threshold)
                {
                    // 置为白色
                    foreach (var coOne in co.Value)
                    {
                        bitmap.SetPixel(coOne.X, coOne.Y, Color.White);
                    }
                }
            }

            return bitmap;
        }

        /// <summary>
        /// 是否已经存在于其他连通域
        /// </summary>
        /// <param name="dic"></param>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <returns></returns>
        public bool IsSolve(Dictionary<string, List<Coordinate>> dic, int x, int y)
        {
            bool result = false;
            foreach (KeyValuePair<string, List<Coordinate>> keyValue in dic)
            {
                foreach (var one in keyValue.Value)
                {
                    if (one.X == x && one.Y == y)
                    {
                        result = true;
                        return result;
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// 获得以某个点为起点的连通域
        /// </summary>
        /// <param name="bmp"></param>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <returns></returns>
        public Dictionary<string, List<Coordinate>> GetConnectDomain(Bitmap bmp)
        {
            Dictionary<string, List<Coordinate>> coordinates = new Dictionary<string, List<Coordinate>>();
            // 以八连通域作为标准作为扫描窗口
            int width = bmp.Width;
            int height = bmp.Height;
            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    Color color = bmp.GetPixel(i, j);

                    // 黑色像素点并且不包含
                    if ((color.R == 0 && color.G == 0 && color.B == 0) && IsSolve(coordinates, i, j) == false)
                    {
                        Coordinate cor = new Coordinate();
                        cor.X = i;
                        cor.Y = j;
                        Queue qu = new Queue();
                        qu.Enqueue(cor);

                        List<Coordinate> saveCoordinates = new List<Coordinate>();
                        saveCoordinates.Add(cor);
                        while (qu.Count > 0)
                        {
                            Coordinate tempCoord = (Coordinate)qu.Dequeue();

                            // 判断这个点的上方是否有点
                            if (tempCoord.Y - 1 >= 0 && !IsSolveOne(saveCoordinates, tempCoord.X, tempCoord.Y - 1) && bmp.GetPixel(tempCoord.X, tempCoord.Y - 1).R == 0 && bmp.GetPixel(tempCoord.X, tempCoord.Y - 1).G == 0 && bmp.GetPixel(tempCoord.X, tempCoord.Y - 1).B == 0)
                            {
                                Coordinate upCoordinate = new Coordinate();
                                upCoordinate.X = tempCoord.X;
                                upCoordinate.Y = tempCoord.Y - 1;
                                saveCoordinates.Add(upCoordinate);
                                qu.Enqueue(upCoordinate);
                            }

                            // 右上方
                            if ((tempCoord.X + 1 < width && tempCoord.Y - 1 >= 0) && !IsSolveOne(saveCoordinates, tempCoord.X + 1, tempCoord.Y - 1) && bmp.GetPixel(tempCoord.X + 1, tempCoord.Y - 1).R == 0 && bmp.GetPixel(tempCoord.X + 1, tempCoord.Y - 1).G == 0 && bmp.GetPixel(tempCoord.X + 1, tempCoord.Y - 1).B == 0)
                            {
                                Coordinate upCoordinate = new Coordinate();
                                upCoordinate.X = tempCoord.X + 1;
                                upCoordinate.Y = tempCoord.Y - 1;
                                saveCoordinates.Add(upCoordinate);
                                qu.Enqueue(upCoordinate);
                            }

                            // 右边
                            if ((tempCoord.X + 1 < width) && !IsSolveOne(saveCoordinates, tempCoord.X + 1, tempCoord.Y) && bmp.GetPixel(tempCoord.X + 1, tempCoord.Y).R == 0 && bmp.GetPixel(tempCoord.X + 1, tempCoord.Y).G == 0 && bmp.GetPixel(tempCoord.X + 1, tempCoord.Y).B == 0)
                            {
                                Coordinate upCoordinate = new Coordinate();
                                upCoordinate.X = tempCoord.X + 1;
                                upCoordinate.Y = tempCoord.Y;
                                saveCoordinates.Add(upCoordinate);
                                qu.Enqueue(upCoordinate);
                            }

                            // 右下角
                            if ((tempCoord.X + 1 < width && tempCoord.Y + 1 < height) && !IsSolveOne(saveCoordinates, tempCoord.X + 1, tempCoord.Y + 1) && bmp.GetPixel(tempCoord.X + 1, tempCoord.Y + 1).R == 0 && bmp.GetPixel(tempCoord.X + 1, tempCoord.Y + 1).G == 0 && bmp.GetPixel(tempCoord.X + 1, tempCoord.Y + 1).B == 0)
                            {
                                Coordinate upCoordinate = new Coordinate();
                                upCoordinate.X = tempCoord.X + 1;
                                upCoordinate.Y = tempCoord.Y + 1;
                                saveCoordinates.Add(upCoordinate);
                                qu.Enqueue(upCoordinate);
                            }

                            // 下边
                            if ((tempCoord.Y + 1 < height) && !IsSolveOne(saveCoordinates, tempCoord.X, tempCoord.Y + 1) && bmp.GetPixel(tempCoord.X, tempCoord.Y + 1).R == 0 && bmp.GetPixel(tempCoord.X, tempCoord.Y + 1).G == 0 && bmp.GetPixel(tempCoord.X, tempCoord.Y + 1).B == 0)
                            {
                                Coordinate upCoordinate = new Coordinate();
                                upCoordinate.X = tempCoord.X;
                                upCoordinate.Y = tempCoord.Y + 1;
                                saveCoordinates.Add(upCoordinate);
                                qu.Enqueue(upCoordinate);
                            }

                            // 左下角
                            if ((tempCoord.X - 1 >= 0 && tempCoord.Y + 1 < height) && !IsSolveOne(saveCoordinates, tempCoord.X - 1, tempCoord.Y + 1) && bmp.GetPixel(tempCoord.X - 1, tempCoord.Y + 1).R == 0 && bmp.GetPixel(tempCoord.X - 1, tempCoord.Y + 1).G == 0 && bmp.GetPixel(tempCoord.X - 1, tempCoord.Y + 1).B == 0)
                            {
                                Coordinate upCoordinate = new Coordinate();
                                upCoordinate.X = tempCoord.X - 1;
                                upCoordinate.Y = tempCoord.Y + 1;
                                saveCoordinates.Add(upCoordinate);
                                qu.Enqueue(upCoordinate);
                            }

                            //　左边
                            if ((tempCoord.X - 1 >= 0 && tempCoord.Y < height) && !IsSolveOne(saveCoordinates, tempCoord.X - 1, tempCoord.Y) && bmp.GetPixel(tempCoord.X - 1, tempCoord.Y).R == 0 && bmp.GetPixel(tempCoord.X - 1, tempCoord.Y).G == 0 && bmp.GetPixel(tempCoord.X - 1, tempCoord.Y).B == 0)
                            {
                                Coordinate upCoordinate = new Coordinate();
                                upCoordinate.X = tempCoord.X - 1;
                                upCoordinate.Y = tempCoord.Y;
                                saveCoordinates.Add(upCoordinate);
                                qu.Enqueue(upCoordinate);
                            }

                            // 左上角
                            if ((tempCoord.X - 1 >= 0 && tempCoord.Y - 1 >= 0) && !IsSolveOne(saveCoordinates, tempCoord.X - 1, tempCoord.Y - 1) && bmp.GetPixel(tempCoord.X - 1, tempCoord.Y - 1).R == 0 && bmp.GetPixel(tempCoord.X - 1, tempCoord.Y - 1).G == 0 && bmp.GetPixel(tempCoord.X - 1, tempCoord.Y - 1).B == 0)
                            {
                                Coordinate upCoordinate = new Coordinate();
                                upCoordinate.X = tempCoord.X - 1;
                                upCoordinate.Y = tempCoord.Y - 1;
                                saveCoordinates.Add(upCoordinate);
                                qu.Enqueue(upCoordinate);
                            }
                        }

                        coordinates.Add(i + "-" + j, saveCoordinates);
                    }
                }
            }

            return coordinates;
        }

        private bool IsSolveOne(List<Coordinate> all, int x, int y)
        {
            Coordinate xx = all.Find(p => p.X == x && p.Y == y);
            if (xx == null)
            {
                return false;
            }

            return true;
        }

        #endregion
    }
}
