﻿using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace PictureSolveAlgorithm
{
    /// <summary>
    /// 获取有效区域
    /// </summary>
    public class GetValidRegionAlgorithm
    {
        /// <summary>
        /// 图片分割
        /// </summary>
        /// <returns>返回分割后的图片集合</returns>
        public static Bitmap DivisionImage(Bitmap bm)
        {
            Bitmap ImageCuted;
            StringBuilder strBuild = new StringBuilder();
            List<CutParamer> lsz = new List<CutParamer>();
            for (int i = 0; i < bm.Height; i++)
            {
                string k = string.Empty;
                for (int j = 0; j < bm.Width; j++)
                {
                    k += bm.GetPixel(j, i).R.ToString();
                }

                Color dd = Color.White;
                Color ccs = Color.Black;

                // 是否有黑点
                if (k.Contains("0"))
                {
                    // 有黑点
                    strBuild.Append(1);
                }
                else
                {
                    // 无黑点
                    strBuild.Append(0);
                }
            }

            // 开始计算所要截取的坐标

            // 是否记录初始值
            bool isrecord = true;

            // 初始横坐标
            int initialYlocal = 0;

            // 接收横坐标
            int receiveYlocal = 0;
            for (int i = 0; i < bm.Height; i++)
            {
                if (strBuild.ToString().Substring(i, 1) == "1")
                {
                    //遇见1
                    if (isrecord)
                    {
                        //第一次可以见到
                        isrecord = false;
                        initialYlocal = i;//记录初始坐标

                    }
                    if (strBuild.Length == i + 1)
                    {
                        //已经是1的终点
                        receiveYlocal = i;

                        //开始截取
                        CutParamer sss = new CutParamer() { X = initialYlocal, W = receiveYlocal - initialYlocal, };
                        lsz.Add(sss);
                    }
                }
            }

            ImageCuted = GetSegmentPicture(bm, lsz.ToArray());
            return ImageCuted;
        }


        /// <summary>
        /// 返回分割图片
        /// </summary>
        /// <param name="b">要分割的图片</param>
        /// <param name="s">分割参数</param>
        /// <returns>返回截取的图片</returns>
        public static Bitmap GetSegmentPicture(Bitmap b, CutParamer[] s)
        {
            Bitmap[] bs = new Bitmap[s.Count()];
            for (int q = 0; q < s.Count(); q++)
            {
                Bitmap bb = new Bitmap(b.Width, s[q].W);
                for (int i = s[q].X; i < s[q].X + s[q].W; i++)
                {
                    for (int j = 0; j < b.Width; j++)
                    {
                        bb.SetPixel(j, i - s[q].X, b.GetPixel(j, i));
                    }
                }

                bs[q] = bb;
            }

            return bs[0];
        }
    }
}
