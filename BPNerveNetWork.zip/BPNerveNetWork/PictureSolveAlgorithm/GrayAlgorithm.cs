﻿//-----------------------------------------------------------------------
// <copyright file="GrayAlgorithm.cs" company="517Na Enterprises">
// * Copyright (C) 2015 517Na科技有限公司 版权所有。
// * version : 2.0.50727.5485
// * author  : xukong
// * FileName: GrayAlgorithm.cs
// * history : created by xukong 2015-02-10 17:39:44 
// </copyright>
//-----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace PictureSolveAlgorithm
{
    /// <summary>
    /// 灰度化算法 
    /// </summary>
    public class GrayAlgorithm
    {
        /// <summary>
        /// 平均灰度法
        /// </summary>
        /// <param name="bit">图像</param>
        /// <returns>返回处理后的图像</returns>
        public static Bitmap AverageGray(Bitmap bit)
        {
            for (int i = 0; i < bit.Width; i++)
            {
                for (int j = 0; j < bit.Height; j++)
                {
                    // 获取该点的RGB值
                    Color color = bit.GetPixel(i, j);

                    // 利用公式计算灰度值
                    int gray = (int)(color.R + color.G + color.B) / 3;
                    Color newColor = Color.FromArgb(gray, gray, gray);
                    bit.SetPixel(i, j, newColor);
                }
            }

            return bit;
        }
    }
}
