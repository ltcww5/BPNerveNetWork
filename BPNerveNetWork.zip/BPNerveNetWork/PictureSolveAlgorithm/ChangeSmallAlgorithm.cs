﻿using System.Drawing;

namespace PictureSolveAlgorithm
{
    /// <summary>
    /// 细化算法
    /// </summary>
    public class ChangeSmallAlgorithm
    {
        /// <summary>
        /// 细化
        /// </summary>
        /// <param name="bmpobj"></param>
        /// <param name="dgGrayValue"></param>
        /// <returns></returns>
        public static Bitmap ChangeSmall(Bitmap bmpobj, int dgGrayValue)
        {
            int lWidth = bmpobj.Width;
            int lHeight = bmpobj.Height;
            bool bModified;            //脏标记    
            int i, j, n, m;            //循环变量
            Color pixel;    //像素颜色值

            //四个条件
            bool bCondition1;
            bool bCondition2;
            bool bCondition3;
            bool bCondition4;

            //计数器   
            int nCount;
            int[,] neighbour = new int[5, 5];    //5×5相邻区域像素值
            bModified = true;
            while (bModified)
            {
                bModified = false;

                //由于使用5×5的结构元素，为防止越界，所以不处理外围的几行和几列像素
                for (j = 2; j < lHeight - 2; j++)
                {
                    for (i = 2; i < lWidth - 2; i++)
                    {
                        bCondition1 = false;
                        bCondition2 = false;
                        bCondition3 = false;
                        bCondition4 = false;

                        if (bmpobj.GetPixel(i, j).R > dgGrayValue)
                        {
                            if (bmpobj.GetPixel(i, j).R < 255)
                                bmpobj.SetPixel(i, j, Color.White);
                            continue;
                        }

                        //获得当前点相邻的5×5区域内像素值，白色用0代表，黑色用1代表
                        for (m = 0; m < 5; m++)
                        {
                            for (n = 0; n < 5; n++)
                            {
                                neighbour[m, n] = bmpobj.GetPixel(i + m - 2, j + n - 2).R < dgGrayValue ? 0 : 1;
                            }
                        }

                        //逐个判断条件。
                        //判断2<=NZ(P1)<=6
                        nCount = neighbour[1, 1] + neighbour[1, 2] + neighbour[1, 3]
                                + neighbour[2, 1] + neighbour[2, 3] +
                                +neighbour[3, 1] + neighbour[3, 2] + neighbour[3, 3];
                        if (nCount >= 2 && nCount <= 6)
                        {
                            bCondition1 = true;
                        }

                        //判断Z0(P1)=1
                        nCount = 0;
                        if (neighbour[1, 2] == 0 && neighbour[1, 1] == 1)
                            nCount++;
                        if (neighbour[1, 1] == 0 && neighbour[2, 1] == 1)
                            nCount++;
                        if (neighbour[2, 1] == 0 && neighbour[3, 1] == 1)
                            nCount++;
                        if (neighbour[3, 1] == 0 && neighbour[3, 2] == 1)
                            nCount++;
                        if (neighbour[3, 2] == 0 && neighbour[3, 3] == 1)
                            nCount++;
                        if (neighbour[3, 3] == 0 && neighbour[2, 3] == 1)
                            nCount++;
                        if (neighbour[2, 3] == 0 && neighbour[1, 3] == 1)
                            nCount++;
                        if (neighbour[1, 3] == 0 && neighbour[1, 2] == 1)
                            nCount++;
                        if (nCount == 1)
                            bCondition2 = true;

                        //判断P2*P4*P8=0 or Z0(p2)!=1
                        if (neighbour[1, 2] * neighbour[2, 1] * neighbour[2, 3] == 0)
                        {
                            bCondition3 = true;
                        }
                        else
                        {
                            nCount = 0;
                            if (neighbour[0, 2] == 0 && neighbour[0, 1] == 1)
                                nCount++;
                            if (neighbour[0, 1] == 0 && neighbour[1, 1] == 1)
                                nCount++;
                            if (neighbour[1, 1] == 0 && neighbour[2, 1] == 1)
                                nCount++;
                            if (neighbour[2, 1] == 0 && neighbour[2, 2] == 1)
                                nCount++;
                            if (neighbour[2, 2] == 0 && neighbour[2, 3] == 1)
                                nCount++;
                            if (neighbour[2, 3] == 0 && neighbour[1, 3] == 1)
                                nCount++;
                            if (neighbour[1, 3] == 0 && neighbour[0, 3] == 1)
                                nCount++;
                            if (neighbour[0, 3] == 0 && neighbour[0, 2] == 1)
                                nCount++;
                            if (nCount != 1)
                                bCondition3 = true;
                        }

                        //判断P2*P4*P6=0 or Z0(p4)!=1
                        if (neighbour[1, 2] * neighbour[2, 1] * neighbour[3, 2] == 0)
                        {
                            bCondition4 = true;
                        }
                        else
                        {
                            nCount = 0;
                            if (neighbour[1, 1] == 0 && neighbour[1, 0] == 1)
                                nCount++;
                            if (neighbour[1, 0] == 0 && neighbour[2, 0] == 1)
                                nCount++;
                            if (neighbour[2, 0] == 0 && neighbour[3, 0] == 1)
                                nCount++;
                            if (neighbour[3, 0] == 0 && neighbour[3, 1] == 1)
                                nCount++;
                            if (neighbour[3, 1] == 0 && neighbour[3, 2] == 1)
                                nCount++;
                            if (neighbour[3, 2] == 0 && neighbour[2, 2] == 1)
                                nCount++;
                            if (neighbour[2, 2] == 0 && neighbour[1, 2] == 1)
                                nCount++;
                            if (neighbour[1, 2] == 0 && neighbour[1, 1] == 1)
                                nCount++;
                            if (nCount != 1)
                                bCondition4 = true;
                        }

                        if (bCondition1 && bCondition2 && bCondition3 && bCondition4)
                        {
                            bmpobj.SetPixel(i, j, Color.White);
                            bModified = true;
                        }
                        else
                        {
                            bmpobj.SetPixel(i, j, Color.Black);
                        }
                    }
                }
            }

            return bmpobj;
        }

        public static int GetPixNumber(Bitmap bitMap)
        {
            int result = 0;
            for (int i = 0; i < bitMap.Width; i++)
            {
                for (int j = 0; j < bitMap.Height; j++)
                {
                    Color c = bitMap.GetPixel(i, j);
                    if (c.R == 0 && c.G == 0 && c.B == 0)
                    {
                        result++;
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// 细化图像
        /// </summary>
        /// <param name="matrix"></param>
        /// <returns></returns>
        public static Bitmap ThinnerBitmap(Bitmap bitmap)
        {
            int[,] matrix = GetMatrix(bitmap);
            //matrix = ThinnerHilditch(matrix);
            int width = matrix.GetLength(0);
            int height = matrix.GetLength(1);

            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    if (matrix[i, j] == 1)
                    {
                        bitmap.SetPixel(i, j, Color.Black);
                    }
                    else if (matrix[i, j] == 0)
                    {
                        bitmap.SetPixel(i, j, Color.White);
                    }
                }
            }

            return bitmap;
        }

        ///// <summary>  
        ///// Hilditch细化算法  
        ///// </summary>  
        ///// <param name="input"></param>  
        ///// <returns></returns>  
        //private static int[,] ThinnerHilditch(int[,] input)
        //{
        //    int lWidth = input.GetLength(0);
        //    int lHeight = input.GetLength(1);

        //    bool IsModified = true;
        //    int Counter = 1;
        //    int[] nnb = new int[9];
        //    //去掉边框像素  
        //    for (int i = 0; i < lWidth; i++)
        //    {
        //        input[i, 0] = 0;
        //        input[i, lHeight - 1] = 0;
        //    }
        //    for (int j = 0; j < lHeight; j++)
        //    {
        //        input[0, j] = 0;
        //        input[lWidth - 1, j] = 0;
        //    }
        //    do
        //    {
        //        Counter++;
        //        IsModified = false;
        //        int[,] nb = new int[3, 3];
        //        for (int i = 1; i < lWidth; i++)
        //        {
        //            for (int j = 1; j < lHeight; j++)
        //            {
        //                //条件1必须为黑点  
        //                if (input[i, j] != 1)
        //                {
        //                    continue;
        //                }

        //                //取3*3领域  
        //                for (int m = 0; m < 3; m++)
        //                {
        //                    for (int n = 0; n < 3; n++)
        //                    {
        //                        nb[m, n] = input[i - 1 + m, j - 1 + n];
        //                    }
        //                }
        //                //复制  
        //                nnb[0] = nb[2, 1] == 1 ? 0 : 1;
        //                nnb[1] = nb[2, 0] == 1 ? 0 : 1;
        //                nnb[2] = nb[1, 0] == 1 ? 0 : 1;
        //                nnb[3] = nb[0, 0] == 1 ? 0 : 1;
        //                nnb[4] = nb[0, 1] == 1 ? 0 : 1;
        //                nnb[5] = nb[0, 2] == 1 ? 0 : 1;
        //                nnb[6] = nb[1, 2] == 1 ? 0 : 1;
        //                nnb[7] = nb[2, 2] == 1 ? 0 : 1;

        //                // 条件2：p0,p2,p4,p6 不皆为前景点   
        //                if (nnb[0] == 0 && nnb[2] == 0 && nnb[4] == 0 && nnb[6] == 0)
        //                {
        //                    continue;
        //                }
        //                // 条件3: p0~p7至少两个是前景点   
        //                int iCount = 0;
        //                for (int ii = 0; ii < 8; ii++)
        //                {
        //                    iCount += nnb[ii];
        //                }
        //                if (iCount > 6) continue;

        //                // 条件4：联结数等于1   
        //                if (DetectConnectivity(nnb) != 1)
        //                {
        //                    continue;
        //                }
        //                // 条件5: 假设p2已标记删除，则令p2为背景，不改变p的联结数   
        //                if (input[i, j - 1] == -1)
        //                {
        //                    nnb[2] = 1;
        //                    if (DetectConnectivity(nnb) != 1)
        //                        continue;
        //                    nnb[2] = 0;
        //                }
        //                // 条件6: 假设p4已标记删除，则令p4为背景，不改变p的联结数   
        //                if (input[i, j + 1] == -1)
        //                {
        //                    nnb[6] = 1;
        //                    if (DetectConnectivity(nnb) != 1)
        //                        continue;
        //                    nnb[6] = 0;
        //                }

        //                input[i, j] = -1;
        //                IsModified = true;
        //            }
        //        }
        //        for (int i = 0; i < lWidth; i++)
        //        {
        //            for (int j = 0; j < lHeight; j++)
        //            {
        //                if (input[i, j] == -1)
        //                {
        //                    input[i, j] = 0;
        //                }
        //            }
        //        }

        //    } while (IsModified);

        //    return input;
        //}


        /// <summary>
        /// 获取图像的矩阵信息
        /// </summary>
        /// <param name="bitMap"></param>
        /// <returns></returns>
        private static int[,] GetMatrix(Bitmap bitMap)
        {
            int width = bitMap.Width;
            int height = bitMap.Height;
            int[,] matrix = new int[width, height];
            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    Color c = bitMap.GetPixel(i, j);
                    if (c.ToArgb() == Color.Black.ToArgb())
                    {
                        matrix[i, j] = 1;
                    }
                    else
                    {
                        matrix[i, j] = 0;
                    }
                }
            }

            return matrix;
        }

    }
}
