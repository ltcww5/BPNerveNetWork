﻿using System.Drawing;
using System.Drawing.Drawing2D;

namespace PictureSolveAlgorithm
{
    public class ZoomAlgorithm
    {
        public static Bitmap ReduceImage(Bitmap bitMap, int toWidth, int toHeight)
        {
            Bitmap originBmp = bitMap;
            int w = toWidth;
            int h = toHeight;
            Bitmap resizedBmp = new Bitmap(w, h);
            Graphics g = Graphics.FromImage(resizedBmp);
            //////设置高质量插值法   
            g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.High;
            //设置高质量,低速度呈现平滑程度   
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            g.CompositingQuality = System.Drawing.Drawing2D.CompositingQuality.HighQuality;

            //消除锯齿 
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.DrawImage(originBmp, new Rectangle(0, 0, w, h), new Rectangle(0, 0, originBmp.Width, originBmp.Height), GraphicsUnit.Pixel);
           
            g.Dispose();
            originBmp.Dispose();
            return resizedBmp;
            //Bitmap originalImage = bitMap;
            //if (toWidth <= 0 && toHeight <= 0)
            //{
            //    return originalImage;
            //}

            //Image toBitmap = new Bitmap(toWidth, toHeight);
            //using (Graphics g = Graphics.FromImage(toBitmap))
            //{
            //    g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.High;
            //    g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            //    g.Clear(Color.Transparent);
            //    g.DrawImage(originalImage,
            //                new Rectangle(0, 0, toWidth, toHeight),
            //                new Rectangle(0, 0, originalImage.Width, originalImage.Height),
            //                GraphicsUnit.Pixel);
            //    originalImage.Dispose();
            //    return toBitmap as Bitmap;
            //}
        }
    }
}
