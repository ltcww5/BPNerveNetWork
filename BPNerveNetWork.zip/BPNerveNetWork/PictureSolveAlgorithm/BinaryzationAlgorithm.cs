﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;

namespace PictureSolveAlgorithm
{
    /// <summary>
    /// 二值化算法
    /// </summary>
    public class BinaryzationAlgorithm
    {
        /// <summary>
        /// 自适应阀值
        /// </summary>
        /// <param name="bmp"></param>
        /// <returns></returns>
        public static Bitmap AdaptThreshold(Bitmap bmp)
        {
            int average = 0;
            for (int i = 0; i < bmp.Width; i++)
            {
                for (int j = 0; j < bmp.Height; j++)
                {
                    Color color = bmp.GetPixel(i, j);
                    average += color.B;
                }
            }

            average = (int)average / (bmp.Width * bmp.Height);

            for (int i = 0; i < bmp.Width; i++)
            {
                for (int j = 0; j < bmp.Height; j++)
                {
                    //获取该点的像素的RGB的颜色
                    Color color = bmp.GetPixel(i, j);
                    int value = 255 - color.B;
                    Color newColor = value > average ? Color.FromArgb(0, 0, 0) : Color.FromArgb(255, 255, 255);
                    bmp.SetPixel(i, j, newColor);
                }
            }

            return bmp;
        }

        /// <summary>
        /// 动态阀值
        /// </summary>
        /// <param name="bmp"></param>
        /// <returns></returns>
        public static Bitmap DynamicThreshold(Bitmap img)
        {
            int w = img.Width;
            int h = img.Height;
            Bitmap bmp = new Bitmap(w, h, PixelFormat.Format1bppIndexed);
            BitmapData data = bmp.LockBits(new Rectangle(0, 0, w, h), ImageLockMode.ReadWrite, PixelFormat.Format1bppIndexed);
            for (int y = 0; y < h; y++)
            {
                byte[] scan = new byte[(w + 7) / 8];
                for (int x = 0; x < w; x++)
                {
                    Color c = img.GetPixel(x, y);
                    if (c.GetBrightness() >= 0.41)
                    {
                        scan[x / 8] |= (byte)(0x80 >> (x % 8));
                    }
                }

                Marshal.Copy(scan, 0, (IntPtr)((int)data.Scan0 + data.Stride * y), scan.Length);
            }

            bmp.UnlockBits(data);
            Bitmap bitMap = bmp.Clone(new Rectangle(0, 0, bmp.Width, bmp.Height), PixelFormat.Format32bppRgb);
            return bitMap;
        }

        /// <summary>
        /// 二值化 遍历每个点 点的亮度小于阀值 则认为是黑色 否则是白色
        /// </summary>
        public static Bitmap CVThreshold(Bitmap img)
        {
            var bitImg = new Bitmap(img);
            if (img != null)
            {
                for (var x = 0; x < img.Width; x++)
                {
                    for (var y = 0; y < img.Height; y++)
                    {
                        Color color = img.GetPixel(x, y);
                        ////if (color.R > 157)
                        ////{
                        ////    img.SetPixel(x, y, Color.White);
                        ////}
                        ////else
                        ////{
                        ////    img.SetPixel(x, y, Color.Black);
                        ////}
                        if (color.R > 127)
                        {
                            img.SetPixel(x, y, Color.White);
                        }
                        else
                        {
                            img.SetPixel(x, y, Color.Black);
                        }
                    }
                }

                bitImg = img;
            }

            return bitImg;
        }


    }
}
