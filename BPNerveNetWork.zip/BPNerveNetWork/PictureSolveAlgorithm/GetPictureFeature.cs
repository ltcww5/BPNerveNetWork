﻿using System.Drawing;
using System.Collections.Generic;

namespace PictureSolveAlgorithm
{
    /// <summary>
    /// 获取图片特征
    /// </summary>
    public class GetPictureFeature
    {
        /// <summary>
        /// 获取图像特征
        /// </summary>
        /// <param name="bitMap">图像</param>
        /// <returns>返回特征矩阵</returns>
        public static double[,] GetPicFeature(List<Bitmap> bitMaps)
        {
            int width = bitMaps[0].Width;
            int height = bitMaps[0].Height;
            int line = 0;
            double[,] resuMa = new double[bitMaps.Count, width * height];
            foreach (var bitMap in bitMaps)
            {
                int toal = 0;
                double[,] result = new double[width, height];
                for (int i = 0; i < width; i++)
                {
                    for (int j = 0; j < height; j++)
                    {
                        Color color = bitMap.GetPixel(i, j);
                        if (color.R != 255 && color.G != 255 && color.B != 255)
                        {
                            result[i, j] = 0.9f;
                        }
                        else
                        {
                            result[i, j] = 0.1f;
                        }

                        resuMa[line, toal] = result[i, j];
                        toal++;
                    }
                }

                line++;
            }

            return resuMa;
        }
    }
}
