﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PictureSolveAlgorithm
{
    /// <summary>
    /// 坐标
    /// </summary>
    public class Coordinate
    {
        private int x = 0;


        private int y = 0;

        public int Y
        {
            get { return this.y; }
            set { this.y = value; }
        }



        public int X
        {
            get { return this.x; }
            set { this.x = value; }
        }

    }
}
