﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;


namespace PictureSolveAlgorithm
{
    /// <summary>
    /// 宽度优先搜索
    /// </summary>
    public class BFS
    {
        private List<Coordinate> moveDirection = new List<Coordinate>();

        public static Coordinate[,] preMove = null;

        private int[,] InitMaze = null;

        private int width = 0;
        private int height = 0;

        public BFS(Bitmap bmp)
        {
            width = bmp.Width;
            height = bmp.Height;
            InitMaze = new int[width, height];
            preMove = new Coordinate[width, height];

            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    Color colr = bmp.GetPixel(i, j);
                    if (colr.R == 0 && colr.G == 0 && colr.B == 0)
                    {
                        InitMaze[i, j] = 1;
                    }
                    else
                    {
                        InitMaze[i, j] = 0;
                    }
                }
            }


            Coordinate one = new Coordinate();
            one.X = 1;
            one.Y = -1;
            Coordinate two = new Coordinate();
            two.X = 1;
            two.Y = 0;
            Coordinate three = new Coordinate();
            three.X = 1;
            three.Y = 1;

            moveDirection.Add(one);
            moveDirection.Add(two);
            moveDirection.Add(three);
        }

        public bool MovePath(int row, int colum, int x, int y)
        {
            // 因为不确定列，所以确定行的大致范围就以了
            if (x == row && y == colum)
            {
                return true;
            }

            Queue qu = new Queue();
            Coordinate currentLocal = new Coordinate();
            currentLocal.X = x;
            currentLocal.Y = y;
            qu.Enqueue(currentLocal);
            while (qu.Count > 0)
            {
                // 弹出第一个
                Coordinate firstCoordinate = (Coordinate)qu.Dequeue();

                for (int i = 0; i < 3; i++)
                {
                    if (firstCoordinate.X + moveDirection[i].X >= 0 && firstCoordinate.X + moveDirection[i].X < width && firstCoordinate.Y + moveDirection[i].Y >= 0 && firstCoordinate.Y + moveDirection[i].Y < height)
                    {
                        if (firstCoordinate.X + moveDirection[i].X == row && firstCoordinate.Y + moveDirection[i].Y == colum)
                        {
                            InitMaze[firstCoordinate.X + moveDirection[i].X, firstCoordinate.Y + moveDirection[i].Y] = -1;
                            preMove[row, colum] = firstCoordinate;
                            return true;
                        }

                        if (InitMaze[firstCoordinate.X + moveDirection[i].X, firstCoordinate.Y + moveDirection[i].Y] == 1)
                        {
                            Coordinate temp = new Coordinate();
                            temp.X = firstCoordinate.X + moveDirection[i].X;
                            temp.Y = firstCoordinate.Y + moveDirection[i].Y;
                            qu.Enqueue(temp);
                            InitMaze[temp.X, temp.Y] = -1;
                            preMove[temp.X, temp.Y] = firstCoordinate;
                        }
                    }

                }
            }

            return false;
        }



    }
}
