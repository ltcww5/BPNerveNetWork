﻿//-----------------------------------------------------------------------
// <copyright file="ShapeContextAlgorithm.cs" company="517Na Enterprises">
// * Copyright (C) 2015 517Na科技有限公司 版权所有。
// * version : 2.0.50727.5485
// * author  : xukong
// * FileName: ShapeContextAlgorithm.cs
// * history : created by xukong 2015-02-15 15:03:28 
// </copyright>
//-----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace PictureSolveAlgorithm.MUB2C
{
    /// <summary>
    /// 形状上下文算法
    /// </summary>
    public class ShapeContextAlgorithm
    {
        /// <summary>
        /// 图像
        /// </summary>
        private Bitmap bitMap = null;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="bitMap">图像</param>
        public ShapeContextAlgorithm(Bitmap bitMap)
        {
            this.bitMap = bitMap;
        }
        


    }
}
