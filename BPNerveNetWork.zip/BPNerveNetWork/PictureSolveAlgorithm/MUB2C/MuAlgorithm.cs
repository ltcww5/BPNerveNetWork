﻿
using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;


namespace PictureSolveAlgorithm
{
    public class MuAlgorithm
    {
        private static List<Coordinate> allSolveCoordinate = new List<Coordinate>();

        private static List<Coordinate> allSolveCoordinateOne = new List<Coordinate>();

        /// <summary>
        /// 小于一定阀值的部分变为白色
        /// </summary>
        /// <param name="bmp"></param>
        /// <param name="threshold"></param>
        /// <returns></returns>
        public static Bitmap ChangeWhite(Bitmap bmp, int threshold)
        {
            int width = bmp.Width;
            int height = bmp.Height;
            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    Color color = bmp.GetPixel(i, j);
                    if (color.R > threshold)
                    {
                        bmp.SetPixel(i, j, Color.White);
                    }
                    else
                    {
                        bmp.SetPixel(i, j, Color.Black);
                    }
                }
            }

            return bmp;
        }

        /// <summary>
        /// 获得以某个点为起点的连通域
        /// </summary>
        /// <param name="bmp"></param>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <returns></returns>
        public static Dictionary<string, List<Coordinate>> GetConnectDomain(Bitmap bmp)
        {
            Dictionary<string, List<Coordinate>> coordinates = new Dictionary<string, List<Coordinate>>();
            // 以八连通域作为标准作为扫描窗口
            int width = bmp.Width;
            int height = bmp.Height;
            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    Color color = bmp.GetPixel(i, j);

                    // 黑色像素点并且不包含
                    if ((color.R == 0 && color.G == 0 && color.B == 0) && IsSolve(coordinates, i, j) == false)
                    {
                        Coordinate cor = new Coordinate();
                        cor.X = i;
                        cor.Y = j;
                        Queue qu = new Queue();
                        qu.Enqueue(cor);

                        List<Coordinate> saveCoordinates = new List<Coordinate>();
                        saveCoordinates.Add(cor);
                        while (qu.Count > 0)
                        {
                            Coordinate tempCoord = (Coordinate)qu.Dequeue();

                            // 判断这个点的上方是否有点
                            if (tempCoord.Y - 1 >= 0 && !IsSolveOne(saveCoordinates, tempCoord.X, tempCoord.Y - 1) && bmp.GetPixel(tempCoord.X, tempCoord.Y - 1).R == 0 && bmp.GetPixel(tempCoord.X, tempCoord.Y - 1).G == 0 && bmp.GetPixel(tempCoord.X, tempCoord.Y - 1).B == 0)
                            {
                                Coordinate upCoordinate = new Coordinate();
                                upCoordinate.X = tempCoord.X;
                                upCoordinate.Y = tempCoord.Y - 1;
                                saveCoordinates.Add(upCoordinate);
                                qu.Enqueue(upCoordinate);
                            }

                            // 右上方
                            if ((tempCoord.X + 1 < width && tempCoord.Y - 1 >= 0) && !IsSolveOne(saveCoordinates, tempCoord.X + 1, tempCoord.Y - 1) && bmp.GetPixel(tempCoord.X + 1, tempCoord.Y - 1).R == 0 && bmp.GetPixel(tempCoord.X + 1, tempCoord.Y - 1).G == 0 && bmp.GetPixel(tempCoord.X + 1, tempCoord.Y - 1).B == 0)
                            {
                                Coordinate upCoordinate = new Coordinate();
                                upCoordinate.X = tempCoord.X + 1;
                                upCoordinate.Y = tempCoord.Y - 1;
                                saveCoordinates.Add(upCoordinate);
                                qu.Enqueue(upCoordinate);
                            }

                            // 右边
                            if ((tempCoord.X + 1 < width) && !IsSolveOne(saveCoordinates, tempCoord.X + 1, tempCoord.Y) && bmp.GetPixel(tempCoord.X + 1, tempCoord.Y).R == 0 && bmp.GetPixel(tempCoord.X + 1, tempCoord.Y).G == 0 && bmp.GetPixel(tempCoord.X + 1, tempCoord.Y).B == 0)
                            {
                                Coordinate upCoordinate = new Coordinate();
                                upCoordinate.X = tempCoord.X + 1;
                                upCoordinate.Y = tempCoord.Y;
                                saveCoordinates.Add(upCoordinate);
                                qu.Enqueue(upCoordinate);
                            }

                            // 右下角
                            if ((tempCoord.X + 1 < width && tempCoord.Y + 1 < height) && !IsSolveOne(saveCoordinates, tempCoord.X + 1, tempCoord.Y + 1) && bmp.GetPixel(tempCoord.X + 1, tempCoord.Y + 1).R == 0 && bmp.GetPixel(tempCoord.X + 1, tempCoord.Y + 1).G == 0 && bmp.GetPixel(tempCoord.X + 1, tempCoord.Y + 1).B == 0)
                            {
                                Coordinate upCoordinate = new Coordinate();
                                upCoordinate.X = tempCoord.X + 1;
                                upCoordinate.Y = tempCoord.Y + 1;
                                saveCoordinates.Add(upCoordinate);
                                qu.Enqueue(upCoordinate);
                            }

                            // 下边
                            if ((tempCoord.Y + 1 < height) && !IsSolveOne(saveCoordinates, tempCoord.X, tempCoord.Y + 1) && bmp.GetPixel(tempCoord.X, tempCoord.Y + 1).R == 0 && bmp.GetPixel(tempCoord.X, tempCoord.Y + 1).G == 0 && bmp.GetPixel(tempCoord.X, tempCoord.Y + 1).B == 0)
                            {
                                Coordinate upCoordinate = new Coordinate();
                                upCoordinate.X = tempCoord.X;
                                upCoordinate.Y = tempCoord.Y + 1;
                                saveCoordinates.Add(upCoordinate);
                                qu.Enqueue(upCoordinate);
                            }

                            // 左下角
                            if ((tempCoord.X - 1 >= 0 && tempCoord.Y + 1 < height) && !IsSolveOne(saveCoordinates, tempCoord.X - 1, tempCoord.Y + 1) && bmp.GetPixel(tempCoord.X - 1, tempCoord.Y + 1).R == 0 && bmp.GetPixel(tempCoord.X - 1, tempCoord.Y + 1).G == 0 && bmp.GetPixel(tempCoord.X - 1, tempCoord.Y + 1).B == 0)
                            {
                                Coordinate upCoordinate = new Coordinate();
                                upCoordinate.X = tempCoord.X - 1;
                                upCoordinate.Y = tempCoord.Y + 1;
                                saveCoordinates.Add(upCoordinate);
                                qu.Enqueue(upCoordinate);
                            }

                            //　左边
                            if ((tempCoord.X - 1 >= 0 && tempCoord.Y < height) && !IsSolveOne(saveCoordinates, tempCoord.X - 1, tempCoord.Y) && bmp.GetPixel(tempCoord.X - 1, tempCoord.Y).R == 0 && bmp.GetPixel(tempCoord.X - 1, tempCoord.Y).G == 0 && bmp.GetPixel(tempCoord.X - 1, tempCoord.Y).B == 0)
                            {
                                Coordinate upCoordinate = new Coordinate();
                                upCoordinate.X = tempCoord.X - 1;
                                upCoordinate.Y = tempCoord.Y;
                                saveCoordinates.Add(upCoordinate);
                                qu.Enqueue(upCoordinate);
                            }

                            // 左上角
                            if ((tempCoord.X - 1 >= 0 && tempCoord.Y - 1 >= 0) && !IsSolveOne(saveCoordinates, tempCoord.X - 1, tempCoord.Y - 1) && bmp.GetPixel(tempCoord.X - 1, tempCoord.Y - 1).R == 0 && bmp.GetPixel(tempCoord.X - 1, tempCoord.Y - 1).G == 0 && bmp.GetPixel(tempCoord.X - 1, tempCoord.Y - 1).B == 0)
                            {
                                Coordinate upCoordinate = new Coordinate();
                                upCoordinate.X = tempCoord.X - 1;
                                upCoordinate.Y = tempCoord.Y - 1;
                                saveCoordinates.Add(upCoordinate);
                                qu.Enqueue(upCoordinate);
                            }
                        }

                        coordinates.Add(i + "-" + j, saveCoordinates);
                    }
                }
            }

            return coordinates;
        }

        private static bool IsSolveOne(List<Coordinate> all, int x, int y)
        {
            Coordinate xx = all.Find(p => p.X == x && p.Y == y);
            if (xx == null)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// 获取主要的连通域
        /// </summary>
        /// <param name="bitmap"></param>
        /// <param name="threshold"></param>
        /// <returns></returns>
        public static Bitmap GetMainConnection(Bitmap bitmap, int threshold)
        {
            Dictionary<string, List<Coordinate>> dic = GetConnectDomain(bitmap);
            foreach (KeyValuePair<string, List<Coordinate>> co in dic)
            {
                if (co.Value.Count < threshold)
                {
                    // 置为白色
                    foreach (var coOne in co.Value)
                    {
                        bitmap.SetPixel(coOne.X, coOne.Y, Color.White);
                    }
                }
            }

            return bitmap;
        }

        /// <summary>
        /// 获取主要的连通域
        /// </summary>
        /// <param name="bitmap"></param>
        /// <param name="threshold"></param>
        /// <returns></returns>
        public static Bitmap GetMainConnectionOne(Bitmap bitmap, int threshold)
        {
            Dictionary<string, List<Coordinate>> dic = GetConnectDomain(bitmap);
            foreach (KeyValuePair<string, List<Coordinate>> co in dic)
            {
                if (co.Value.Count < threshold)
                {
                    // 置为白色
                    foreach (var coOne in co.Value)
                    {
                        bitmap.SetPixel(coOne.X, coOne.Y, Color.White);
                    }
                }
            }

            return bitmap;
        }


        /// <summary>
        /// 是否已经存在于其他连通域
        /// </summary>
        /// <param name="dic"></param>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <returns></returns>
        public static bool IsSolve(Dictionary<string, List<Coordinate>> dic, int x, int y)
        {
            bool result = false;
            foreach (KeyValuePair<string, List<Coordinate>> keyValue in dic)
            {
                foreach (var one in keyValue.Value)
                {
                    if (one.X == x && one.Y == y)
                    {
                        result = true;
                        return result;
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// 去掉比较小的连通域
        /// </summary>
        /// <param name="bitMap"></param>
        /// <param name="threshold"></param>
        /// <returns></returns>
        public static Bitmap KillSmallConnectiion(Bitmap bitMap, int threshold)
        {
            for (int i = 0; i < bitMap.Width; i++)
            {
                for (int j = 0; j < bitMap.Height; j++)
                {
                    Color color = bitMap.GetPixel(i, j);
                    if (color.R == 0 && color.G == 0 && color.B == 0)
                    {
                        if (j - 1 > 0 && bitMap.GetPixel(i, j - 1).R == 0)
                        {

                        }
                        else if (j + 1 < bitMap.Height && bitMap.GetPixel(i, j + 1).R == 0)
                        {

                        }
                        else
                        {
                            bitMap.SetPixel(i, j, Color.White);
                        }


                    }
                }
            }

            return bitMap;
        }

        /// <summary>
        /// 获取第一列的点
        /// </summary>
        /// <param name="img"></param>
        /// <returns></returns>
        public static List<Coordinate> GetFirstPoint(Bitmap img)
        {
            int width = img.Width;
            int height = img.Height;
            bool flag = false;
            List<Coordinate> firstCoordinate = new List<Coordinate>();
            for (int i = width - 1; i >= 0; i--)
            {
                if (flag == true)
                {
                    break;
                }

                for (int j = height - 1; j >= 0; j--)
                {
                    Color color = img.GetPixel(i, j);
                    if (color.R == 0 && color.G == 0 && color.B == 0)
                    {
                        Coordinate coordinate = new Coordinate();
                        coordinate.X = i;
                        coordinate.Y = j;
                        firstCoordinate.Add(coordinate);
                        flag = true;
                    }
                }
            }

            return firstCoordinate;
        }

        /// <summary>
        /// 获取第一列的点
        /// </summary>
        /// <param name="img"></param>
        /// <returns></returns>
        public static List<Coordinate> GetSecondPoint(Bitmap img)
        {
            int width = img.Width;
            int height = img.Height;
            int flag = 0;
            List<Coordinate> firstCoordinate = new List<Coordinate>();
            for (int i = 0; i < img.Width; i++)
            {
                flag++;
                if (flag == 3)
                {
                    break;
                }

                for (int j = 0; j < height; j++)
                {
                    Color color = img.GetPixel(i, j);
                    if (color.R == 0 && color.G == 0 && color.B == 0)
                    {
                        Coordinate coordinate = new Coordinate();
                        coordinate.X = i;
                        coordinate.Y = j;
                        firstCoordinate.Add(coordinate);
                    }
                }
            }

            return firstCoordinate;
        }


        /// <summary>
        /// 标记干扰线
        /// </summary>
        /// <param name="bitmap"></param>
        /// <returns></returns>
        public static Bitmap MarkLine(Bitmap bitmap)
        {
            List<Coordinate> coordinates = GetFirstPoint(bitmap);
            foreach (var coo in coordinates)
            {
                List<Coordinate> oneConnecion = GetOneConnectionDomain(bitmap, coo);
                bitmap.SetPixel(coo.X, coo.Y, Color.Red);
                GetSmallDistance(bitmap, oneConnecion, coo);
            }

            return bitmap;
        }

        /// <summary>
        /// 标记干扰线
        /// </summary>
        /// <param name="bitmap"></param>
        /// <returns></returns>
        public static Bitmap MarkLineOne(Bitmap bitmap)
        {
            Coordinate yuan = GetMaxWidth(bitmap);
            List<Coordinate> coordinates = GetSecondPoint(bitmap);
            // 只需要标记最长的点

            foreach (var coo in coordinates)
            {
                int width = bitmap.Width;
                int height = bitmap.Height;
                List<Coordinate> oneConnecion = GetOneConnectionDomain(bitmap, coo);
                BFS bfs = new BFS(bitmap);
                bool res = bfs.MovePath(yuan.X, yuan.Y, coo.X, coo.Y);
                Coordinate my = new Coordinate();
                my = yuan;
                if (res == true)
                {
                    // 把拿到的点且距离最短的点标记为红色
                    for (int i = width - 1; i >= 0; i--)
                    {
                        Coordinate hh = GetSmallL(my, height, i);
                        if (hh != null)
                        {
                            my = hh;
                            bitmap.SetPixel(my.X, my.Y, Color.Red);
                        }
                    }
                }

                BFS.preMove = null;
            }

            return bitmap;
        }

        /// <summary>
        /// 找到最宽的点
        /// </summary>
        /// <param name="bitmap"></param>
        /// <returns></returns>
        private static Coordinate GetMaxWidth(Bitmap bitmap)
        {
            int width = bitmap.Width;
            int height = bitmap.Height;
            int maxWidth = 0;
            Coordinate result = new Coordinate();
            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    Color color = bitmap.GetPixel(i, j);
                    if (color.R == 0 && color.G == 0 && color.B == 0)
                    {
                        if (maxWidth < i)
                        {
                            maxWidth = i;
                            result.X = i;
                            result.Y = j;
                        }
                    }
                }
            }

            return result;
        }

        private static Coordinate GetSmallL(Coordinate mm, int height, int line)
        {
            double res = -1;
            Coordinate result = null;
            for (int i = 0; i < height; i++)
            {
                Coordinate my = BFS.preMove[line, i];
                if (my != null)
                {
                    double dd = Math.Sqrt((mm.X - my.X) * (mm.X - my.X) + (mm.Y - my.Y) * (mm.Y - my.Y));
                    if (res != -1 && res == dd && mm.Y == my.Y)
                    {
                        result = new Coordinate();
                        res = dd;
                        result.X = my.X;
                        result.Y = my.Y;
                    }
                    if (res != -1 && res > dd)
                    {
                        result = new Coordinate();
                        res = dd;
                        result.X = my.X;
                        result.Y = my.Y;
                    }
                    else if (res == -1)
                    {
                        result = new Coordinate();
                        res = dd;
                        result.X = my.X;
                        result.Y = my.Y;
                    }
                }

            }

            return result;

        }


        private static Coordinate Find(List<Coordinate> DD)
        {
            int maxX = 0;
            Coordinate maxCoo = new Coordinate();
            foreach (var cc in DD)
            {
                if (cc.X > maxX)
                {
                    maxX = cc.X;
                    maxCoo.X = cc.X;
                    maxCoo.Y = cc.Y;
                }
            }

            return maxCoo;
        }

        /// <summary>
        /// 拿到最小距离
        /// </summary>
        /// <param name="bmp"></param>
        /// <param name="oneConnecion"></param>
        /// <param name="co"></param>
        /// <returns></returns>
        public static Bitmap GetSmallDistance(Bitmap bmp, List<Coordinate> oneConnecion, Coordinate co)
        {
            // 拿到包含的附近的点
            List<Coordinate> coos = EightDirction(bmp, oneConnecion, co);

            // 去除已经算过距离的点
            coos = PickPoint(coos, allSolveCoordinate);

            if (coos != null && coos.Count > 0)
            {
                // 寻找距离最小的点
                Coordinate oneDinate = Small(co, coos);
                allSolveCoordinate.Add(co);
                bmp.SetPixel(oneDinate.X, oneDinate.Y, Color.Red);
                GetSmallDistance(bmp, oneConnecion, oneDinate);
            }

            return bmp;
        }


        /// <summary>
        /// 拿到最小距离
        /// </summary>
        /// <param name="bmp"></param>
        /// <param name="oneConnecion"></param>
        /// <param name="co"></param>
        /// <returns></returns>
        public static Bitmap GetSmallDistanceOne(Bitmap bmp, List<Coordinate> oneConnecion, Coordinate co)
        {
            // 拿到包含的附近的点
            List<Coordinate> coos = EightDirction(bmp, oneConnecion, co);

            // 去除已经算过距离的点
            coos = PickPoint(coos, allSolveCoordinateOne);

            if (coos != null && coos.Count > 0)
            {
                // 把拿到的所有点全部标红
                foreach (var hh in coos)
                {
                    bmp.SetPixel(hh.X, hh.Y, Color.Red);
                    allSolveCoordinateOne.Add(hh);
                    GetSmallDistanceOne(bmp, oneConnecion, hh);
                }
            }

            return bmp;
        }

        private static List<Coordinate> PickPoint(List<Coordinate> one, List<Coordinate> two)
        {
            List<Coordinate> ts = new List<Coordinate>();
            if (one != null)
            {
                foreach (var g in one)
                {
                    bool dd = two.Exists(p => p.X == g.X && p.Y == g.Y);
                    if (dd == false)
                    {
                        ts.Add(g);
                    }
                }
            }

            return ts;
        }

        public static Bitmap RemoveRed(Bitmap bmp)
        {
            int width = bmp.Width;
            int height = bmp.Height;
            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    //if (i < 15)
                    //{
                    //    // 去除红色线周围八个点
                    //    for (int m = -1; m <= 1; m++)
                    //    {
                    //        if (i + m >= 0 && i + m < width)
                    //        {
                    //            bmp.SetPixel(i + m, j, Color.White);
                    //        }
                    //    }
                    //}

                    Color color = bmp.GetPixel(i, j);
                    if (color.R == 255 && color.G == 0 && color.B == 0)
                    {
                        bmp.SetPixel(i, j, Color.White);
                    }
                }

            }

            return bmp;
        }

        /// <summary>
        /// 获取最小距离的点
        /// </summary>
        /// <param name="co"></param>
        /// <param name="allc"></param>
        /// <returns></returns>
        public static Coordinate Small(Coordinate co, List<Coordinate> allc)
        {
            double gap = 0;
            Coordinate dinate = new Coordinate();
            bool flag = false;
            foreach (var one in allc)
            {
                // 只取向右延伸的地方
                if (one.X < co.X)
                {
                    double temp = Math.Sqrt((one.X - co.X) * (one.X - co.X) + (one.Y - co.Y) * (one.Y - co.Y));
                    if (gap != 0 && temp <= gap)
                    {
                        if (one.Y == co.Y)
                        {
                            dinate.X = one.X;
                            dinate.Y = one.Y;
                            gap = temp;
                            flag = true;
                        }
                        else if (flag == true)
                        {
                            dinate.X = one.X;
                            dinate.Y = dinate.Y;
                            gap = temp;
                        }
                        else
                        {
                            dinate.X = one.X;
                            dinate.Y = one.Y;
                            gap = temp;
                        }
                    }
                    else if (gap == 0)
                    {
                        gap = temp;
                        dinate.X = one.X;
                        dinate.Y = one.Y;
                    }
                }
            }

            return dinate;
        }


        /// <summary>
        /// 获取最小距离的点
        /// </summary>
        /// <param name="co"></param>
        /// <param name="allc"></param>
        /// <returns></returns>
        public static Coordinate SmallOne(Coordinate co, List<Coordinate> allc)
        {
            double gap = 0;
            Coordinate dinate = new Coordinate();
            bool flag = false;
            foreach (var one in allc)
            {
                // 只取向右延伸的地方
                if (one.X > co.X)
                {
                    double temp = Math.Sqrt((one.X - co.X) * (one.X - co.X) + (one.Y - co.Y) * (one.Y - co.Y));
                    if (gap != 0 && temp <= gap)
                    {
                        dinate.X = one.X;
                        dinate.Y = one.Y;
                        gap = temp;
                        flag = true;
                    }
                    else if (gap == 0)
                    {
                        gap = temp;
                        dinate.X = one.X;
                        dinate.Y = one.Y;
                    }
                }
            }

            return dinate;
        }

        /// <summary>
        /// 包含在八个点附近的点
        /// </summary>
        /// <param name="bmp"></param>
        /// <param name="oneConnecion"></param>
        /// <param name="co"></param>
        /// <returns></returns>
        public static List<Coordinate> EightDirction(Bitmap bmp, List<Coordinate> oneConnecion, Coordinate co)
        {
            int width = bmp.Width;
            int height = bmp.Height;
            int x = co.X;
            int y = co.Y;
            List<Coordinate> all = new List<Coordinate>();
            List<Coordinate> allTest = new List<Coordinate>();

            // 上方
            if (y - 1 > 0 && bmp.GetPixel(x, y - 1).R == 0 && bmp.GetPixel(x, y - 1).G == 0 && bmp.GetPixel(x, y - 1).B == 0)
            {
                Coordinate up = new Coordinate();
                up.X = x;
                up.Y = y - 1;
                all.Add(up);
            }

            // 右上角
            if (y - 1 > 0 && x + 1 < width && bmp.GetPixel(x + 1, y - 1).R == 0 && bmp.GetPixel(x + 1, y - 1).G == 0 && bmp.GetPixel(x + 1, y - 1).B == 0)
            {
                Coordinate up = new Coordinate();
                up.X = x + 1;
                up.Y = y - 1;
                all.Add(up);
            }

            // 右边
            if (x + 1 < width && bmp.GetPixel(x + 1, y).R == 0 && bmp.GetPixel(x + 1, y).G == 0 && bmp.GetPixel(x + 1, y).B == 0)
            {
                Coordinate up = new Coordinate();
                up.X = x + 1;
                up.Y = y;
                all.Add(up);
            }


            // 右下角
            if (y + 1 < height && x + 1 < width && bmp.GetPixel(x + 1, y + 1).R == 0 && bmp.GetPixel(x + 1, y + 1).G == 0 && bmp.GetPixel(x + 1, y + 1).B == 0)
            {
                Coordinate up = new Coordinate();
                up.X = x + 1;
                up.Y = y + 1;
                all.Add(up);
            }

            // 下边
            if (y + 1 < height && bmp.GetPixel(x, y + 1).R == 0 && bmp.GetPixel(x, y + 1).G == 0 && bmp.GetPixel(x, y + 1).B == 0)
            {
                Coordinate up = new Coordinate();
                up.X = x;
                up.Y = y + 1;
                all.Add(up);
            }

            // 右下角
            if (y + 1 < height && x + 1 < width && bmp.GetPixel(x + 1, y + 1).R == 0 && bmp.GetPixel(x + 1, y + 1).G == 0 && bmp.GetPixel(x + 1, y + 1).B == 0)
            {
                Coordinate up = new Coordinate();
                up.X = x + 1;
                up.Y = y + 1;
                all.Add(up);
            }

            //// 左下角
            //if (y + 1 < height && x - 1 > 0 && bmp.GetPixel(x - 1, y + 1).R == 0 && bmp.GetPixel(x - 1, y + 1).G == 0 && bmp.GetPixel(x - 1, y + 1).B == 0)
            //{
            //    Coordinate up = new Coordinate();
            //    up.X = x - 1;
            //    up.Y = y + 1;
            //    all.Add(up);
            //}


            //// 左边
            //if (x - 1 > 0 && bmp.GetPixel(x - 1, y).R == 0 && bmp.GetPixel(x - 1, y).G == 0 && bmp.GetPixel(x - 1, y).B == 0)
            //{
            //    Coordinate up = new Coordinate();
            //    up.X = x - 1;
            //    up.Y = y;
            //    all.Add(up);
            //}


            //// 左上角
            //if (x - 1 > 0 && y - 1 > 0 && bmp.GetPixel(x - 1, y - 1).R == 0 && bmp.GetPixel(x - 1, y - 1).G == 0 && bmp.GetPixel(x - 1, y - 1).B == 0)
            //{
            //    Coordinate up = new Coordinate();
            //    up.X = x - 1;
            //    up.Y = y - 1;
            //    all.Add(up);
            //}

            foreach (var one in all)
            {
                bool res = oneConnecion.Exists(p => p.X == one.X && p.Y == one.Y);
                if (res == true)
                {
                    allTest.Add(one);
                }

            }

            return allTest;
        }

        /// <summary>
        /// 某个点的获取连通域
        /// </summary>
        /// <param name="bmp"></param>
        /// <param name="co"></param>
        /// <returns></returns>
        public static List<Coordinate> GetOneConnectionDomain(Bitmap bmp, Coordinate co)
        {
            int width = bmp.Width;
            int height = bmp.Height;
            Queue qu = new Queue();
            qu.Enqueue(co);
            List<Coordinate> saveCoordinates = new List<Coordinate>();
            while (qu.Count > 0)
            {
                Coordinate tempCoord = (Coordinate)qu.Dequeue();

                // 判断这个点的上方是否有点
                if (tempCoord.Y - 1 > 0 && !IsSolveOne(saveCoordinates, tempCoord.X, tempCoord.Y - 1) && bmp.GetPixel(tempCoord.X, tempCoord.Y - 1).R == 0 && bmp.GetPixel(tempCoord.X, tempCoord.Y - 1).G == 0 && bmp.GetPixel(tempCoord.X, tempCoord.Y - 1).B == 0)
                {
                    Coordinate upCoordinate = new Coordinate();
                    upCoordinate.X = tempCoord.X;
                    upCoordinate.Y = tempCoord.Y - 1;
                    saveCoordinates.Add(upCoordinate);
                    qu.Enqueue(upCoordinate);
                }

                // 右上方
                if ((tempCoord.X + 1 < width && tempCoord.Y - 1 > 0) && !IsSolveOne(saveCoordinates, tempCoord.X + 1, tempCoord.Y - 1) && bmp.GetPixel(tempCoord.X + 1, tempCoord.Y - 1).R == 0 && bmp.GetPixel(tempCoord.X + 1, tempCoord.Y - 1).G == 0 && bmp.GetPixel(tempCoord.X + 1, tempCoord.Y - 1).B == 0)
                {
                    Coordinate upCoordinate = new Coordinate();
                    upCoordinate.X = tempCoord.X + 1;
                    upCoordinate.Y = tempCoord.Y - 1;
                    saveCoordinates.Add(upCoordinate);
                    qu.Enqueue(upCoordinate);
                }

                // 右边
                if ((tempCoord.X + 1 < width) && !IsSolveOne(saveCoordinates, tempCoord.X + 1, tempCoord.Y) && bmp.GetPixel(tempCoord.X + 1, tempCoord.Y).R == 0 && bmp.GetPixel(tempCoord.X + 1, tempCoord.Y).G == 0 && bmp.GetPixel(tempCoord.X + 1, tempCoord.Y).B == 0)
                {
                    Coordinate upCoordinate = new Coordinate();
                    upCoordinate.X = tempCoord.X + 1;
                    upCoordinate.Y = tempCoord.Y;
                    saveCoordinates.Add(upCoordinate);
                    qu.Enqueue(upCoordinate);
                }

                // 右下角
                if ((tempCoord.X + 1 < width && tempCoord.Y + 1 < height) && !IsSolveOne(saveCoordinates, tempCoord.X + 1, tempCoord.Y + 1) && bmp.GetPixel(tempCoord.X + 1, tempCoord.Y + 1).R == 0 && bmp.GetPixel(tempCoord.X + 1, tempCoord.Y + 1).G == 0 && bmp.GetPixel(tempCoord.X + 1, tempCoord.Y + 1).B == 0)
                {
                    Coordinate upCoordinate = new Coordinate();
                    upCoordinate.X = tempCoord.X + 1;
                    upCoordinate.Y = tempCoord.Y + 1;
                    saveCoordinates.Add(upCoordinate);
                    qu.Enqueue(upCoordinate);
                }

                // 下边
                if ((tempCoord.Y + 1 < height) && !IsSolveOne(saveCoordinates, tempCoord.X, tempCoord.Y + 1) && bmp.GetPixel(tempCoord.X, tempCoord.Y + 1).R == 0 && bmp.GetPixel(tempCoord.X, tempCoord.Y + 1).G == 0 && bmp.GetPixel(tempCoord.X, tempCoord.Y + 1).B == 0)
                {
                    Coordinate upCoordinate = new Coordinate();
                    upCoordinate.X = tempCoord.X;
                    upCoordinate.Y = tempCoord.Y + 1;
                    saveCoordinates.Add(upCoordinate);
                    qu.Enqueue(upCoordinate);
                }

                // 左下角
                if ((tempCoord.X - 1 > 0 && tempCoord.Y + 1 < height) && !IsSolveOne(saveCoordinates, tempCoord.X - 1, tempCoord.Y + 1) && bmp.GetPixel(tempCoord.X - 1, tempCoord.Y + 1).R == 0 && bmp.GetPixel(tempCoord.X - 1, tempCoord.Y + 1).G == 0 && bmp.GetPixel(tempCoord.X - 1, tempCoord.Y + 1).B == 0)
                {
                    Coordinate upCoordinate = new Coordinate();
                    upCoordinate.X = tempCoord.X - 1;
                    upCoordinate.Y = tempCoord.Y + 1;
                    saveCoordinates.Add(upCoordinate);
                    qu.Enqueue(upCoordinate);
                }

                //　左边
                if ((tempCoord.X - 1 > 0 && tempCoord.Y < height) && !IsSolveOne(saveCoordinates, tempCoord.X - 1, tempCoord.Y) && bmp.GetPixel(tempCoord.X - 1, tempCoord.Y).R == 0 && bmp.GetPixel(tempCoord.X - 1, tempCoord.Y).G == 0 && bmp.GetPixel(tempCoord.X - 1, tempCoord.Y).B == 0)
                {
                    Coordinate upCoordinate = new Coordinate();
                    upCoordinate.X = tempCoord.X - 1;
                    upCoordinate.Y = tempCoord.Y;
                    saveCoordinates.Add(upCoordinate);
                    qu.Enqueue(upCoordinate);
                }

                // 左上角
                if ((tempCoord.X - 1 > 0 && tempCoord.Y - 1 > 0) && !IsSolveOne(saveCoordinates, tempCoord.X - 1, tempCoord.Y - 1) && bmp.GetPixel(tempCoord.X - 1, tempCoord.Y - 1).R == 0 && bmp.GetPixel(tempCoord.X - 1, tempCoord.Y - 1).G == 0 && bmp.GetPixel(tempCoord.X - 1, tempCoord.Y - 1).B == 0)
                {
                    Coordinate upCoordinate = new Coordinate();
                    upCoordinate.X = tempCoord.X - 1;
                    upCoordinate.Y = tempCoord.Y - 1;
                    saveCoordinates.Add(upCoordinate);
                    qu.Enqueue(upCoordinate);
                }
            }

            return saveCoordinates;
        }


    }
}
