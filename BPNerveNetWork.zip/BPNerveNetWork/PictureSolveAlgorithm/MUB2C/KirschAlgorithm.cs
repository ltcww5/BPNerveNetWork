﻿//-----------------------------------------------------------------------
// <copyright file="KirschAlgorithm.cs" company="517Na Enterprises">
// * Copyright (C) 2015 517Na科技有限公司 版权所有。
// * version : 2.0.50727.5485
// * author  : xukong
// * FileName: KirschAlgorithm.cs
// * history : created by xukong 2015-02-15 10:11:00 
// </copyright>
//-----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace PictureSolveAlgorithm
{
    /// <summary>
    /// KirschAlgorithm边缘检测算法
    /// </summary>
    public class KirschAlgorithm
    {
        /// <summary>
        /// 模板一
        /// </summary>
        private int[,] kirschTemplateOne = new int[3, 3];

        /// <summary>
        /// 模板二
        /// </summary>
        private int[,] kirschTemplateTwo = new int[3, 3];

        /// <summary>
        /// 模板三
        /// </summary>
        private int[,] kirschTemplateThree = new int[3, 3];

        /// <summary>
        /// 模板四
        /// </summary>
        private int[,] kirschTemplateFour = new int[3, 3];

        /// <summary>
        /// 模板五
        /// </summary>
        private int[,] kirschTemplateFive = new int[3, 3];

        /// <summary>
        /// 模板六
        /// </summary>
        private int[,] kirschTemplateSix = new int[3, 3];

        /// <summary>
        /// 模板七
        /// </summary>
        private int[,] kirschTemplateSeven = new int[3, 3];

        /// <summary>
        /// 模板八
        /// </summary>
        private int[,] kirschTemplateEight = new int[3, 3];

        /// <summary>
        /// 图像
        /// </summary>
        private Bitmap bitMap = null;

        /// <summary>
        /// 图像宽度
        /// </summary>
        private int width = 0;

        /// <summary>
        /// 图像高度
        /// </summary>
        private int height = 0;

        /// <summary>
        /// 构造函数
        /// </summary>
        public KirschAlgorithm(Bitmap bitMap)
        {
            this.bitMap = bitMap;
            this.width = this.bitMap.Width;
            this.height = this.bitMap.Height;
            kirschTemplateOne = new int[,] { { 5, 5, 5 }, { -3, 0, -3 }, { -3, -3, -3 } };
            kirschTemplateTwo = new int[,] { { -3, 5, 5 }, { -3, 0, 5 }, { -3, -3, -3 } };
            kirschTemplateThree = new int[,] { { -3, -3, 5 }, { -3, 0, 5 }, { -3, -3, 5 } };

            kirschTemplateFour = new int[,] { { -3, -3, -3 }, { -3, 0, 5 }, { -3, 5, 5 } };
            kirschTemplateFive = new int[,] { { -3, -3, -3 }, { -3, 0, -3 }, { 5, 5, 5 } };
            kirschTemplateSix = new int[,] { { -3, -3, -3 }, { 5, 0, -3 }, { 5, 5, -3 } };

            kirschTemplateSeven = new int[,] { { 5, -3, -3 }, { 5, 0, -3 }, { 5, -3, -3 } };
            kirschTemplateEight = new int[,] { { 5, 5, -3 }, { 5, 0, -3 }, { -3, -3, -3 } };

        }

        /// <summary>
        /// 提取轮廓
        /// </summary>
        /// <param name="threshold">阀值</param>
        /// <returns>返回提取轮廓的图像</returns>
        public Bitmap ExtractOutLine(int threshold)
        {
            Bitmap bm = this.bitMap;
            int[,] edgeOne = new int[this.width, this.height];
            int[,] edgeTwo = new int[this.width, this.height];
            int[,] edgeThree = new int[this.width, this.height];
            int[,] edgeFour = new int[this.width, this.height];
            int[,] edgeFive = new int[this.width, this.height];
            int[,] edgeSix = new int[this.width, this.height];
            int[,] edgeSeven = new int[this.width, this.height];
            int[,] edgeEight = new int[this.width, this.height];

            int[,] gray = this.GetGrayPic();
            edgeOne = this.edgeDetect(gray, kirschTemplateOne, this.width, this.height);
            edgeTwo = this.edgeDetect(gray, kirschTemplateTwo, this.width, this.height);
            edgeThree = this.edgeDetect(gray, kirschTemplateThree, this.width, this.height);
            edgeFour = this.edgeDetect(gray, kirschTemplateFour, this.width, this.height);
            edgeFive = this.edgeDetect(gray, kirschTemplateFive, this.width, this.height);
            edgeSix = this.edgeDetect(gray, kirschTemplateSix, this.width, this.height);
            edgeSeven = this.edgeDetect(gray, kirschTemplateSeven, this.width, this.height);
            edgeEight = this.edgeDetect(gray, kirschTemplateEight, this.width, this.height);

            int[] temp = new int[8];
            int max = 0;
            int colorWeight = 0;
            Color color = new Color();
            for (int j = 0; j < this.height; j++)
            {
                for (int i = 0; i < this.width; i++)
                {
                    temp[0] = edgeOne[i, j];
                    temp[1] = edgeTwo[i, j];
                    temp[2] = edgeThree[i, j];
                    temp[3] = edgeFour[i, j];
                    temp[4] = edgeFive[i, j];
                    temp[5] = edgeSix[i, j];
                    temp[6] = edgeSeven[i, j];
                    temp[7] = edgeEight[i, j];
                    max = 0;
                    for (int k = 0; k < 8; k++)
                    {
                        if (temp[k] > max)
                        {
                            max = temp[k];
                        }
                    }

                    if (max > threshold)
                    {
                        colorWeight = 0;
                    }
                    else
                    {
                        colorWeight = 255;
                    }

                    color = Color.FromArgb(colorWeight, colorWeight, colorWeight);
                    bm.SetPixel(i, j, color);
                }
            }

            return this.bitMap;
        }

        /// <summary>
        /// 获取灰度图像
        /// </summary>
        /// <returns>返回灰度值集合</returns>
        public int[,] GetGrayPic()
        {
            int[,] gray = new int[this.width, this.height];
            for (int j = 0; j < this.height; j++)
            {
                for (int i = 0; i < this.width; i++)
                {
                    Color color = this.bitMap.GetPixel(i, j);
                    gray[i, j] = (int)((color.R + color.G + color.B) / 3.0);
                }
            }

            return gray;
        }

        /// <summary>
        /// 边缘检测
        /// </summary>
        /// <param name="gray">灰度值集合</param>
        /// <param name="kirsch">kirsch算法</param>
        /// <param name="width">图片宽度</param>
        /// <param name="height">图片高度</param>
        /// <returns></returns>
        public int[,] edgeDetect(int[,] gray, int[,] kirsch, int width, int height)
        {
            int[,] edge = new int[width, height];

            for (int j = 1; j < height - 1; j++)
            {
                for (int i = 1; i < width - 1; i++)
                {
                    edge[i, j] = Math.Abs(kirsch[0, 0] * gray[i - 1, j - 1] + kirsch[0, 1] * gray[i - 1, j] +
                                       kirsch[0, 2] * gray[i - 1, j + 1] + kirsch[1, 0] * gray[i, j - 1] +
                                       kirsch[1, 1] * gray[i, j] + kirsch[1, 2] * gray[i, j + 1] +
                                       kirsch[2, 0] * gray[i + 1, j - 1] + kirsch[2, 1] * gray[i + 1, j] +
                                       kirsch[2, 2] * gray[i + 1, j + 1]);
                }
            }

            return edge;
        }
    }
}
