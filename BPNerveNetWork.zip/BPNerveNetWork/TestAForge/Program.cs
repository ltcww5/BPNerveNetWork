﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BPNerveNetWork;
using System.IO;

namespace TestAForge
{
    class Program
    {
        static void Main(string[] args)
        {
            // 测试神经网络
            double[,] data = new double[,] { { 0.1, 0.2 }, { 0.3, 0.4 } };
            double[] teacherData = new double[] { 0.2, 0.3 };
            MNerveNetWork netWork = new MNerveNetWork();
            netWork.InputData = data;
            netWork.TeacherData = null;
            netWork.StudyRate = 0.08;
            netWork.PrecisionControl = 0.01;
            netWork.TrainNumber = 10000;
            netWork.MomentumFactor = 0.6;
            netWork.OutputDataNumber = 1;
            NerveNetWork netWorkTest = new NerveNetWork(netWork);
            netWorkTest.TrainNetWork();

            double[,] testData = new double[,] { { 0.1, 0.2 } };

            //double[,] data = new double[,] { { 0.1, 0.2 }, { 0.3, 0.4 }, { 0.2, 0.3 }, { 0.2, 0.3 } };
            //double[] teacherData = new double[] { 0.2, 0.3 };
            //Console.WriteLine(data.GetLength(1));

            string pat = AppDomain.CurrentDomain.BaseDirectory + "HideWeightMatrix.txt";
            StreamReader rea = new StreamReader(pat);
            string ss = string.Empty;
            while ((ss = rea.ReadLine()) != null)
            {
                Console.WriteLine(ss);
            }

            Console.ReadLine();
        }

        private void read()
        {
            string pat = AppDomain.CurrentDomain.BaseDirectory + "HideWeightMatrix.txt";
            StreamReader rea = new StreamReader(pat);
            string ss=string.Empty;
            while ((ss=rea.ReadLine()) != null)
            {
                Console.WriteLine(ss);
            }
        }
    }
}
